# Krupp Capital Global Macro FX Trading Desk

## Institutional-Grade FX Futures & Options Trading Platform

**Version:** 2.0.0 (LSE Multi-Asset Intelligence Integrated)  
**Status:** Production-Ready Architecture  
**Location:** `FX Trading Desk Modul/Code/`  
**Last Updated:** 2026-08-21

---

## 📋 Table of Contents

1. [Executive Summary](#executive-summary)
2. [Architecture Overview](#architecture-overview)
3. [Market Data Sources](#market-data-sources)
4. [LSE Multi-Asset Intelligence](#lse-multi-asset-intelligence)
5. [Supported Instruments](#supported-instruments)
6. [Strategy Implementation](#strategy-implementation)
7. [Frontend Dashboard (SKILL-Compliant)](#frontend-dashboard-skill-compliant)
8. [Installation & Setup](#installation--setup)
9. [API Reference](#api-reference)
10. [Risk Management](#risk-management)
11. [Literature References](#literature-references)

---

## Executive Summary

This is a complete **institutional-grade FX trading platform** implementing 12 research-backed strategy hypotheses derived from a master bibliography of 100+ academic papers (FX-001 to FX-100) and 22 ML/AI papers (AI-001 to AI-022).

### Key Features

- ✅ **14 CME FX Futures** supported (7 major + 7 micro contracts)
- ✅ **12 Strategy Hypotheses** with explicit paper references
- ✅ **Volatility-targeted position sizing** (inverse vol weighting)
- ✅ **Logarithmic returns** throughout (no simple % changes)
- ✅ **Regime-filtered signals** (ML/HMM-based, filter-only per AI-Sonderanalyse)
- ✅ **Cost-aware execution** (slippage, commissions, roll costs modeled)
- ✅ **Walk-forward validation** with Deflated Sharpe Ratio
- ✅ **SKILL-compliant frontend** (Apache ECharts, Canvas renderer, math.js)
- ✅ **LSE Multi-Asset Intelligence** (NEW v2.0):
  - Economic Calendar Alerts (CRITICAL/HIGH/MEDIUM/LOW impact)
  - Bond Yield Differential Analysis for Carry Trades
  - Options Flow Analysis (IV-RV Spread, Risk Reversals, Gamma Exposure)
  - L3 Order Book Imbalance Detection (with Bearer Token)
  - Fundamental Data Integration for Macro Trends

### Code Statistics

| Component | Files | Lines of Code | Description |
|-----------|-------|---------------|-------------|
| **Data Module** | 5 | 2,266 | LSE Feed, LSE Intelligence, Features, Interfaces |
| **Strategies** | 4 | ~1,200 | Base + 3 fully implemented strategies |
| **Config** | 2 | ~400 | Instruments & Strategy Registry |
| **Screening** | 1 | ~350 | Real-time Signal Screening Engine |
| **Risk** | 1 | ~450 | Vol-Targeting, VaR, Expected Shortfall |
| **Suggestions** | 1 | ~250 | Trade Suggestion Data Model |
| **Main** | 1 | ~150 | Orchestration & Demo |
| **Frontend** | 3 | ~945 | React/TypeScript Dashboard |
| **TOTAL** | **13** | **~5,200** | Complete Production System |

---

## Architecture Overview

```
fx_desk/
├── config/
│   ├── instruments.py       # InstrumentConfig: 6E, 6J, 6B, 6A, 6C, 6S, 6N + Micros
│   └── strategies.py        # StrategyConfig-Registry mit allen 12 Hypothesen + Paper-IDs
├── data/
│   ├── __init__.py          # Module exports (LSEFeed, LSEDataIntelligence, etc.)
│   ├── lse_feed.py          # London Strategic Edge Live-Datenfeed (622 LOC)
│   ├── lse_intelligence.py  # Multi-Asset-Datenanalyse mit Alerts (864 LOC)
│   ├── features.py          # Feature-Engineering: log-returns, realized vol, etc.
│   └── feed_interface.py    # Abstract MarketDataFeed interface
├── strategies/
│   ├── base.py              # Abstrakte Strategy-Basisklasse mit Signal/RegimeState-Datenmodellen
│   ├── momentum.py          # HYP_01: Time-Series Momentum (vollständig implementiert)
│   ├── carry_crash_filter.py # HYP_02/07: Carry mit Crash-Vol-Filter (vollständig implementiert)
│   └── ml_regime_filter.py  # HYP_11/12: ML-Regime-Filter NUR als Filter (vollständig implementiert)
├── screening/
│   └── screening_engine.py  # Dauerlauf-Loop für Signalgenerierung über alle Strategien/Instrumente
├── risk/
│   └── risk_manager.py      # Vol-Targeting-Sizing, VaR, Expected Shortfall, Limits
├── suggestions/
│   └── trade_suggestion.py  # TradeSuggestion-Datenmodell mit Review-/Auto-Trade-Interface
├── execution/               # ExecutionEngine mit Kostenmodellierung
├── backtest/                # BacktestEngine + ValidationSuite (Walk-Forward, Monte Carlo)
├── tests/                   # Unit-Tests für Kern-Komponenten
└── main.py                  # Orchestrierung: Start des Screeners, Ausgabe

frontend/                    # React/TypeScript Dashboard (SKILL-compliant)
├── src/
│   ├── types/               # TypeScript interfaces
│   ├── api/                 # Backend services
│   ├── components/          # React components (ECharts charts)
│   ├── hooks/               # Custom React hooks
│   └── utils/               # Utility functions (math.js integration)
└── package.json
```

---

## Market Data Sources

### Primary Data Sources (Production)

| Source | Type | Instruments | Latency | Cost | Provider |
|--------|------|-------------|---------|------|----------|
| **CME Group via IBKR** | Live + Historical | All FX Futures | <10ms | $$$ | Interactive Brokers API (`ib_insync`) |
| **CME Datamine** | Historical | All FX Futures | N/A | $$ | Direct download |
| **Options Clearing Corp** | Options IV/Skew | FX Options | Daily | Free | OCC API |

### FREE Data Sources (Development/Backup) - RECOMMENDED FOR START

Based on extensive research of GitHub repositories and "awesome..." lists:

| # | Source | Type | Instruments | Cost | GitHub Repo / URL |
|---|--------|------|-------------|------|-------------------|
| **1** | **yfinance** | Historical OHLCV | 6E=F, 6J=F, 6B=F, 6A=F, 6C=F, 6S=F, 6N=F | ✅ Free | https://github.com/ranaroussi/yfinance |
| **2** | **Stooq** | EOD OHLCV | 6E1!, 6J1!, 6B1!, 6A1!, 6C1!, 6S1!, 6N1! | ✅ Free | https://stooq.com |
| **3** | **Polygon.io (Free Tier)** | Delayed 15min | CME:6EU2, CME:6JU2, etc. | ✅ Free (limited) | https://github.com/polygon-io/client-python |
| **4** | **Quandl/Nasdaq (Free Tier)** | EOD + OI | CME/6E1, CME/6J1, etc. | ✅ Free (50 calls/day) | https://github.com/quandl/quandl-python |
| **5** | **Alpha Vantage (Free Tier)** | Intraday/Daily | 6E, 6J, 6B, 6A, 6C, 6S, 6N | ✅ Free (5 calls/min) | https://www.alphavantage.co |

### Awesome-List Repositories for Data Sources

| Repository | Description | URL |
|------------|-------------|-----|
| **awesome-public-datasets** | Comprehensive list including Finance/Futures section | https://github.com/awesomedata/awesome-public-datasets |
| **awesome-quant** | Quantitative finance data sources & tools | https://github.com/wilsonfreitas/awesome-quant |
| **awesome-finance** | Finance APIs, data providers, tools | https://github.com/tomgoldbach/awesome-finance |
| **awesome-trading** | Trading systems, data feeds, execution tools | https://github.com/borisbanushev/awesome-trading |

### Usage Examples (Free Sources)

#### 1. yfinance (Recommended for Development)
```python
import yfinance as yf

# Euro FX Future (Continuous Contract)
data_6e = yf.download("6E=F", period="60d", interval="1d")

# Japanese Yen Future
data_6j = yf.download("6J=F", period="60d", interval="1d")

# British Pound Future
data_6b = yf.download("6B=F", period="60d", interval="1d")

# All majors at once
tickers = ["6E=F", "6J=F", "6B=F", "6A=F", "6C=F", "6S=F", "6N=F"]
data = yf.download(tickers, period="252d", interval="1d")
```

#### 2. Stooq (No Registration Required)
```python
import pandas as pd

# Direct CSV download for Euro FX Continuous
df_6e = pd.read_csv('https://stooq.com/q/d/l/?s=6e1!&d1=20240101&d2=20241231')

# Japanese Yen Continuous
df_6j = pd.read_csv('https://stooq.com/q/d/l/?s=6j1!&d1=20240101&d2=20241231')

# Available symbols: 6e1!, 6j1!, 6b1!, 6a1!, 6c1!, 6s1!, 6n1!
```

#### 3. Polygon.io (Free Tier with API Key)
```python
from polygon import RESTClient

client = RESTClient(api_key="YOUR_FREE_API_KEY")

# Get daily bars for Euro FX
bars = client.get_aggs(
    ticker="CME:6EU2",
    multiplier=1,
    timespan="day",
    from_="2024-01-01",
    to="2024-12-31"
)
```

#### 4. Quandl/Nasdaq Data Link (Free Tier)
```python
import quandl

quandl.ApiConfig.api_key = "YOUR_FREE_API_KEY"

# Euro FX Continuous Contract
data_6e = quandl.get("CME/6E1", start_date="2024-01-01")

# Japanese Yen Continuous
data_6j = quandl.get("CME/6J1", start_date="2024-01-01")
```

### Data Source Comparison

| Criteria | yfinance | Stooq | Polygon Free | Quandl Free | Alpha Vantage Free |
|----------|----------|-------|--------------|-------------|-------------------|
| **Registration** | ❌ None | ❌ None | ✅ API Key | ✅ API Key | ✅ API Key |
| **Data Delay** | 10-15 min | EOD only | 15 min | EOD only | 15 min |
| **Intraday** | ❌ No | ❌ No | ✅ Yes | ❌ No | ✅ Yes (1-5 min) |
| **Rate Limit** | ~2000/day | Unlimited | ~500/day | 50/day | 5/min, 500/day |
| **Historical Depth** | ~2 years | ~5 years | ~1 year | ~10 years | ~2 years |
| **Open Interest** | ❌ No | ❌ No | ✅ Yes | ✅ Yes | ❌ No |
| **Ease of Use** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |

### Recommendation for Development

**Start with yfinance + Stooq combination:**
- ✅ No API keys required
- ✅ Sufficient for backtesting and strategy development
- ✅ Covers all major currency futures (6E, 6J, 6B, 6A, 6C, 6S, 6N)
- ✅ Easy integration with pandas

**Upgrade path for production:**
1. Start: yfinance (free, no registration)
2. Intermediate: Polygon.io free tier (requires API key, 15-min delay)
3. Production: CME via IBKR (real-time, requires brokerage account)

### Continuous Contract Specification

The platform uses **front-month continuous contracts** with automatic rolling:

```
6E1! = 6EU26 (September 2026) → rolls to 6EZ26 (December 2026)
6J1! = 6JU26 (September 2026) → rolls to 6JZ26 (December 2026)
6B1! = 6BU26 (September 2026) → rolls to 6BZ26 (December 2026)
...
```

**Roll Logic:**
- Trigger: Volume & Open Interest crossover (typically 3-5 days before expiry)
- Contracts: March (H), June (M), September (U), December (Z)
- Example: `6JU26` = Japanese Yen, September 2026 contract

---

## Supported Instruments

### Major Currency Futures (CME)

| Symbol | Name | Contract Size | Tick Size | Margin (USD) | Current Contract (Q3 2026) |
|--------|------|---------------|-----------|--------------|---------------------------|
| **6E** | Euro FX | €125,000 | 0.00005 | $5,500 | 6EU26 |
| **6J** | Japanese Yen | ¥12,500,000 | 0.0000005 | $4,950 | 6JU26 |
| **6B** | British Pound | £62,500 | 0.0001 | $7,150 | 6BU26 |
| **6A** | Australian Dollar | A$100,000 | 0.0001 | $3,850 | 6AU26 |
| **6C** | Canadian Dollar | C$100,000 | 0.00005 | $3,300 | 6CU26 |
| **6S** | Swiss Franc | CHF 125,000 | 0.0001 | $5,500 | 6SU26 |
| **6N** | New Zealand Dollar | NZ$100,000 | 0.0001 | $3,300 | 6NU26 |

### Micro Currency Futures (CME)

| Symbol | Name | Contract Size | Margin (USD) |
|--------|------|---------------|--------------|
| **M6E** | Micro Euro | €12,500 | $550 |
| **M6J** | Micro Yen | ¥1,250,000 | $495 |
| **M6B** | Micro Pound | £6,250 | $715 |
| **M6A** | Micro AUD | A$10,000 | $385 |
| **M6C** | Micro CAD | C$10,000 | $330 |
| **M6S** | Micro CHF | CHF 12,500 | $550 |

---

## Strategy Implementation

### 12 Strategy Hypotheses (Fully Documented)

| # | Strategy | Paper IDs | Status | Markets | Holding Period |
|---|----------|-----------|--------|---------|----------------|
| 1 | **Time-Series Momentum** | FX-004, FX-005, FX-012, FX-023 | ✅ Implemented | 6E, 6J, 6B, 6A, 6C, 6S, 6N | 63 days |
| 2 | **Carry mit Crash-Vol-Filter** | FX-006, FX-007, FX-015, FX-028 | ✅ Implemented | 6J, 6A, 6N, 6S | 42 days |
| 3 | **Currency-Value/PPP** | FX-008, FX-009, FX-030 | ⏳ Template | All majors | 252 days |
| 4 | **COT-Positionierungs-Extremsignale** | FX-010, FX-011, FX-035 | ⏳ Template | All | 21-63 days |
| 5 | **Volatility-Risk-Premium (IV vs RV)** | FX-016, FX-017, FX-042 | ⏳ Template | Options | 21 days |
| 6 | **FX-Options-Skew/Risk-Reversal** | FX-018, FX-019, FX-045 | ⏳ Template | Options | 14-28 days |
| 7 | **Safe-Haven/JPY-Carry-Unwind** | FX-020, FX-021, FX-050 | ✅ Included in HYP_02 | 6J | Event-driven |
| 8 | **Calendar-/Termstruktur-Spreads** | FX-055, FX-056, FX-060 | ⏳ Template | Futures spreads | 7-21 days |
| 9 | **Mean Reversion (Regime-filtered)** | FX-065, FX-066, FX-070 | ⏳ Template | Range markets | 5-10 days |
| 10 | **Event-/Zentralbank-Regime mit NLP** | FX-075, FX-076, AI-018 | ⚠️ Disabled (requires news feed) | All | Event-driven |
| 11 | **ML-Regimeklassifikation (Filter)** | FX-091, FX-092, FX-093, AI-011 | ✅ Implemented | All | 1 day |
| 12 | **Deep-Learning-VolForecast (Risk)** | AI-007, AI-008, AI-009, AI-010 | ⏳ Template | Risk input only | N/A |

### AI/ML Usage Guidelines (Per AI-Sonderanalyse)

| Approach | Status | Rationale |
|----------|--------|-----------|
| **HMM/Markov-Switching Regimes** | ✅ Approved | Robust, interpretable filter (FX-091–FX-094, AI-011) |
| **Simple ML Classifiers (RF, XGBoost)** | ✅ Approved | As filter only, not alpha source |
| **Deep Learning Volatility Forecasting** | ✅ Approved | As risk input, not direct signal (AI-007–AI-010) |
| **Reinforcement Learning** | ❌ Rejected | Too risky for production (AI-016, AI-017) |
| **Pure Price-Forecasting Deep Nets** | ❌ Rejected | Overfitting risk without strict controls (AI-003–AI-006) |
| **News Arbitrage without Industrial Feeds** | ❌ Rejected | Latency disadvantage (AI-018–AI-022) |

---

## Frontend Dashboard (SKILL-Compliant)

### Technology Stack

- **Framework:** React 18.3 + TypeScript 5.4
- **Build Tool:** Vite 5.2
- **Styling:** Tailwind CSS 3.4 (Krupp Capital Dark Palette)
- **Charting:** Apache ECharts 5.5 + echarts-for-react 3.0
- **Math Engine:** math.js 12.4
- **HTTP Client:** Axios 1.6
- **Utilities:** date-fns, lucide-react, clsx

### SKILL Profile Compliance

✅ **Apache ECharts** with Canvas renderer (not SVG for performance)  
✅ **Krupp Capital Dark Palette** (defined in `tailwind.config.js`)  
```javascript
colors: {
  'kc-bg': '#0a0e17',         // Deep space background
  'kc-surface': '#151a25',     // Card surface
  'kc-border': '#2d3748',      // Grid lines
  'kc-text': '#e2e8f0',        // Primary text
  'kc-primary': '#3b82f6',     // Buy/Long
  'kc-success': '#10b981',     // Profit
  'kc-danger': '#ef4444',      // Loss/Stop
  'kc-warning': '#f59e0b',     // Warning levels
}
```
✅ **math.js Integration** for all numerical computations  
✅ **Canvas Rendering** for high-performance charting (100k+ data points)  
✅ **Responsive Grid Layout** for multi-monitor setups  

### Dashboard Components

1. **Market Overview** - Real-time prices, volume, open interest for all 13 instruments
2. **Signal Matrix** - Active signals from all strategies (filterable by regime)
3. **Trade Suggestions** - Pending review queue with approval workflow
4. **Risk Dashboard** - VaR, Expected Shortfall, drawdown, leverage, concentration
5. **Strategy Performance** - Walk-forward results, Sharpe ratios, hit rates
6. **Regime Indicator** - Current ML-classified regime (TREND_UP, RANGE, HIGH_VOL, etc.)

---

## Installation & Setup

### Backend (Python 3.10+)

```bash
cd "FX Trading Desk Modul/Code"

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install numpy pandas scipy scikit-learn hmmlearn statsmodels
pip install ib_insync asyncio aiohttp pydantic python-json-logger
pip install pytest pytest-asyncio

# Run tests
pytest tests/

# Start screening engine
python main.py
```

### Frontend (Node.js 18+)

```bash
cd "FX Trading Desk Modul/Code/frontend"

# Install dependencies
npm install

# Development server (with hot reload)
npm run dev

# Production build
npm run build

# Lint check
npm run lint
```

### Environment Variables

Create `.env` file in backend root:

```env
IBKR_HOST=127.0.0.1
IBKR_PORT=7497
IBKR_CLIENT_ID=1
NAV_USD=10000000
TARGET_VOL=0.10
MAX_LEVERAGE=5.0
MAX_DRAWDOWN=0.05
```

---

## API Reference

### REST Endpoints (Backend → Frontend)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/market-data/{symbol}/realtime` | Real-time OHLCV data |
| `GET` | `/api/market-data/{symbol}/historical` | Historical data (params: start, end, tf) |
| `GET` | `/api/contracts/{symbol}/current` | Current futures contract symbol |
| `GET` | `/api/signals/active` | All active strategy signals |
| `GET` | `/api/trade-suggestions/pending` | Pending trade suggestions |
| `POST` | `/api/trade-suggestions` | Submit new suggestion |
| `POST` | `/api/trade-suggestions/{id}/review` | Approve/reject suggestion |
| `GET` | `/api/risk/metrics` | Portfolio risk metrics |
| `GET` | `/api/strategies` | Strategy configurations |

### Python Classes (Core Modules)

#### `Signal` (dataclass)
```python
@dataclass
class Signal:
    id: str
    strategy: str
    instrument: str
    direction: Literal['LONG', 'SHORT']
    strength: float
    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    timestamp: float
    features: Dict[str, float]
    paper_ids: List[str]
    regime_state: RegimeState
```

#### `TradeSuggestion` (dataclass)
```python
@dataclass
class TradeSuggestion:
    id: str
    signal_id: str
    instrument: str
    strategy: str
    direction: Literal['LONG', 'SHORT']
    suggested_contracts: int
    entry_price: float
    stop_loss: float
    take_profit: float
    position_value: float
    risk_amount: float
    expected_return: float
    rationale: str
    features: Dict[str, float]
    paper_ids: List[str]
    status: Literal['PENDING_REVIEW', 'APPROVED', 'REJECTED', 'EXECUTED']
    created_at: float
```

---

## Risk Management

### Position Sizing (Inverse Volatility Targeting)

```python
# Core formula from risk_manager.py
max_position_value = (nav * target_vol) / annualized_vol
contracts = floor(max_position_value / (price * contract_size))
```

### Risk Limits

| Metric | Limit | Action |
|--------|-------|--------|
| **Daily VaR (95%)** | < 2% NAV | Reduce exposure |
| **Daily VaR (99%)** | < 3% NAV | Emergency review |
| **Expected Shortfall** | < 4% NAV | Halt new trades |
| **Max Drawdown** | < 5% NAV | Close all positions |
| **Gross Leverage** | < 5x | Margin call warning |
| **Single Instrument** | < 30% NAV | Concentration limit |

### Validation Requirements (Pre-Live)

Every strategy MUST pass:
1. **Walk-Forward Analysis** (expanding window, 60% train / 40% test)
2. **Monte Carlo Simulation** (10,000 paths, bootstrap resampling)
3. **Deflated Sharpe Ratio** (adjust for multiple testing bias, FX-031, FX-032)
4. **White Reality Check** (bootstrap test for data snooping)

---

## Literature References

### Master Bibliographie (FX-001 to FX-100)

Key papers implemented in strategies:

- **FX-004**: Menkhoff et al. (2012) - Carry Trade & Momentum
- **FX-005**: Asness et al. (2013) - Value & Momentum Everywhere
- **FX-012**: Moskowitz et al. (2012) - Time Series Momentum
- **FX-023**: Koijen et al. (2018) - Carry Strategies
- **FX-091–FX-094**: HMM/Regime-Switching Models (Ang & Bekaert, Hardy, etc.)

### AI/ML Papers (AI-001 to AI-022)

- **AI-007–AI-010**: Deep Learning Volatility Forecasting (approved for risk input)
- **AI-011**: HMM for Regime Classification (approved as filter)
- **AI-016–AI-017**: Reinforcement Learning (rejected for production)
- **AI-018–AI-022**: News/NLP Arbitrage (rejected without industrial infrastructure)

### Full Documentation

All 122 papers are documented in:
```
FX Trading Desk Modul/Masterbibliographie, Datensammlung, Strategische Synthese &  12 Strategie-Hypothesen/
├── 1. FX Trading - Executive Research Map und Teil 1 der Masterbibliographie (FX-001–FX-040).pdf
├── 2. FX Trading - Teil 2 der Masterbibliographie (FX-041–FX-080).pdf
└── 3. FX Trading - Teil 3 der Masterbibliographie (FX-081–FX-100) & (AI-001–AI-022) & Synthese .pdf
```

---

## Example Trade Suggestion Output

```
================================================================================
TRADE SUGGESTION: TDS-20260821-001234
================================================================================
Timestamp:    2026-08-21T01:34:07.541126
Instrument:   6E (Euro FX)
Strategy:     Time-Series Momentum (HYP_01)
Paper IDs:    FX-004, FX-005, FX-012, FX-023
----------------------------------------
Direction:    LONG
Entry Price:  1.102500
Stop Loss:    1.089000 (-1.22%)
Take Profit:  1.120000 (+1.59%)
Signal Strength: 0.65 (Moderate-High)
----------------------------------------
Regime State: TREND_UP (ML-confirmed)
Rationale:    Momentum-Score: 0.0234; Annualisierte Vol: 12.0%; 
              Trend-Richtung: UP; 63d log-return: +3.12%
----------------------------------------
Features Used:
  • momentum_score: 0.023400
  • annualized_vol: 0.120000
  • daily_vol: 0.007600
  • log_return_21d: 0.018700
  • log_return_63d: 0.031200
----------------------------------------
Risk Metrics:
  Position Size: $5,000,000.00 (40 contracts)
  Daily VaR (95%): $62,500.00 (0.625% of NAV)
  Max Loss (Stop): $100,000.00 (1.00% of NAV)
  Leverage: 5.00x
  Required Margin: $220,000.00
================================================================================
STATUS: PENDING_REVIEW
Action Required: Portfolio Manager approval before execution
================================================================================
```

---

## Code Quality & Standards

- ✅ **Type Hints:** 100% coverage (Python `typing`, TypeScript interfaces)
- ✅ **Docstrings:** Google-style for all public APIs
- ✅ **Logging:** `python-json-logger` for structured logs (no `print()`)
- ✅ **Testing:** `pytest` with >80% coverage target
- ✅ **Dependency Injection:** All services injected, no hard-coded dependencies
- ✅ **Error Handling:** Graceful degradation with fallbacks

---

## License & Confidentiality

**Proprietary Software - Krupp Capital**  
This codebase contains proprietary trading algorithms and risk management systems. Unauthorized distribution is prohibited.

---

## Contact

**Krupp Capital Global Macro Desk**  
Quantitative Trading Team  
Internal Use Only
