import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Activity, TrendingUp, AlertTriangle, Shield, CheckCircle, XCircle } from 'lucide-react';
import type { DashboardState, Signal, TradeSuggestion, RiskMetrics } from './types';
import { marketDataService, signalService, riskService, strategyService } from './api/services';

// Placeholder for ECharts component - to be implemented with echarts-for-react
const PriceChart: React.FC<{ symbol: string; data: any[] }> = ({ symbol, data }) => (
  <div className="h-64 bg-kc-surface rounded-lg flex items-center justify-center border border-kc-border">
    <div className="text-center">
      <p className="text-kc-text-muted text-sm">ECharts Canvas Renderer</p>
      <p className="text-kc-text font-mono">{symbol} - {data.length} data points</p>
      <p className="text-kc-text-muted text-xs mt-2">Apache ECharts 5.5 + math.js integration</p>
    </div>
  </div>
);

const StatCard: React.FC<{ 
  title: string; 
  value: string | number; 
  icon: React.ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  subtext?: string;
}> = ({ title, value, icon, trend, subtext }) => (
  <div className="bg-kc-surface rounded-lg p-4 border border-kc-border">
    <div className="flex items-center justify-between mb-2">
      <span className="text-kc-text-muted text-sm">{title}</span>
      <span className="text-kc-primary">{icon}</span>
    </div>
    <div className="text-2xl font-bold text-kc-text">{value}</div>
    {trend && (
      <div className={`text-xs mt-1 ${trend === 'up' ? 'text-kc-success' : trend === 'down' ? 'text-kc-danger' : 'text-kc-text-muted'}`}>
        {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'} {subtext}
      </div>
    )}
  </div>
);

const SignalTable: React.FC<{ signals: Signal[] }> = ({ signals }) => (
  <div className="bg-kc-surface rounded-lg border border-kc-border overflow-hidden">
    <div className="px-4 py-3 border-b border-kc-border">
      <h3 className="text-kc-text font-semibold">Active Signals</h3>
    </div>
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-kc-surface-light">
          <tr>
            <th className="px-4 py-2 text-left text-kc-text-muted">Time</th>
            <th className="px-4 py-2 text-left text-kc-text-muted">Instrument</th>
            <th className="px-4 py-2 text-left text-kc-text-muted">Strategy</th>
            <th className="px-4 py-2 text-left text-kc-text-muted">Direction</th>
            <th className="px-4 py-2 text-left text-kc-text-muted">Strength</th>
            <th className="px-4 py-2 text-left text-kc-text-muted">Regime</th>
            <th className="px-4 py-2 text-left text-kc-text-muted">Papers</th>
          </tr>
        </thead>
        <tbody>
          {signals.map((signal) => (
            <tr key={signal.id} className="border-t border-kc-border hover:bg-kc-surface-light">
              <td className="px-4 py-2 text-kc-text-muted">
                {format(new Date(signal.timestamp), 'HH:mm:ss')}
              </td>
              <td className="px-4 py-2 text-kc-text font-mono">{signal.instrument}</td>
              <td className="px-4 py-2 text-kc-text">{signal.strategy}</td>
              <td className={`px-4 py-2 font-semibold ${signal.direction === 'LONG' ? 'text-kc-success' : 'text-kc-danger'}`}>
                {signal.direction}
              </td>
              <td className="px-4 py-2">
                <div className="w-24 bg-kc-border rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${signal.strength > 0.7 ? 'bg-kc-success' : signal.strength > 0.4 ? 'bg-kc-warning' : 'bg-kc-danger'}`}
                    style={{ width: `${signal.strength * 100}%` }}
                  />
                </div>
              </td>
              <td className="px-4 py-2 text-kc-text-muted">{signal.regime_state}</td>
              <td className="px-4 py-2 text-kc-text-muted text-xs font-mono">
                {signal.paper_ids.slice(0, 3).join(', ')}{signal.paper_ids.length > 3 ? '...' : ''}
              </td>
            </tr>
          ))}
          {signals.length === 0 && (
            <tr>
              <td colSpan={7} className="px-4 py-8 text-center text-kc-text-muted">
                No active signals - waiting for market conditions
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  </div>
);

const TradeSuggestionsPanel: React.FC<{ suggestions: TradeSuggestion[] }> = ({ suggestions }) => (
  <div className="bg-kc-surface rounded-lg border border-kc-border overflow-hidden">
    <div className="px-4 py-3 border-b border-kc-border flex justify-between items-center">
      <h3 className="text-kc-text font-semibold">Trade Suggestions (Pending Review)</h3>
      <span className="bg-kc-warning text-kc-bg px-2 py-0.5 rounded text-xs font-semibold">
        {suggestions.filter(s => s.status === 'PENDING_REVIEW').length} Pending
      </span>
    </div>
    <div className="max-h-96 overflow-y-auto">
      {suggestions.filter(s => s.status === 'PENDING_REVIEW').map((suggestion) => (
        <div key={suggestion.id} className="p-4 border-b border-kc-border hover:bg-kc-surface-light">
          <div className="flex justify-between items-start mb-2">
            <div>
              <span className={`font-bold ${suggestion.direction === 'LONG' ? 'text-kc-success' : 'text-kc-danger'}`}>
                {suggestion.direction}
              </span>
              <span className="text-kc-text mx-2 font-mono">{suggestion.instrument}</span>
              <span className="text-kc-text-muted text-sm">{suggestion.strategy}</span>
            </div>
            <span className="text-kc-text-muted text-xs font-mono">
              {format(new Date(suggestion.createdAt), 'MMM dd, HH:mm')}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs mb-2">
            <div className="text-kc-text-muted">Entry: <span className="text-kc-text font-mono">{suggestion.entry_price.toFixed(5)}</span></div>
            <div className="text-kc-text-muted">Stop: <span className="text-kc-danger font-mono">{suggestion.stop_loss.toFixed(5)}</span></div>
            <div className="text-kc-text-muted">Contracts: <span className="text-kc-text font-mono">{suggestion.suggested_contracts}</span></div>
          </div>
          <p className="text-kc-text-muted text-xs mb-3">
            {suggestion.rationale}
          </p>
          <div className="flex gap-2">
            <button className="flex-1 bg-kc-success hover:bg-green-600 text-white px-3 py-1.5 rounded text-sm flex items-center justify-center gap-1">
              <CheckCircle size={14} /> Approve
            </button>
            <button className="flex-1 bg-kc-danger hover:bg-red-600 text-white px-3 py-1.5 rounded text-sm flex items-center justify-center gap-1">
              <XCircle size={14} /> Reject
            </button>
          </div>
          <div className="mt-2 text-xs text-kc-text-muted font-mono">
            Papers: {suggestion.paper_ids.join(', ')}
          </div>
        </div>
      ))}
      {suggestions.filter(s => s.status === 'PENDING_REVIEW').length === 0 && (
        <div className="p-8 text-center text-kc-text-muted">
          No pending trade suggestions
        </div>
      )}
    </div>
  </div>
);

const RiskDashboard: React.FC<{ metrics: RiskMetrics }> = ({ metrics }) => (
  <div className="bg-kc-surface rounded-lg border border-kc-border p-4">
    <h3 className="text-kc-text font-semibold mb-4 flex items-center gap-2">
      <Shield size={18} className="text-kc-primary" />
      Risk Metrics
    </h3>
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      <div>
        <div className="text-kc-text-muted text-xs">VaR (95%)</div>
        <div className={`text-lg font-bold ${metrics.portfolioVaR95 / 1000000 > 0.02 ? 'text-kc-danger' : 'text-kc-success'}`}>
          ${(metrics.portfolioVaR95 / 1000).toFixed(1)}K
        </div>
      </div>
      <div>
        <div className="text-kc-text-muted text-xs">VaR (99%)</div>
        <div className={`text-lg font-bold ${metrics.portfolioVaR99 / 1000000 > 0.03 ? 'text-kc-danger' : 'text-kc-success'}`}>
          ${(metrics.portfolioVaR99 / 1000).toFixed(1)}K
        </div>
      </div>
      <div>
        <div className="text-kc-text-muted text-xs">Expected Shortfall</div>
        <div className="text-lg font-bold text-kc-text">
          ${(metrics.expectedShortfall / 1000).toFixed(1)}K
        </div>
      </div>
      <div>
        <div className="text-kc-text-muted text-xs">Max Drawdown</div>
        <div className={`text-lg font-bold ${metrics.maxDrawdown > 0.05 ? 'text-kc-danger' : 'text-kc-success'}`}>
          {(metrics.maxDrawdown * 100).toFixed(2)}%
        </div>
      </div>
      <div>
        <div className="text-kc-text-muted text-xs">Current Drawdown</div>
        <div className="text-lg font-bold text-kc-text">
          {(metrics.currentDrawdown * 100).toFixed(2)}%
        </div>
      </div>
      <div>
        <div className="text-kc-text-muted text-xs">Leverage</div>
        <div className={`text-lg font-bold ${metrics.leverage > 5 ? 'text-kc-danger' : metrics.leverage > 3 ? 'text-kc-warning' : 'text-kc-success'}`}>
          {metrics.leverage.toFixed(2)}x
        </div>
      </div>
    </div>
    <div className="mt-4 pt-4 border-t border-kc-border">
      <div className="text-kc-text-muted text-xs mb-2">Exposure Concentration</div>
      <div className="space-y-2">
        {Object.entries(metrics.concentration).slice(0, 5).map(([instrument, pct]) => (
          <div key={instrument} className="flex items-center gap-2">
            <span className="text-kc-text text-xs font-mono w-10">{instrument}</span>
            <div className="flex-1 bg-kc-border rounded-full h-2">
              <div 
                className="h-2 rounded-full bg-kc-primary"
                style={{ width: `${pct * 100}%` }}
              />
            </div>
            <span className="text-kc-text-muted text-xs w-10 text-right">{(pct * 100).toFixed(0)}%</span>
          </div>
        ))}
      </div>
    </div>
  </div>
);

function App() {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [tradeSuggestions, setTradeSuggestions] = useState<TradeSuggestion[]>([]);
  const [riskMetrics, setRiskMetrics] = useState<RiskMetrics>({
    portfolioVaR95: 125000,
    portfolioVaR99: 185000,
    expectedShortfall: 225000,
    maxDrawdown: 0.045,
    currentDrawdown: 0.012,
    totalExposure: 10000000,
    netExposure: 2500000,
    grossExposure: 12500000,
    leverage: 1.25,
    concentration: { '6E': 0.25, '6J': 0.20, '6B': 0.18, '6A': 0.15, '6C': 0.12, '6S': 0.10 },
  });
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [connectionStatus, setConnectionStatus] = useState<'CONNECTED' | 'DISCONNECTED' | 'RECONNECTING'>('CONNECTED');

  // Simulate data refresh loop
  useEffect(() => {
    const refreshData = async () => {
      try {
        const [activeSignals, pendingSuggestions, risk] = await Promise.all([
          signalService.getActiveSignals(),
          signalService.getPendingSuggestions(),
          riskService.getRiskMetrics(),
        ]);
        
        setSignals(activeSignals);
        setTradeSuggestions(pendingSuggestions);
        setRiskMetrics(risk);
        setLastUpdate(new Date());
        setConnectionStatus('CONNECTED');
      } catch (error) {
        console.error('Data refresh failed:', error);
        setConnectionStatus('RECONNECTING');
      }
    };

    refreshData();
    const interval = setInterval(refreshData, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-kc-bg">
      {/* Header */}
      <header className="bg-kc-surface border-b border-kc-border px-6 py-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-kc-text">Krupp Capital Global Macro</h1>
            <p className="text-kc-text-muted text-sm">FX Trading Desk Dashboard</p>
          </div>
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded ${connectionStatus === 'CONNECTED' ? 'bg-kc-success/20 text-kc-success' : connectionStatus === 'RECONNECTING' ? 'bg-kc-warning/20 text-kc-warning' : 'bg-kc-danger/20 text-kc-danger'}`}>
              <Activity size={16} />
              <span className="text-sm font-medium">
                {connectionStatus === 'CONNECTED' ? 'Live' : connectionStatus === 'RECONNECTING' ? 'Reconnecting...' : 'Disconnected'}
              </span>
            </div>
            <div className="text-kc-text-muted text-sm">
              Last update: {format(lastUpdate, 'HH:mm:ss')}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {/* Top Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard 
            title="Total Exposure" 
            value={`$${(riskMetrics.totalExposure / 1000000).toFixed(1)}M`}
            icon={<TrendingUp size={20} />}
            trend="neutral"
            subtext={`${(riskMetrics.netExposure / riskMetrics.totalExposure * 100).toFixed(0)}% net`}
          />
          <StatCard 
            title="Active Signals" 
            value={signals.length}
            icon={<Activity size={20} />}
            trend={signals.length > 5 ? 'up' : 'neutral'}
            subtext={signals.length > 0 ? `${signals.filter(s => s.direction === 'LONG').length} long, ${signals.filter(s => s.direction === 'SHORT').length} short` : 'No signals'}
          />
          <StatCard 
            title="Pending Reviews" 
            value={tradeSuggestions.filter(s => s.status === 'PENDING_REVIEW').length}
            icon={<AlertTriangle size={20} />}
            trend={tradeSuggestions.filter(s => s.status === 'PENDING_REVIEW').length > 0 ? 'up' : 'neutral'}
          />
          <StatCard 
            title="Portfolio VaR (95%)" 
            value={`$${(riskMetrics.portfolioVaR95 / 1000).toFixed(0)}K`}
            icon={<Shield size={20} />}
            trend={riskMetrics.portfolioVaR95 / 1000000 < 0.02 ? 'up' : 'down'}
            subtext={`${(riskMetrics.portfolioVaR95 / riskMetrics.totalExposure * 100).toFixed(2)}% of NAV`}
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
          <div>
            <h3 className="text-kc-text font-semibold mb-2">Euro FX (6E1!)</h3>
            <PriceChart symbol="6E1!" data={marketDataService.generateSimulatedData('6E', 100)} />
          </div>
          <div>
            <h3 className="text-kc-text font-semibold mb-2">Japanese Yen (6J1!)</h3>
            <PriceChart symbol="6J1!" data={marketDataService.generateSimulatedData('6J', 100)} />
          </div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <SignalTable signals={signals} />
          </div>
          <div>
            <RiskDashboard metrics={riskMetrics} />
          </div>
        </div>

        {/* Trade Suggestions Panel */}
        <div className="mt-6">
          <TradeSuggestionsPanel suggestions={tradeSuggestions} />
        </div>
      </main>
    </div>
  );
}

export default App;
