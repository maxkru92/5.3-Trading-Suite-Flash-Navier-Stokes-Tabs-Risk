import axios from 'axios';
import type { 
  Instrument, 
  MarketDataPoint, 
  Signal, 
  TradeSuggestion, 
  RiskMetrics,
  StrategyConfig 
} from '../types';

const API_BASE_URL = '/api';

/**
 * Market Data Service
 * 
 * DATA SOURCES:
 * - Primary: CME Group via Interactive Brokers API (live & historical)
 * - Fallback: Polygon.io, Alpha Vantage, Yahoo Finance
 * - Continuous contracts: Custom roll logic based on volume/open interest
 * 
 * Supported instruments: 6E1!, 6J1!, 6B1!, 6A1!, 6C1!, 6S1!, 6N1! (front-month continuous)
 * Specific contracts: 6EU26, 6JU26, 6BU26, etc. (September 2026)
 */
export const marketDataService = {
  /**
   * Fetch real-time market data for an instrument
   */
  async getRealTimeData(symbol: string): Promise<MarketDataPoint[]> {
    try {
      const response = await axios.get(`${API_BASE_URL}/market-data/${symbol}/realtime`);
      return response.data;
    } catch (error) {
      console.warn(`Live data unavailable for ${symbol}, using simulated data`);
      // Return simulated data for development/demo
      return this.generateSimulatedData(symbol);
    }
  },

  /**
   * Fetch historical data for backtesting
   */
  async getHistoricalData(
    symbol: string, 
    startDate: number, 
    endDate: number,
    timeframe: '1m' | '5m' | '15m' | '1h' | '4h' | '1d' = '1d'
  ): Promise<MarketDataPoint[]> {
    try {
      const response = await axios.get(`${API_BASE_URL}/market-data/${symbol}/historical`, {
        params: { start: startDate, end: endDate, tf: timeframe }
      });
      return response.data;
    } catch (error) {
      console.error(`Historical data fetch failed for ${symbol}:`, error);
      throw error;
    }
  },

  /**
   * Get current contract details
   */
  async getCurrentContract(symbol: string): Promise<string> {
    try {
      const response = await axios.get(`${API_BASE_URL}/contracts/${symbol}/current`);
      return response.data.contractSymbol;
    } catch (error) {
      // Fallback to client-side calculation
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      let contractMonth: number;
      if (month <= 3) contractMonth = 3;
      else if (month <= 6) contractMonth = 6;
      else if (month <= 9) contractMonth = 9;
      else contractMonth = 12;
      
      const monthCodes: Record<number, string> = {
        1: 'F', 2: 'G', 3: 'H', 4: 'J', 5: 'K', 6: 'M',
        7: 'N', 8: 'Q', 9: 'U', 10: 'V', 11: 'X', 12: 'Z'
      };
      
      return `${symbol}${monthCodes[contractMonth]}${year.toString().slice(-2)}`;
    }
  },

  /**
   * Generate simulated market data for development/testing
   * Uses math.js for realistic price generation
   */
  generateSimulatedData(symbol: string, days: number = 252): MarketDataPoint[] {
    const basePrices: Record<string, number> = {
      '6E': 1.0850,
      '6J': 0.006750,
      '6B': 1.2650,
      '6A': 0.6580,
      '6C': 0.7350,
      '6S': 1.1250,
      '6N': 0.6120,
    };
    
    const basePrice = basePrices[symbol] || 1.0;
    const dailyVol = 0.008; // ~0.8% daily vol
    const data: MarketDataPoint[] = [];
    let currentPrice = basePrice;
    
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    
    for (let i = days; i >= 0; i--) {
      const timestamp = now - i * dayMs;
      const drift = (Math.random() - 0.5) * dailyVol;
      currentPrice = currentPrice * Math.exp(drift);
      
      const open = currentPrice * (1 + (Math.random() - 0.5) * 0.002);
      const high = Math.max(open, currentPrice) * (1 + Math.random() * 0.005);
      const low = Math.min(open, currentPrice) * (1 - Math.random() * 0.005);
      const volume = Math.floor(Math.random() * 100000) + 50000;
      
      data.push({
        timestamp,
        open,
        high,
        low,
        close: currentPrice,
        volume,
      });
    }
    
    return data;
  },
};

/**
 * Signal Service - communicates with Python backend
 */
export const signalService = {
  /**
   * Fetch active signals from screening engine
   */
  async getActiveSignals(): Promise<Signal[]> {
    try {
      const response = await axios.get(`${API_BASE_URL}/signals/active`);
      return response.data;
    } catch (error) {
      console.warn('Signal service unavailable, returning empty array');
      return [];
    }
  },

  /**
   * Submit trade suggestion for review
   */
  async submitTradeSuggestion(suggestion: Omit<TradeSuggestion, 'id' | 'createdAt'>): Promise<TradeSuggestion> {
    const response = await axios.post(`${API_BASE_URL}/trade-suggestions`, suggestion);
    return response.data;
  },

  /**
   * Get pending trade suggestions
   */
  async getPendingSuggestions(): Promise<TradeSuggestion[]> {
    const response = await axios.get(`${API_BASE_URL}/trade-suggestions/pending`);
    return response.data;
  },

  /**
   * Approve/reject trade suggestion
   */
  async reviewSuggestion(id: string, approved: boolean): Promise<TradeSuggestion> {
    const response = await axios.post(`${API_BASE_URL}/trade-suggestions/${id}/review`, { approved });
    return response.data;
  },
};

/**
 * Risk Management Service
 */
export const riskService = {
  /**
   * Get current portfolio risk metrics
   */
  async getRiskMetrics(): Promise<RiskMetrics> {
    try {
      const response = await axios.get(`${API_BASE_URL}/risk/metrics`);
      return response.data;
    } catch (error) {
      // Return default/simulated metrics
      return {
        portfolioVaR95: 125000,
        portfolioVaR99: 185000,
        expectedShortfall: 225000,
        maxDrawdown: 0.045,
        currentDrawdown: 0.012,
        totalExposure: 10000000,
        netExposure: 2500000,
        grossExposure: 12500000,
        leverage: 1.25,
        concentration: { '6E': 0.25, '6J': 0.20, '6B': 0.18, '6A': 0.15, '6C': 0.12, '6S': 0.10 },
      };
    }
  },

  /**
   * Calculate position size based on volatility targeting
   */
  calculatePositionSize(
    nav: number,
    targetVol: number,
    annualizedVol: number,
    instrumentValue: number
  ): number {
    // Inverse volatility targeting
    const maxPositionValue = (nav * targetVol) / annualizedVol;
    return Math.floor(maxPositionValue / instrumentValue);
  },
};

/**
 * Strategy Configuration Service
 */
export const strategyService = {
  /**
   * Get all strategy configurations
   */
  async getStrategies(): Promise<StrategyConfig[]> {
    try {
      const response = await axios.get(`${API_BASE_URL}/strategies`);
      return response.data;
    } catch (error) {
      // Return default strategies
      return [
        {
          id: 'HYP_01',
          name: 'Time-Series Momentum',
          hypothesisNumber: 1,
          enabled: true,
          paperIds: ['FX-004', 'FX-005', 'FX-012', 'FX-023'],
          markets: ['6E', '6J', '6B', '6A', '6C', '6S', '6N'],
          holdingPeriodDays: 63,
          costSensitivity: 'LOW',
          evidenceStrength: 'STRONG',
          requiresOptionsData: false,
          requiresNewsFeed: false,
        },
        {
          id: 'HYP_02',
          name: 'Carry with Crash-Vol Filter',
          hypothesisNumber: 2,
          enabled: true,
          paperIds: ['FX-006', 'FX-007', 'FX-015', 'FX-028'],
          markets: ['6J', '6A', '6N', '6S'],
          holdingPeriodDays: 42,
          costSensitivity: 'MEDIUM',
          evidenceStrength: 'MODERATE',
          requiresOptionsData: true,
          requiresNewsFeed: false,
        },
        {
          id: 'HYP_11',
          name: 'ML Regime Filter',
          hypothesisNumber: 11,
          enabled: true,
          paperIds: ['FX-091', 'FX-092', 'FX-093', 'AI-011'],
          markets: ['ALL'],
          holdingPeriodDays: 1,
          costSensitivity: 'LOW',
          evidenceStrength: 'MODERATE',
          requiresOptionsData: false,
          requiresNewsFeed: false,
        },
      ];
    }
  },
};
