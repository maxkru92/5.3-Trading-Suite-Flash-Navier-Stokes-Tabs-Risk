export interface Instrument {
  symbol: string;
  name: string;
  baseCurrency: string;
  quoteCurrency: string;
  tickSize: number;
  contractSize: number;
  exchange: string;
  category: 'major' | 'minor' | 'exotic';
  tradingHours: string;
  marginRequirement: number;
}

export interface MarketDataPoint {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  openInterest?: number;
}

export interface ContinuousContract {
  symbol: string;
  underlying: string;
  currentContract: string;
  rollDate?: number;
  data: MarketDataPoint[];
}

export interface Signal {
  id: string;
  strategy: string;
  instrument: string;
  direction: 'LONG' | 'SHORT';
  strength: number;
  entryPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  timestamp: number;
  features: Record<string, number>;
  paperIds: string[];
  regimeState: RegimeState;
}

export type RegimeState = 'TREND_UP' | 'TREND_DOWN' | 'RANGE' | 'HIGH_VOL' | 'LOW_VOL' | 'CRISIS';

export interface TradeSuggestion {
  id: string;
  signalId: string;
  instrument: string;
  strategy: string;
  direction: 'LONG' | 'SHORT';
  suggestedContracts: number;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  positionValue: number;
  riskAmount: number;
  expectedReturn: number;
  sharpeRatio?: number;
  rationale: string;
  features: Record<string, number>;
  paperIds: string[];
  status: 'PENDING_REVIEW' | 'APPROVED' | 'REJECTED' | 'EXECUTED' | 'CANCELLED';
  createdAt: number;
  reviewedAt?: number;
  executedAt?: number;
}

export interface RiskMetrics {
  portfolioVaR95: number;
  portfolioVaR99: number;
  expectedShortfall: number;
  maxDrawdown: number;
  currentDrawdown: number;
  totalExposure: number;
  netExposure: number;
  grossExposure: number;
  leverage: number;
  concentration: Record<string, number>;
}

export interface StrategyConfig {
  id: string;
  name: string;
  hypothesisNumber: number;
  enabled: boolean;
  paperIds: string[];
  markets: string[];
  holdingPeriodDays: number;
  costSensitivity: 'LOW' | 'MEDIUM' | 'HIGH';
  evidenceStrength: 'STRONG' | 'MODERATE' | 'WEAK';
  requiresOptionsData: boolean;
  requiresNewsFeed: boolean;
}

export interface DashboardState {
  instruments: Instrument[];
  signals: Signal[];
  tradeSuggestions: TradeSuggestion[];
  riskMetrics: RiskMetrics;
  strategies: StrategyConfig[];
  lastUpdate: number;
  connectionStatus: 'CONNECTED' | 'DISCONNECTED' | 'RECONNECTING';
}

// CME FX Futures - Complete List with Current Contracts (2026)
export const FX_INSTRUMENTS: Instrument[] = [
  // Major Currencies
  {
    symbol: '6E',
    name: 'Euro FX',
    baseCurrency: 'EUR',
    quoteCurrency: 'USD',
    tickSize: 0.00005,
    contractSize: 125000,
    exchange: 'CME',
    category: 'major',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 5500,
  },
  {
    symbol: '6J',
    name: 'Japanese Yen',
    baseCurrency: 'JPY',
    quoteCurrency: 'USD',
    tickSize: 0.0000005,
    contractSize: 12500000,
    exchange: 'CME',
    category: 'major',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 4950,
  },
  {
    symbol: '6B',
    name: 'British Pound',
    baseCurrency: 'GBP',
    quoteCurrency: 'USD',
    tickSize: 0.0001,
    contractSize: 62500,
    exchange: 'CME',
    category: 'major',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 7150,
  },
  {
    symbol: '6A',
    name: 'Australian Dollar',
    baseCurrency: 'AUD',
    quoteCurrency: 'USD',
    tickSize: 0.0001,
    contractSize: 100000,
    exchange: 'CME',
    category: 'major',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 3850,
  },
  {
    symbol: '6C',
    name: 'Canadian Dollar',
    baseCurrency: 'CAD',
    quoteCurrency: 'USD',
    tickSize: 0.00005,
    contractSize: 100000,
    exchange: 'CME',
    category: 'major',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 3300,
  },
  {
    symbol: '6S',
    name: 'Swiss Franc',
    baseCurrency: 'CHF',
    quoteCurrency: 'USD',
    tickSize: 0.0001,
    contractSize: 125000,
    exchange: 'CME',
    category: 'major',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 5500,
  },
  {
    symbol: '6N',
    name: 'New Zealand Dollar',
    baseCurrency: 'NZD',
    quoteCurrency: 'USD',
    tickSize: 0.0001,
    contractSize: 100000,
    exchange: 'CME',
    category: 'major',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 3300,
  },
  // Micro Contracts
  {
    symbol: 'M6E',
    name: 'Micro Euro FX',
    baseCurrency: 'EUR',
    quoteCurrency: 'USD',
    tickSize: 0.00005,
    contractSize: 12500,
    exchange: 'CME',
    category: 'minor',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 550,
  },
  {
    symbol: 'M6J',
    name: 'Micro Japanese Yen',
    baseCurrency: 'JPY',
    quoteCurrency: 'USD',
    tickSize: 0.0000005,
    contractSize: 1250000,
    exchange: 'CME',
    category: 'minor',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 495,
  },
  {
    symbol: 'M6B',
    name: 'Micro British Pound',
    baseCurrency: 'GBP',
    quoteCurrency: 'USD',
    tickSize: 0.0001,
    contractSize: 6250,
    exchange: 'CME',
    category: 'minor',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 715,
  },
  {
    symbol: 'M6A',
    name: 'Micro Australian Dollar',
    baseCurrency: 'AUD',
    quoteCurrency: 'USD',
    tickSize: 0.0001,
    contractSize: 10000,
    exchange: 'CME',
    category: 'minor',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 385,
  },
  {
    symbol: 'M6C',
    name: 'Micro Canadian Dollar',
    baseCurrency: 'CAD',
    quoteCurrency: 'USD',
    tickSize: 0.00005,
    contractSize: 10000,
    exchange: 'CME',
    category: 'minor',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 330,
  },
  {
    symbol: 'M6S',
    name: 'Micro Swiss Franc',
    baseCurrency: 'CHF',
    quoteCurrency: 'USD',
    tickSize: 0.0001,
    contractSize: 12500,
    exchange: 'CME',
    category: 'minor',
    tradingHours: '17:00-16:00 CT',
    marginRequirement: 550,
  },
];

/**
 * Get current futures contract code for a given month/year
 * @param symbol Base symbol (e.g., '6E')
 * @param year Year (e.g., 2026)
 * @param month Month (1-12)
 * @returns Full contract symbol (e.g., '6EU26' for September 2026)
 */
export function getContractSymbol(symbol: string, year: number, month: number): string {
  const monthCodes = {
    1: 'F', 2: 'G', 3: 'H', 4: 'J', 5: 'K', 6: 'M',
    7: 'N', 8: 'Q', 9: 'U', 10: 'V', 11: 'X', 12: 'Z'
  };
  const monthCode = monthCodes[month as keyof typeof monthCodes];
  const yearSuffix = year.toString().slice(-2);
  return `${symbol}${monthCode}${yearSuffix}`;
}

/**
 * Get the current active contract based on roll schedule
 * Currency futures typically roll: March (H), June (M), September (U), December (Z)
 */
export function getCurrentContract(symbol: string): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  
  // Determine current quarter contract
  let contractMonth: number;
  if (month <= 3) contractMonth = 3;
  else if (month <= 6) contractMonth = 6;
  else if (month <= 9) contractMonth = 9;
  else contractMonth = 12;
  
  // Adjust year if we're past the contract month
  let contractYear = year;
  if (month > contractMonth) {
    contractYear = year + 1;
  }
  
  return getContractSymbol(symbol, contractYear, contractMonth);
}

// Example: Current contracts for Q3 2026 (September)
export const CURRENT_CONTRACTS_2026_Q3 = FX_INSTRUMENTS.map(inst => ({
  ...inst,
  currentContract: getContractSymbol(inst.symbol, 2026, 9), // September 2026 (U26)
  continuousSymbol: `${inst.symbol}1!`, // Continuous front-month
}));
