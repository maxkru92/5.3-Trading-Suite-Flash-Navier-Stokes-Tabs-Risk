/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Krupp Capital Dark Palette - SKILL compliant
        'kc-bg': '#0a0e17',
        'kc-surface': '#151a25',
        'kc-surface-light': '#1e2633',
        'kc-border': '#2d3748',
        'kc-text': '#e2e8f0',
        'kc-text-muted': '#94a3b8',
        'kc-primary': '#3b82f6',
        'kc-primary-hover': '#2563eb',
        'kc-success': '#10b981',
        'kc-danger': '#ef4444',
        'kc-warning': '#f59e0b',
        'kc-accent': '#8b5cf6',
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
    },
  },
  plugins: [],
}
