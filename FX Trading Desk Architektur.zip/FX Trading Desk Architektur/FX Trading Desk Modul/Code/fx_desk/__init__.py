"""
FX Trading Desk Modul - Institutional-Grade FX Trading Platform

Krupp Capital Global Macro Desk
Version: 1.0.0

Architecture Overview:
======================
This module implements a complete institutional-grade FX trading platform based on
the 12-strategy hypothesis framework from the Krupp Capital Master Bibliography.

Key Design Principles:
- All price calculations use logarithmic returns (NEVER simple percentage changes)
- Position sizing is exclusively volatility-based (inverse vol-targeting)
- ML models serve ONLY as filters, never as direct alpha generators
- No reinforcement learning in production (per AI-Sonderanalyse AI-016, AI-017)
- Explicit cost modeling (slippage, commissions, roll costs) required
- Walk-forward validation mandatory before live activation

Strategy Hypotheses (with Paper References):
============================================
1. Time-Series Momentum in Currency Futures - FX-004, FX-005, FX-012, FX-023
2. Carry mit Crash-Vol-Filter - FX-006, FX-007, FX-018, FX-024, FX-054
3. Currency-Value/PPP als langsamer Drift-Faktor - FX-001, FX-002, FX-008, FX-013
4. COT-Positionierungs-Extremsignale - FX-025, FX-026, FX-027, FX-060
5. Volatility-Risk-Premium-Strategien (IV vs. RV) - FX-033, FX-034, FX-035, FX-055
6. FX-Options-Skew/Smile/Risk-Reversal-Signale - FX-036, FX-037, FX-038, FX-056
7. Safe-Haven/JPY-Carry-Unwind-Regime - FX-041, FX-042, FX-067, FX-071
8. Calendar-/Termstruktur-Spreads in Currency Futures - FX-043, FX-044, FX-061
9. Mean Reversion unter Liquiditäts-/Regimebedingungen - FX-045, FX-046, FX-062
10. Event-/Zentralbank-Regime-Handel mit NLP-Filter - FX-081, FX-082, AI-018-AI-022
11. ML-basierte Regimeklassifikation als Filter - FX-091-FX-094, AI-011
12. Volatilitäts-/Verteilungsprognosen (Deep-Learning) als Risk-Input - AI-007-AI-010

AI/ML Usage Guidelines (per AI-Sonderanalyse):
==============================================
✓ ALLOWED: Classical ML as filters, HMM/Markov-Switching (FX-091-FX-094, AI-011),
           Deep-Learning-Volatility forecasts as risk input (AI-007-AI-010)
✗ FORBIDDEN: RL on tick/orderbook data (AI-016, AI-017), pure price forecasting
             deep nets without overfitting protection (AI-003-AI-006, AI-012-AI-015),
             news arbitrage without industrial feeds (AI-018-AI-022)
"""

__version__ = "1.0.0"
__author__ = "Krupp Capital Global Macro Desk"

from .config.instruments import InstrumentConfig, INSTRUMENT_REGISTRY
from .config.strategies import StrategyConfig, STRATEGY_REGISTRY, StrategyHypothesis
from .data.features import FeatureEngine, MarketContext, RegimeState
from .strategies.base import Strategy, Signal
from .suggestions.trade_suggestion import TradeSuggestion, SuggestionStatus

__all__ = [
    "InstrumentConfig",
    "INSTRUMENT_REGISTRY",
    "StrategyConfig",
    "STRATEGY_REGISTRY",
    "StrategyHypothesis",
    "FeatureEngine",
    "MarketContext",
    "RegimeState",
    "Strategy",
    "Signal",
    "TradeSuggestion",
    "SuggestionStatus",
]
