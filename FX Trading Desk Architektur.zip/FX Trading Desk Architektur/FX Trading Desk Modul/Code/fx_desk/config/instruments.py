"""
Instrument Configuration for FX Currency Futures.

Defines all tradable instruments including standard CME currency futures
and micro contracts with contract specifications, tick values, and margin requirements.

Literature Reference: FX-001, FX-002 (CME FX Futures specifications)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum


class AssetClass(Enum):
    """Asset class enumeration."""
    FX_FUTURE = "fx_future"
    FX_MICRO = "fx_micro"
    FX_OPTION = "fx_option"


@dataclass
class InstrumentConfig:
    """
    Configuration for a single FX instrument.
    
    Attributes:
        symbol: CME ticker symbol (e.g., '6E' for EUR/USD)
        name: Human-readable name
        asset_class: Type of instrument (future, micro, option)
        base_currency: Base currency of the pair
        quote_currency: Quote currency of the pair
        contract_size: Size of one contract in base currency units
        tick_size: Minimum price increment
        tick_value: USD value per tick
        initial_margin: Initial margin requirement per contract (USD)
        maintenance_margin: Maintenance margin per contract (USD)
        trading_hours: CME Globex trading hours
        roll_days_before_expiry: Days before expiry to roll position
        is_active: Whether instrument is currently tradable
    """
    symbol: str
    name: str
    asset_class: AssetClass
    base_currency: str
    quote_currency: str
    contract_size: float
    tick_size: float
    tick_value: float
    initial_margin: float
    maintenance_margin: float
    trading_hours: str = "Sunday 17:00 - Friday 16:00 CT"
    roll_days_before_expiry: int = 5
    is_active: bool = True
    
    # Optional fields for options
    option_type: Optional[str] = None  # 'call' or 'put'
    strike: Optional[float] = None
    expiry_month: Optional[str] = None
    
    def __post_init__(self) -> None:
        """Validate instrument configuration."""
        if self.contract_size <= 0:
            raise ValueError(f"Contract size must be positive: {self.symbol}")
        if self.tick_size <= 0:
            raise ValueError(f"Tick size must be positive: {self.symbol}")
        if self.tick_value <= 0:
            raise ValueError(f"Tick value must be positive: {self.symbol}")
        if self.initial_margin < self.maintenance_margin:
            raise ValueError(f"Initial margin must >= maintenance margin: {self.symbol}")
    
    @property
    def notional_value(self) -> float:
        """Calculate notional value of one contract at parity."""
        return self.contract_size
    
    @property
    def leverage_factor(self) -> float:
        """Calculate effective leverage factor based on margin."""
        if self.initial_margin <= 0:
            return 1.0
        return self.notional_value / self.initial_margin
    
    def get_contract_code(self, year: int, month: int) -> str:
        """
        Generate CME futures contract code for given year/month.
        
        Args:
            year: Contract year (e.g., 2024)
            month: Contract month (1-12)
            
        Returns:
            CME contract code (e.g., '6EH4' for March 2024 EUR/USD)
        """
        month_codes = {
            1: 'F', 2: 'G', 3: 'H', 4: 'J', 5: 'K', 6: 'M',
            7: 'N', 8: 'Q', 9: 'U', 10: 'V', 11: 'X', 12: 'Z'
        }
        if month not in month_codes:
            raise ValueError(f"Invalid month: {month}")
        
        # Year code is last digit
        year_code = year % 10
        month_code = month_codes[month]
        
        return f"{self.symbol}{month_code}{year_code}"
    
    def __str__(self) -> str:
        """Human-readable string representation."""
        return f"{self.symbol} ({self.name})"


# =============================================================================
# INSTRUMENT REGISTRY - CME Currency Futures
# =============================================================================

# Standard Currency Futures (Ticker prefix: 6)
EUR_USD = InstrumentConfig(
    symbol="6E",
    name="Euro FX",
    asset_class=AssetClass.FX_FUTURE,
    base_currency="EUR",
    quote_currency="USD",
    contract_size=125_000,  # €125,000
    tick_size=0.00005,      # 0.5 pip
    tick_value=6.25,        # $6.25 per tick
    initial_margin=4950,    # CME initial margin (approximate)
    maintenance_margin=4500,
    roll_days_before_expiry=5,
    is_active=True
)

JPY_USD = InstrumentConfig(
    symbol="6J",
    name="Japanese Yen",
    asset_class=AssetClass.FX_FUTURE,
    base_currency="JPY",
    quote_currency="USD",
    contract_size=12_500_000,  # ¥12,500,000
    tick_size=0.0000005,       # 0.00005 cents
    tick_value=6.25,
    initial_margin=3850,
    maintenance_margin=3500,
    roll_days_before_expiry=5,
    is_active=True
)

GBP_USD = InstrumentConfig(
    symbol="6B",
    name="British Pound",
    asset_class=AssetClass.FX_FUTURE,
    base_currency="GBP",
    quote_currency="USD",
    contract_size=62_500,  # £62,500
    tick_size=0.0001,      # 1 pip
    tick_value=6.25,
    initial_margin=4400,
    maintenance_margin=4000,
    roll_days_before_expiry=5,
    is_active=True
)

AUD_USD = InstrumentConfig(
    symbol="6A",
    name="Australian Dollar",
    asset_class=AssetClass.FX_FUTURE,
    base_currency="AUD",
    quote_currency="USD",
    contract_size=100_000,  # A$100,000
    tick_size=0.00005,      # 0.5 pip
    tick_value=5.00,
    initial_margin=3300,
    maintenance_margin=3000,
    roll_days_before_expiry=5,
    is_active=True
)

CAD_USD = InstrumentConfig(
    symbol="6C",
    name="Canadian Dollar",
    asset_class=AssetClass.FX_FUTURE,
    base_currency="CAD",
    quote_currency="USD",
    contract_size=100_000,  # C$100,000
    tick_size=0.00005,      # 0.5 pip
    tick_value=5.00,
    initial_margin=2750,
    maintenance_margin=2500,
    roll_days_before_expiry=5,
    is_active=True
)

CHF_USD = InstrumentConfig(
    symbol="6S",
    name="Swiss Franc",
    asset_class=AssetClass.FX_FUTURE,
    base_currency="CHF",
    quote_currency="USD",
    contract_size=125_000,  # CHF 125,000
    tick_size=0.00005,      # 0.5 pip
    tick_value=6.25,
    initial_margin=3575,
    maintenance_margin=3250,
    roll_days_before_expiry=5,
    is_active=True
)

MXN_USD = InstrumentConfig(
    symbol="6N",
    name="Mexican Peso",
    asset_class=AssetClass.FX_FUTURE,
    base_currency="MXN",
    quote_currency="USD",
    contract_size=500_000,  # MXN 500,000
    tick_size=0.0000025,    # 0.00025 cents
    tick_value=6.25,
    initial_margin=2200,
    maintenance_margin=2000,
    roll_days_before_expiry=5,
    is_active=True
)

# Micro Currency Futures (Ticker prefix: M6)
MICRO_EUR_USD = InstrumentConfig(
    symbol="M6E",
    name="Micro Euro FX",
    asset_class=AssetClass.FX_MICRO,
    base_currency="EUR",
    quote_currency="USD",
    contract_size=12_500,   # €12,500 (1/10 of standard)
    tick_size=0.00005,
    tick_value=0.625,       # $0.625 per tick (1/10 of standard)
    initial_margin=495,     # 1/10 of standard
    maintenance_margin=450,
    roll_days_before_expiry=5,
    is_active=True
)

MICRO_JPY_USD = InstrumentConfig(
    symbol="M6J",
    name="Micro Japanese Yen",
    asset_class=AssetClass.FX_MICRO,
    base_currency="JPY",
    quote_currency="USD",
    contract_size=1_250_000,
    tick_size=0.0000005,
    tick_value=0.625,
    initial_margin=385,
    maintenance_margin=350,
    roll_days_before_expiry=5,
    is_active=True
)

MICRO_GBP_USD = InstrumentConfig(
    symbol="M6B",
    name="Micro British Pound",
    asset_class=AssetClass.FX_MICRO,
    base_currency="GBP",
    quote_currency="USD",
    contract_size=6_250,
    tick_size=0.0001,
    tick_value=0.625,
    initial_margin=440,
    maintenance_margin=400,
    roll_days_before_expiry=5,
    is_active=True
)

MICRO_AUD_USD = InstrumentConfig(
    symbol="M6A",
    name="Micro Australian Dollar",
    asset_class=AssetClass.FX_MICRO,
    base_currency="AUD",
    quote_currency="USD",
    contract_size=10_000,
    tick_size=0.00005,
    tick_value=0.50,
    initial_margin=330,
    maintenance_margin=300,
    roll_days_before_expiry=5,
    is_active=True
)

MICRO_CAD_USD = InstrumentConfig(
    symbol="M6C",
    name="Micro Canadian Dollar",
    asset_class=AssetClass.FX_MICRO,
    base_currency="CAD",
    quote_currency="USD",
    contract_size=10_000,
    tick_size=0.00005,
    tick_value=0.50,
    initial_margin=275,
    maintenance_margin=250,
    roll_days_before_expiry=5,
    is_active=True
)

MICRO_CHF_USD = InstrumentConfig(
    symbol="M6S",
    name="Micro Swiss Franc",
    asset_class=AssetClass.FX_MICRO,
    base_currency="CHF",
    quote_currency="USD",
    contract_size=12_500,
    tick_size=0.00005,
    tick_value=0.625,
    initial_margin=358,
    maintenance_margin=325,
    roll_days_before_expiry=5,
    is_active=True
)

MICRO_MXN_USD = InstrumentConfig(
    symbol="M6N",
    name="Micro Mexican Peso",
    asset_class=AssetClass.FX_MICRO,
    base_currency="MXN",
    quote_currency="USD",
    contract_size=50_000,
    tick_size=0.0000025,
    tick_value=0.625,
    initial_margin=220,
    maintenance_margin=200,
    roll_days_before_expiry=5,
    is_active=True
)


# =============================================================================
# INSTRUMENT REGISTRY DICTIONARY
# =============================================================================

INSTRUMENT_REGISTRY: Dict[str, InstrumentConfig] = {
    # Standard Futures
    "6E": EUR_USD,
    "6J": JPY_USD,
    "6B": GBP_USD,
    "6A": AUD_USD,
    "6C": CAD_USD,
    "6S": CHF_USD,
    "6N": MXN_USD,
    # Micro Futures
    "M6E": MICRO_EUR_USD,
    "M6J": MICRO_JPY_USD,
    "M6B": MICRO_GBP_USD,
    "M6A": MICRO_AUD_USD,
    "M6C": MICRO_CAD_USD,
    "M6S": MICRO_CHF_USD,
    "M6N": MICRO_MXN_USD,
}


def get_instrument(symbol: str) -> InstrumentConfig:
    """
    Retrieve instrument configuration by symbol.
    
    Args:
        symbol: Instrument symbol (e.g., '6E', 'M6J')
        
    Returns:
        InstrumentConfig for the requested symbol
        
    Raises:
        KeyError: If symbol not found in registry
    """
    if symbol not in INSTRUMENT_REGISTRY:
        available = ", ".join(sorted(INSTRUMENT_REGISTRY.keys()))
        raise KeyError(
            f"Instrument '{symbol}' not found. Available: {available}"
        )
    return INSTRUMENT_REGISTRY[symbol]


def get_active_instruments() -> List[InstrumentConfig]:
    """Return list of all currently active instruments."""
    return [inst for inst in INSTRUMENT_REGISTRY.values() if inst.is_active]


def get_instruments_by_asset_class(asset_class: AssetClass) -> List[InstrumentConfig]:
    """
    Filter instruments by asset class.
    
    Args:
        asset_class: AssetClass enum value
        
    Returns:
        List of matching instruments
    """
    return [
        inst for inst in INSTRUMENT_REGISTRY.values()
        if inst.asset_class == asset_class and inst.is_active
    ]


def get_currency_pairs(base_currency: Optional[str] = None, 
                       quote_currency: Optional[str] = None) -> List[InstrumentConfig]:
    """
    Filter instruments by currency pair components.
    
    Args:
        base_currency: Optional base currency filter (e.g., 'EUR')
        quote_currency: Optional quote currency filter (e.g., 'USD')
        
    Returns:
        List of matching instruments
    """
    result = []
    for inst in INSTRUMENT_REGISTRY.values():
        if not inst.is_active:
            continue
        if base_currency and inst.base_currency != base_currency:
            continue
        if quote_currency and inst.quote_currency != quote_currency:
            continue
        result.append(inst)
    return result
