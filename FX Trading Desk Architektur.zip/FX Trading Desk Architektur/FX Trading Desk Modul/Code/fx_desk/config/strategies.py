"""
Strategy Configuration Registry.

Defines the 12 strategy hypotheses from the Krupp Capital Master Bibliography
with their associated paper references, parameters, and metadata.

Literature References:
- FX-001 to FX-100: Base FX research papers
- AI-001 to AI-022: ML/AI research papers
- Strategy Synthesis: 12 hypothesis framework document
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum


class StrategyCategory(Enum):
    """Strategy category enumeration based on Master Bibliography tags."""
    MOMENTUM = "momentum"
    CARRY = "carry"
    VALUE = "value"
    POSITIONING = "positioning"
    VOLATILITY = "volatility"
    OPTIONS = "options"
    REGIME = "regime"
    SPREAD = "spread"
    MEAN_REVERSION = "mean_reversion"
    EVENT = "event"
    ML_FILTER = "ml_filter"


class EvidenceStrength(Enum):
    """Evidence strength rating from synthesis document."""
    STRONG = "strong"       # Multiple papers, robust empirical evidence
    MODERATE = "moderate"   # Some papers, reasonable evidence
    EMERGING = "emerging"   # Limited papers, preliminary evidence
    SPECULATIVE = "speculative"  # Theoretical, limited empirical support


@dataclass
class StrategyHypothesis:
    """
    Complete definition of a trading strategy hypothesis.
    
    Attributes:
        id: Hypothesis ID (HYP_01 to HYP_12)
        name: Human-readable strategy name
        description: Detailed strategy description
        category: Strategy category
        paper_ids: List of referenced paper IDs from Master Bibliography
        instruments: List of suitable instruments for this strategy
        signal_features: Required features/signals for strategy
        regime_filter: Regime conditions required for strategy to be active
        holding_period: Expected holding period (e.g., 'days', 'weeks')
        cost_sensitivity: Sensitivity to transaction costs/slippage
        evidence_strength: Strength of empirical evidence
        main_error_source: Primary source of strategy failure
        validation_step: Next validation step required
    """
    id: str
    name: str
    description: str
    category: StrategyCategory
    paper_ids: List[str]
    instruments: List[str]
    signal_features: List[str]
    regime_filter: Optional[str]
    holding_period: str
    cost_sensitivity: str  # 'low', 'medium', 'high'
    evidence_strength: EvidenceStrength
    main_error_source: str
    validation_step: str
    
    def __post_init__(self) -> None:
        """Validate hypothesis configuration."""
        if not self.id.startswith("HYP_"):
            raise ValueError(f"Hypothesis ID must start with 'HYP_': {self.id}")
        if not self.paper_ids:
            raise ValueError(f"Strategy {self.id} must have at least one paper reference")


@dataclass
class StrategyConfig:
    """
    Runtime configuration for a strategy instance.
    
    Attributes:
        hypothesis: Reference to StrategyHypothesis
        enabled: Whether strategy is currently active
        priority: Execution priority (lower = higher priority)
        max_position_pct: Maximum position size as % of NAV
        target_volatility: Target annualized volatility for vol-scaling
        stop_loss_pct: Stop loss as % of entry price
        take_profit_pct: Take profit as % of entry price
        min_signal_strength: Minimum signal strength to generate trade
        params: Additional strategy-specific parameters
    """
    hypothesis: StrategyHypothesis
    enabled: bool = True
    priority: int = 5
    max_position_pct: float = 0.10  # 10% of NAV per position
    target_volatility: float = 0.12  # 12% annualized vol target
    stop_loss_pct: float = 0.02  # 2% stop loss
    take_profit_pct: float = 0.04  # 4% take profit
    min_signal_strength: float = 0.5  # Minimum signal strength threshold
    params: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self) -> None:
        """Validate strategy configuration."""
        if not 0 < self.max_position_pct <= 1:
            raise ValueError("max_position_pct must be between 0 and 1")
        if not 0 < self.target_volatility <= 1:
            raise ValueError("target_volatility must be between 0 and 1")
        if self.stop_loss_pct <= 0:
            raise ValueError("stop_loss_pct must be positive")
        if self.take_profit_pct <= 0:
            raise ValueError("take_profit_pct must be positive")
        if not 0 <= self.min_signal_strength <= 1:
            raise ValueError("min_signal_strength must be between 0 and 1")


# =============================================================================
# STRATEGY HYPOTHESES - 12 Strategies from Master Bibliography
# =============================================================================

# HYP_01: Time-Series Momentum in Currency Futures
HYP_01_MOMENTUM = StrategyHypothesis(
    id="HYP_01",
    name="Time-Series Momentum in Currency Futures",
    description=(
        "Exploits persistent trends in FX futures markets using lookback periods "
        "of 1-12 months. Based on momentum factor premium documented extensively "
        "in FX literature."
    ),
    category=StrategyCategory.MOMENTUM,
    paper_ids=["FX-004", "FX-005", "FX-012", "FX-023"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
    signal_features=[
        "log_return_21d", "log_return_63d", "log_return_126d", "log_return_252d",
        "momentum_score", "trend_direction"
    ],
    regime_filter="TREND or NEUTRAL",
    holding_period="weeks to months",
    cost_sensitivity="low",
    evidence_strength=EvidenceStrength.STRONG,
    main_error_source="Regime change from trend to mean-reversion",
    validation_step="Walk-forward test across multiple market regimes"
)

# HYP_02: Carry mit Crash-Vol-Filter
HYP_02_CARRY_CRASH = StrategyHypothesis(
    id="HYP_02",
    name="Carry mit Crash-Vol-Filter",
    description=(
        "Traditional carry trade enhanced with volatility-based crash protection. "
        "Uses skew, risk-reversal, and variance risk premium to filter high-risk "
        "carry positions during stress periods."
    ),
    category=StrategyCategory.CARRY,
    paper_ids=["FX-006", "FX-007", "FX-018", "FX-024", "FX-054"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
    signal_features=[
        "interest_rate_differential", "carry_score", "skew_25d",
        "risk_reversal_25d", "variance_risk_premium", "crash_probability"
    ],
    regime_filter="RISK_ON and NOT CRASH",
    holding_period="months",
    cost_sensitivity="medium",
    evidence_strength=EvidenceStrength.STRONG,
    main_error_source="Sudden risk-off events / carry unwinds",
    validation_step="Stress test with 2008-style crash scenarios"
)

# HYP_03: Currency-Value/PPP als langsamer Drift-Faktor
HYP_03_VALUE_PPP = StrategyHypothesis(
    id="HYP_03",
    name="Currency-Value/PPP als langsamer Drift-Faktor",
    description=(
        "Long-term value strategy based on purchasing power parity deviations. "
        "Acts as slow drift factor with multi-year holding periods."
    ),
    category=StrategyCategory.VALUE,
    paper_ids=["FX-001", "FX-002", "FX-008", "FX-013"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S"],
    signal_features=[
        "ppp_deviation", "real_exchange_rate", "cpi_differential",
        "value_zscore", "fair_value_gap"
    ],
    regime_filter="NEUTRAL or TREND",
    holding_period="quarters to years",
    cost_sensitivity="low",
    evidence_strength=EvidenceStrength.MODERATE,
    main_error_source="Extended periods of PPP deviation persistence",
    validation_step="Multi-decade backtest with inflation adjustments"
)

# HYP_04: COT-Positionierungs-Extremsignale
HYP_04_COT_POSITIONING = StrategyHypothesis(
    id="HYP_04",
    name="COT-Positionierungs-Extremsignale",
    description=(
        "Contrarian strategy based on extreme positioning in CFTC Commitment of "
        "Traders reports. Signals when speculator positioning reaches historical extremes."
    ),
    category=StrategyCategory.POSITIONING,
    paper_ids=["FX-025", "FX-026", "FX-027", "FX-060"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
    signal_features=[
        "cot_commercial_net", "cot_speculator_net", "cot_extremes_zscore",
        "positioning_percentile", "crowding_indicator"
    ],
    regime_filter="NOT CRASH",
    holding_period="weeks to months",
    cost_sensitivity="medium",
    evidence_strength=EvidenceStrength.MODERATE,
    main_error_source="Extended trending markets ignoring positioning extremes",
    validation_step="Real-time COT data integration test"
)

# HYP_05: Volatility-Risk-Premium-Strategien (IV vs. RV)
HYP_05_VOL_RISK_PREMIUM = StrategyHypothesis(
    id="HYP_05",
    name="Volatility-Risk-Premium-Strategien (IV vs. RV)",
    description=(
        "Exploits the difference between implied volatility (IV) and realized "
        "volatility (RV). Typically short volatility when IV > RV."
    ),
    category=StrategyCategory.VOLATILITY,
    paper_ids=["FX-033", "FX-034", "FX-035", "FX-055"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S"],
    signal_features=[
        "implied_vol_1m", "realized_vol_21d", "iv_rv_spread",
        "variance_risk_premium", "vol_convexity"
    ],
    regime_filter="RISK_ON and LOW_STRESS",
    holding_period="days to weeks",
    cost_sensitivity="high",
    evidence_strength=EvidenceStrength.MODERATE,
    main_error_source="Volatility spikes during stress events",
    validation_step="Tail risk analysis and stress testing"
)

# HYP_06: FX-Options-Skew/Smile/Risk-Reversal-Signale
HYP_06_OPTIONS_SKEW = StrategyHypothesis(
    id="HYP_06",
    name="FX-Options-Skew/Smile/Risk-Reversal-Signale",
    description=(
        "Uses options market information including skew, smile patterns, and "
        "risk-reversals to infer directional bias and tail risk sentiment."
    ),
    category=StrategyCategory.OPTIONS,
    paper_ids=["FX-036", "FX-037", "FX-038", "FX-056"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S"],
    signal_features=[
        "skew_25d", "smile_curvature", "risk_reversal_25d",
        "put_call_ratio", "tail_risk_premium"
    ],
    regime_filter="NEUTRAL",
    holding_period="days to weeks",
    cost_sensitivity="high",
    evidence_strength=EvidenceStrength.MODERATE,
    main_error_source="Liquidity gaps in options markets",
    validation_step="Options chain data quality verification"
)

# HYP_07: Safe-Haven/JPY-Carry-Unwind-Regime
HYP_07_SAFE_HAVEN = StrategyHypothesis(
    id="HYP_07",
    name="Safe-Haven/JPY-Carry-Unwind-Regime",
    description=(
        "Identifies and trades safe-haven flows, particularly JPY appreciation "
        "during carry unwind episodes. Defensive strategy activated during stress."
    ),
    category=StrategyCategory.REGIME,
    paper_ids=["FX-041", "FX-042", "FX-067", "FX-071"],
    instruments=["6J", "6S", "6E"],
    signal_features=[
        "vix_level", "credit_spread_change", "equity_correlation",
        "jpy_carry_unwind_signal", "safe_haven_flow_indicator"
    ],
    regime_filter="RISK_OFF or CRASH",
    holding_period="days to weeks",
    cost_sensitivity="medium",
    evidence_strength=EvidenceStrength.MODERATE,
    main_error_source="False signals during contained risk-off events",
    validation_step="Event study around major risk-off episodes"
)

# HYP_08: Calendar-/Termstruktur-Spreads in Currency Futures
HYP_08_CALENDAR_SPREAD = StrategyHypothesis(
    id="HYP_08",
    name="Calendar-/Termstruktur-Spreads in Currency Futures",
    description=(
        "Exploits term structure anomalies in currency futures calendar spreads. "
        "Based on interest rate differential expectations and roll yield."
    ),
    category=StrategyCategory.SPREAD,
    paper_ids=["FX-043", "FX-044", "FX-061"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
    signal_features=[
        "calendar_spread_near_far", "term_structure_slope",
        "roll_yield", "forward_curve_shape"
    ],
    regime_filter="NEUTRAL or TREND",
    holding_period="weeks",
    cost_sensitivity="low",
    evidence_strength=EvidenceStrength.EMERGING,
    main_error_source="Central bank policy surprises affecting forward curve",
    validation_step="Roll period optimization across contracts"
)

# HYP_09: Mean Reversion unter Liquiditäts-/Regimebedingungen
HYP_09_MEAN_REVERSION = StrategyHypothesis(
    id="HYP_09",
    name="Mean Reversion unter Liquiditäts-/Regimebedingungen",
    description=(
        "Mean reversion strategy only active under specific liquidity and regime "
        "conditions. Avoids catching falling knives during strong trends."
    ),
    category=StrategyCategory.MEAN_REVERSION,
    paper_ids=["FX-045", "FX-046", "FX-062"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S"],
    signal_features=[
        "rsi_14d", "bollinger_position", "mean_reversion_zscore",
        "liquidity_score", "range_bound_indicator"
    ],
    regime_filter="RANGE and HIGH_LIQUIDITY",
    holding_period="days to weeks",
    cost_sensitivity="medium",
    evidence_strength=EvidenceStrength.EMERGING,
    main_error_source="Trend continuation mistaken for mean reversion",
    validation_step="Regime classification accuracy improvement"
)

# HYP_10: Event-/Zentralbank-Regime-Handel mit NLP-Filter
HYP_10_EVENT_NLP = StrategyHypothesis(
    id="HYP_10",
    name="Event-/Zentralbank-Regime-Handel mit NLP-Filter",
    description=(
        "Trades around central bank events and economic releases using NLP "
        "to analyze statements and news sentiment. REQUIRES industrial news feeds."
    ),
    category=StrategyCategory.EVENT,
    paper_ids=["FX-081", "FX-082", "AI-018", "AI-019", "AI-020", "AI-021", "AI-022"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
    signal_features=[
        "nlp_sentiment_score", "hawkish_dovish_index", "surprise_index",
        "event_proximity", "news_flow_intensity"
    ],
    regime_filter="EVENT_WINDOW",
    holding_period="hours to days",
    cost_sensitivity="high",
    evidence_strength=EvidenceStrength.SPECULATIVE,
    main_error_source="Latency disadvantage vs institutional players",
    validation_step="REQUIRES industrial news feed infrastructure"
)

# HYP_11: ML-basierte Regimeklassifikation als Filter
HYP_11_ML_REGIME = StrategyHypothesis(
    id="HYP_11",
    name="ML-basierte Regimeklassifikation als Filter",
    description=(
        "Hidden Markov Model and classical ML classifiers to identify market regimes. "
        "USED ONLY AS FILTER for other strategies, NEVER as direct alpha source. "
        "Per AI-Sonderanalyse: Robust use of HMM/Markov-Switching (FX-091-FX-094, AI-011)."
    ),
    category=StrategyCategory.ML_FILTER,
    paper_ids=["FX-091", "FX-092", "FX-093", "FX-094", "AI-011"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
    signal_features=[
        "hmm_regime_state", "regime_probability", "volatility_cluster",
        "correlation_regime", "trend_strength_classifier"
    ],
    regime_filter=None,  # This IS the regime filter
    holding_period="N/A - Filter only",
    cost_sensitivity="N/A",
    evidence_strength=EvidenceStrength.MODERATE,
    main_error_source="Overfitting to historical regime patterns",
    validation_step="Out-of-sample regime classification accuracy"
)

# HYP_12: Volatilitäts-/Verteilungsprognosen (Deep-Learning) als Risk-Input
HYP_12_DL_VOL_FORECAST = StrategyHypothesis(
    id="HYP_12",
    name="Volatilitäts-/Verteilungsprognosen als Risk-Input",
    description=(
        "Deep learning models for volatility and return distribution forecasting. "
        "Used ONLY as risk management input, NOT for direct signal generation. "
        "Per AI-Sonderanalyse: Deep-Learning-VolForecast (AI-007-AI-010)."
    ),
    category=StrategyCategory.ML_FILTER,
    paper_ids=["AI-007", "AI-008", "AI-009", "AI-010"],
    instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
    signal_features=[
        "dl_vol_forecast_1d", "dl_vol_forecast_5d", "distribution_skew",
        "distribution_kurtosis", "tail_risk_estimate"
    ],
    regime_filter=None,  # Risk input only
    holding_period="N/A - Risk input only",
    cost_sensitivity="N/A",
    evidence_strength=EvidenceStrength.EMERGING,
    main_error_source="Distribution shift in live markets",
    validation_step="Volatility forecast calibration against realized vol"
)


# =============================================================================
# STRATEGY REGISTRY
# =============================================================================

ALL_HYPOTHESES: List[StrategyHypothesis] = [
    HYP_01_MOMENTUM,
    HYP_02_CARRY_CRASH,
    HYP_03_VALUE_PPP,
    HYP_04_COT_POSITIONING,
    HYP_05_VOL_RISK_PREMIUM,
    HYP_06_OPTIONS_SKEW,
    HYP_07_SAFE_HAVEN,
    HYP_08_CALENDAR_SPREAD,
    HYP_09_MEAN_REVERSION,
    HYP_10_EVENT_NLP,
    HYP_11_ML_REGIME,
    HYP_12_DL_VOL_FORECAST,
]

# Default strategy configurations
DEFAULT_STRATEGY_CONFIGS: Dict[str, StrategyConfig] = {
    hyp.id: StrategyConfig(hypothesis=hyp) for hyp in ALL_HYPOTHESES
}

# Override defaults for specific strategies
DEFAULT_STRATEGY_CONFIGS["HYP_01"].priority = 1  # High priority
DEFAULT_STRATEGY_CONFIGS["HYP_01"].max_position_pct = 0.15
DEFAULT_STRATEGY_CONFIGS["HYP_01"].params = {
    "lookback_short": 21,
    "lookback_medium": 63,
    "lookback_long": 126,
}

DEFAULT_STRATEGY_CONFIGS["HYP_02"].priority = 2
DEFAULT_STRATEGY_CONFIGS["HYP_02"].max_position_pct = 0.12
DEFAULT_STRATEGY_CONFIGS["HYP_02"].params = {
    "crash_vol_threshold": 0.25,
    "skew_threshold": -0.3,
}

DEFAULT_STRATEGY_CONFIGS["HYP_11"].enabled = True  # Always enabled as filter
DEFAULT_STRATEGY_CONFIGS["HYP_11"].priority = 0  # Highest priority (filter runs first)

DEFAULT_STRATEGY_CONFIGS["HYP_12"].enabled = True  # Always enabled for risk
DEFAULT_STRATEGY_CONFIGS["HYP_12"].priority = 0

# Disabled by default (require special infrastructure)
DEFAULT_STRATEGY_CONFIGS["HYP_10"].enabled = False  # Requires news feed
DEFAULT_STRATEGY_CONFIGS["HYP_05"].enabled = False  # Requires options data
DEFAULT_STRATEGY_CONFIGS["HYP_06"].enabled = False  # Requires options data


STRATEGY_REGISTRY: Dict[str, StrategyConfig] = DEFAULT_STRATEGY_CONFIGS


def get_strategy_config(strategy_id: str) -> StrategyConfig:
    """
    Retrieve strategy configuration by ID.
    
    Args:
        strategy_id: Strategy ID (e.g., 'HYP_01')
        
    Returns:
        StrategyConfig for the requested strategy
        
    Raises:
        KeyError: If strategy ID not found
    """
    if strategy_id not in STRATEGY_REGISTRY:
        available = ", ".join(sorted(STRATEGY_REGISTRY.keys()))
        raise KeyError(
            f"Strategy '{strategy_id}' not found. Available: {available}"
        )
    return STRATEGY_REGISTRY[strategy_id]


def get_enabled_strategies() -> List[StrategyConfig]:
    """Return list of all currently enabled strategies."""
    return [cfg for cfg in STRATEGY_REGISTRY.values() if cfg.enabled]


def get_strategies_by_category(category: StrategyCategory) -> List[StrategyConfig]:
    """
    Filter strategies by category.
    
    Args:
        category: StrategyCategory enum value
        
    Returns:
        List of matching strategy configs
    """
    return [
        cfg for cfg in STRATEGY_REGISTRY.values()
        if cfg.hypothesis.category == category and cfg.enabled
    ]


def get_strategies_for_instrument(symbol: str) -> List[StrategyConfig]:
    """
    Get all strategies applicable to a specific instrument.
    
    Args:
        symbol: Instrument symbol (e.g., '6E')
        
    Returns:
        List of strategy configs that can trade this instrument
    """
    result = []
    for cfg in STRATEGY_REGISTRY.values():
        if not cfg.enabled:
            continue
        if symbol in cfg.hypothesis.instruments:
            result.append(cfg)
    return result
