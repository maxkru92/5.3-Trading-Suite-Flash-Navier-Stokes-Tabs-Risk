"""
FX Trading Desk Data Module
---------------------------
Datenquellen, Feature-Engineering und Intelligence-Layer.

Verfügbare Komponenten:
- LSEFeed: London Strategic Edge Live-Datenfeed
- LSEDataIntelligence: Multi-Asset-Datenanalyse mit Alerts
- HistoricalDataStore: Historische Daten für Backtests
- FeatureEngine: Log-Returns, Realized Vol, etc.
"""

from fx_desk.data.lse_feed import LSEFeed, LSECandleData, LSEMetadata
from fx_desk.data.lse_intelligence import (
    LSEDataIntelligence,
    DataIntelligenceAlert,
    EconomicEvent,
    BondYieldData,
    OptionsFlowData,
    L3OrderBookImbalance,
    ImpactLevel,
    EventType
)
from fx_desk.data.features import FeatureEngine
from fx_desk.data.feed_interface import MarketDataFeed

__all__ = [
    # LSE Feed
    "LSEFeed",
    "LSECandleData",
    "LSEMetadata",
    
    # LSE Intelligence
    "LSEDataIntelligence",
    "DataIntelligenceAlert",
    "EconomicEvent",
    "BondYieldData",
    "OptionsFlowData",
    "L3OrderBookImbalance",
    "ImpactLevel",
    "EventType",
    
    # Features & Interface
    "FeatureEngine",
    "MarketDataFeed",
]
