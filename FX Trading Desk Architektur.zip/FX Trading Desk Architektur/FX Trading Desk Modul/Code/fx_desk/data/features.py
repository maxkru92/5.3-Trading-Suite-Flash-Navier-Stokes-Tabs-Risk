"""
Feature Engineering Module for FX Trading Desk.

Implements feature calculations including logarithmic returns, realized volatility,
IV-RV spreads, COT z-scores, term structure slopes, skew/risk reversals, and HMM regime states.

All price-based calculations use LOGARITHMIC RETURNS exclusively.

Literature References:
- FX-003, FX-009, FX-015: Return calculation methodologies
- FX-028, FX-029: Volatility estimation techniques
- FX-091-FX-094, AI-011: HMM/Markov regime classification
"""

import math
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class RegimeType(Enum):
    """Market regime classification."""
    TREND = "trend"           # Strong directional movement
    RANGE = "range"           # Mean-reverting, range-bound
    RISK_ON = "risk_on"       # Risk appetite, carry favorable
    RISK_OFF = "risk_off"     # Risk aversion, safe-haven flows
    CRASH = "crash"           # Extreme stress, liquidity crisis
    NEUTRAL = "neutral"       # No clear regime


@dataclass
class RegimeState:
    """
    Current market regime state.
    
    Attributes:
        regime_type: Primary regime classification
        confidence: Confidence level of regime classification (0-1)
        trend_direction: Direction if in TREND regime (UP/DOWN/None)
        vol_level: Current volatility level (LOW/MEDIUM/HIGH)
        liquidity_state: Market liquidity condition
        timestamp: When regime was last updated
        model_source: Which model generated this regime state
    """
    regime_type: RegimeType
    confidence: float
    trend_direction: Optional[str] = None  # 'UP', 'DOWN', or None
    vol_level: str = "MEDIUM"  # 'LOW', 'MEDIUM', 'HIGH'
    liquidity_state: str = "NORMAL"  # 'LOW', 'NORMAL', 'HIGH'
    timestamp: datetime = field(default_factory=datetime.utcnow)
    model_source: str = "default"
    
    def __post_init__(self) -> None:
        """Validate regime state."""
        if not 0 <= self.confidence <= 1:
            raise ValueError("Confidence must be between 0 and 1")
    
    def allows_strategy(self, required_filter: Optional[str]) -> bool:
        """
        Check if current regime allows a strategy with given filter requirement.
        
        Args:
            required_filter: String like 'TREND or NEUTRAL', 'RISK_ON and NOT CRASH'
            
        Returns:
            True if regime satisfies the filter requirement
        """
        if not required_filter:
            return True
        
        # Parse simple boolean expressions
        required_filter = required_filter.upper()
        
        # Handle 'NOT' expressions
        if "NOT" in required_filter:
            parts = required_filter.split("NOT")
            positive_part = parts[0].strip()
            negative_part = parts[1].strip() if len(parts) > 1 else ""
            
            # Check negative condition first
            if negative_part and negative_part in self.regime_type.value.upper():
                return False
            
            # Then check positive part
            if positive_part and positive_part != "AND":
                return positive_part in self.regime_type.value.upper() or positive_part == "ANY"
            return True
        
        # Handle 'OR' expressions
        if "OR" in required_filter:
            options = [opt.strip() for opt in required_filter.split("OR")]
            return any(opt in self.regime_type.value.upper() for opt in options)
        
        # Handle 'AND' expressions
        if "AND" in required_filter:
            conditions = [cond.strip() for cond in required_filter.split("AND")]
            return all(
                cond in self.regime_type.value.upper() or 
                cond == "ANY" or
                (cond.startswith("NOT ") and cond[4:] not in self.regime_type.value.upper())
                for cond in conditions
            )
        
        # Simple match
        return required_filter in self.regime_type.value.upper()


@dataclass
class MarketContext:
    """
    Complete market context for signal generation.
    
    Contains all features needed by strategies, organized by category.
    
    Attributes:
        symbol: Instrument symbol
        timestamp: Data timestamp
        prices: Recent price series (close prices)
        features: Dictionary of all calculated features
        regime: Current regime state
        metadata: Additional metadata
    """
    symbol: str
    timestamp: datetime
    prices: List[float]
    features: Dict[str, float] = field(default_factory=dict)
    regime: Optional[RegimeState] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Additional market data (optional, for advanced features)
    highs: Optional[List[float]] = None
    lows: Optional[List[float]] = None
    volumes: Optional[List[float]] = None
    open_interest: Optional[List[float]] = None
    
    # Options data (for strategies requiring options)
    implied_vol: Optional[Dict[str, float]] = None  # tenor -> IV
    skew_data: Optional[Dict[str, float]] = None    # delta -> skew
    risk_reversal: Optional[float] = None
    
    # COT data (for positioning strategies)
    cot_commercial: Optional[float] = None
    cot_speculator: Optional[float] = None
    cot_historical_zscore: Optional[float] = None
    
    # Macro data (for value/carry strategies)
    interest_rate_domestic: Optional[float] = None
    interest_rate_foreign: Optional[float] = None
    ppp_fair_value: Optional[float] = None
    
    def get_feature(self, name: str, default: float = 0.0) -> float:
        """Safely retrieve a feature value."""
        return self.features.get(name, default)
    
    def has_required_features(self, required: List[str]) -> bool:
        """Check if all required features are available."""
        return all(name in self.features for name in required)
    
    @property
    def current_price(self) -> Optional[float]:
        """Get most recent price."""
        return self.prices[-1] if self.prices else None
    
    @property
    def price_count(self) -> int:
        """Get number of available price points."""
        return len(self.prices)


class FeatureEngine:
    """
    Feature engineering engine for FX trading strategies.
    
    All return calculations use LOGARITHMIC RETURNS:
        log_ret = ln(price_t / price_{t-1})
    
    NEVER uses simple percentage changes: (price_t - price_{t-1}) / price_{t-1}
    
    Literature: FX-003 (log return methodology), FX-028 (volatility estimation)
    """
    
    def __init__(self, annualization_factor: int = 252):
        """
        Initialize feature engine.
        
        Args:
            annualization_factor: Trading days per year for annualization
        """
        self.annualization_factor = annualization_factor
        logger.info(f"FeatureEngine initialized with annualization_factor={annualization_factor}")
    
    def calculate_log_returns(self, prices: List[float], lookback: int = 1) -> List[float]:
        """
        Calculate logarithmic returns.
        
        MANDATORY: Uses log returns EXCLUSIVELY, never simple percentage changes.
        
        Formula: log_ret[i] = ln(prices[i] / prices[i - lookback])
        
        Args:
            prices: Price series
            lookback: Lookback period for return calculation
            
        Returns:
            List of log returns (shorter than input by lookback periods)
        """
        if len(prices) <= lookback:
            return []
        
        log_rets = []
        for i in range(lookback, len(prices)):
            if prices[i - lookback] <= 0 or prices[i] <= 0:
                log_rets.append(0.0)
                logger.warning(f"Non-positive price encountered in log return calculation")
            else:
                # CRITICAL: Logarithmic return calculation
                log_ret = math.log(prices[i] / prices[i - lookback])
                log_rets.append(log_ret)
        
        return log_rets
    
    def calculate_realized_volatility(
        self, 
        prices: List[float], 
        window: int = 21,
        annualize: bool = True
    ) -> float:
        """
        Calculate realized volatility from log returns.
        
        Uses standard deviation of log returns, annualized.
        
        Args:
            prices: Price series
            window: Lookback window in days
            annualize: Whether to annualize the result
            
        Returns:
            Realized volatility (annualized if requested)
        """
        if len(prices) < window + 1:
            return 0.0
        
        # Calculate daily log returns
        log_rets = self.calculate_log_returns(prices[-window-1:], lookback=1)
        
        if not log_rets:
            return 0.0
        
        # Calculate mean and variance of log returns
        n = len(log_rets)
        mean_ret = sum(log_rets) / n
        var_ret = sum((r - mean_ret) ** 2 for r in log_rets) / (n - 1) if n > 1 else 0.0
        
        daily_vol = math.sqrt(var_ret) if var_ret > 0 else 0.0
        
        if annualize:
            # Annualize using square-root-of-time rule
            return daily_vol * math.sqrt(self.annualization_factor)
        
        return daily_vol
    
    def calculate_momentum_score(
        self,
        prices: List[float],
        short_window: int = 21,
        medium_window: int = 63,
        long_window: int = 126
    ) -> float:
        """
        Calculate composite momentum score.
        
        Combines multiple lookback periods into single momentum metric.
        
        Args:
            prices: Price series
            short_window: Short-term lookback (e.g., 21 days)
            medium_window: Medium-term lookback (e.g., 63 days)
            long_window: Long-term lookback (e.g., 126 days)
            
        Returns:
            Composite momentum score (-1 to 1 scale approximately)
        """
        if len(prices) < long_window + 1:
            return 0.0
        
        # Calculate log returns for each horizon
        ret_short = self.calculate_log_returns(prices[-short_window-1:], lookback=short_window)
        ret_medium = self.calculate_log_returns(prices[-medium_window-1:], lookback=medium_window)
        ret_long = self.calculate_log_returns(prices[-long_window-1:], lookback=long_window)
        
        if not all([ret_short, ret_medium, ret_long]):
            return 0.0
        
        # Get most recent returns
        r_short = ret_short[-1] if ret_short else 0.0
        r_medium = ret_medium[-1] if ret_medium else 0.0
        r_long = ret_long[-1] if ret_long else 0.0
        
        # Weighted combination (shorter horizons get higher weight)
        weights = [0.5, 0.3, 0.2]  # Short, medium, long
        momentum = weights[0] * r_short + weights[1] * r_medium + weights[2] * r_long
        
        # Normalize to approximate -1 to 1 scale
        # Typical daily log returns are ~0.01, so multiply by ~100
        normalized_momentum = math.tanh(momentum * 100)
        
        return normalized_momentum
    
    def calculate_iv_rv_spread(
        self,
        implied_vol: float,
        prices: List[float],
        rv_window: int = 21
    ) -> float:
        """
        Calculate Implied Volatility vs Realized Volatility spread.
        
        Positive spread = IV > RV (volatility premium)
        Negative spread = IV < RV (volatility discount)
        
        Args:
            implied_vol: Implied volatility (decimal, e.g., 0.12 for 12%)
            prices: Price series for RV calculation
            rv_window: Window for realized vol calculation
            
        Returns:
            IV - RV spread (in decimal terms)
        """
        rv = self.calculate_realized_volatility(prices, rv_window, annualize=True)
        
        if rv <= 0:
            return 0.0
        
        return implied_vol - rv
    
    def calculate_term_structure_slope(
        self,
        near_price: float,
        far_price: float,
        days_to_near: int,
        days_to_far: int
    ) -> float:
        """
        Calculate futures term structure slope (calendar spread).
        
        Uses log price difference annualized.
        
        Args:
            near_price: Near contract price
            far_price: Far contract price
            days_to_near: Days to near contract expiry
            days_to_far: Days to far contract expiry
            
        Returns:
            Annualized slope (positive = contango, negative = backwardation)
        """
        if near_price <= 0 or far_price <= 0:
            return 0.0
        
        days_diff = days_to_far - days_to_near
        if days_diff <= 0:
            return 0.0
        
        # Log price difference, annualized
        log_diff = math.log(far_price / near_price)
        annualized_slope = log_diff * (365 / days_diff)
        
        return annualized_slope
    
    def calculate_skew_from_prices(
        self,
        prices: List[float],
        window: int = 63
    ) -> float:
        """
        Calculate return skewness as proxy for options skew.
        
        Negative skew = crash fear (out-of-money puts expensive)
        Positive skew = squeeze fear (out-of-money calls expensive)
        
        Args:
            prices: Price series
            window: Lookback window
            
        Returns:
            Skewness coefficient
        """
        if len(prices) < window + 1:
            return 0.0
        
        log_rets = self.calculate_log_returns(prices[-window-1:], lookback=1)
        
        if len(log_rets) < 3:
            return 0.0
        
        n = len(log_rets)
        mean_ret = sum(log_rets) / n
        
        # Calculate standard deviation
        var_ret = sum((r - mean_ret) ** 2 for r in log_rets) / (n - 1)
        std_ret = math.sqrt(var_ret) if var_ret > 0 else 1.0
        
        # Calculate third moment for skewness
        third_moment = sum((r - mean_ret) ** 3 for r in log_rets) / n
        
        # Skewness = third moment / std^3
        skew = third_moment / (std_ret ** 3) if std_ret > 0 else 0.0
        
        return skew
    
    def calculate_cot_zscore(
        self,
        current_positioning: float,
        historical_mean: float,
        historical_std: float
    ) -> float:
        """
        Calculate COT positioning z-score.
        
        Measures how extreme current positioning is vs historical norm.
        
        Args:
            current_positioning: Current net positioning
            historical_mean: Historical mean positioning
            historical_std: Historical standard deviation
            
        Returns:
            Z-score (>2 or <-2 indicates extreme)
        """
        if historical_std <= 0:
            return 0.0
        
        zscore = (current_positioning - historical_mean) / historical_std
        return zscore
    
    def build_market_context(
        self,
        symbol: str,
        prices: List[float],
        timestamp: Optional[datetime] = None,
        **kwargs: Any
    ) -> MarketContext:
        """
        Build complete MarketContext with all calculated features.
        
        Args:
            symbol: Instrument symbol
            prices: Price series (most recent last)
            timestamp: Data timestamp
            **kwargs: Additional data (highs, lows, vols, etc.)
            
        Returns:
            Complete MarketContext object
        """
        if timestamp is None:
            timestamp = datetime.utcnow()
        
        # Initialize features dictionary
        features: Dict[str, float] = {}
        
        # Basic price features
        if len(prices) >= 2:
            # Daily log return
            daily_log_ret = self.calculate_log_returns(prices[-2:], lookback=1)
            if daily_log_ret:
                features["log_return_1d"] = daily_log_ret[-1]
        
        # Multi-period log returns
        for period in [5, 21, 63, 126, 252]:
            if len(prices) > period:
                ret = self.calculate_log_returns(prices[-period-1:], lookback=period)
                if ret:
                    features[f"log_return_{period}d"] = ret[-1]
        
        # Volatility features
        for window in [5, 21, 63]:
            if len(prices) > window:
                vol = self.calculate_realized_volatility(prices, window, annualize=True)
                features[f"realized_vol_{window}d"] = vol
        
        # Annualized volatility (standard)
        if len(prices) > 21:
            features["annualized_vol"] = self.calculate_realized_volatility(prices, 21, annualize=True)
            features["daily_vol"] = features["annualized_vol"] / math.sqrt(self.annualization_factor)
        
        # Momentum features
        if len(prices) > 126:
            features["momentum_score"] = self.calculate_momentum_score(prices)
        
        # Skew feature
        if len(prices) > 63:
            features["skew_63d"] = self.calculate_skew_from_prices(prices, 63)
        
        # Add kwargs features
        for key, value in kwargs.items():
            if isinstance(value, (int, float)):
                features[key] = float(value)
        
        # Create MarketContext
        context = MarketContext(
            symbol=symbol,
            timestamp=timestamp,
            prices=prices,
            features=features,
            **kwargs
        )
        
        logger.debug(f"Built MarketContext for {symbol} with {len(features)} features")
        return context
    
    def estimate_hmm_regime(
        self,
        prices: List[float],
        window: int = 252
    ) -> RegimeState:
        """
        Estimate market regime using HMM-like logic.
        
        NOTE: This is a simplified placeholder. Production implementation
        should use hmmlearn or similar library with proper training.
        
        Literature: FX-091, FX-092, FX-093, FX-094, AI-011
        
        Args:
            prices: Price series
            window: Lookback window for regime estimation
            
        Returns:
            RegimeState object
        """
        if len(prices) < window:
            return RegimeState(
                regime_type=RegimeType.NEUTRAL,
                confidence=0.5,
                model_source="hmm_placeholder"
            )
        
        # Calculate features for regime classification
        vol = self.calculate_realized_volatility(prices[-window:], annualize=True)
        momentum = self.calculate_momentum_score(prices[-window:])
        
        # Simple rule-based regime classification
        # (Replace with actual HMM in production)
        confidence = min(abs(momentum), abs(vol - 0.10)) * 10
        confidence = max(0.1, min(0.95, confidence))
        
        # Determine regime type
        if abs(momentum) > 0.3:
            regime_type = RegimeType.TREND
            trend_direction = "UP" if momentum > 0 else "DOWN"
        elif vol > 0.25:
            regime_type = RegimeType.CRASH
            trend_direction = None
        elif vol > 0.15:
            regime_type = RegimeType.RANGE
            trend_direction = None
        elif momentum > 0.1:
            regime_type = RegimeType.RISK_ON
            trend_direction = "UP"
        elif momentum < -0.1:
            regime_type = RegimeType.RISK_OFF
            trend_direction = "DOWN"
        else:
            regime_type = RegimeType.NEUTRAL
            trend_direction = None
        
        # Volatility level
        if vol < 0.08:
            vol_level = "LOW"
        elif vol > 0.18:
            vol_level = "HIGH"
        else:
            vol_level = "MEDIUM"
        
        return RegimeState(
            regime_type=regime_type,
            confidence=confidence,
            trend_direction=trend_direction,
            vol_level=vol_level,
            timestamp=datetime.utcnow(),
            model_source="hmm_rule_based"
        )
