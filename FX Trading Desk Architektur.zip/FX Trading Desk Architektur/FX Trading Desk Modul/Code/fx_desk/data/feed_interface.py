#!/usr/bin/env python3
"""
Market Data Feed Interface - Abstrakte Basisklasse für Live-Datenfeeds.

Dieses Modul definiert das Interface für alle MarketDataFeed-Implementierungen.
Konkrete Implementierungen (IBKR, Polygon, yfinance, LSE) erben von dieser Klasse.

Literatur:
- FX-078 (Real-time data requirements)
- FX-089 (Data quality checks)

Autor: Qwen Coder als Senior Chief Quantitative Coder
Datum: 2026-08-21
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime


@dataclass
class TickData:
    """Datenmodell für Tick-Daten."""
    symbol: str
    timestamp: datetime
    bid: float
    ask: float
    bid_size: int
    ask_size: int
    last: float
    volume: int
    
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0
    
    def spread(self) -> float:
        return self.ask - self.bid


@dataclass
class BarData:
    """Datenmodell für OHLCV-Bars."""
    symbol: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: int
    bar_size: str = "1m"
    
    def log_return(self) -> float:
        import math
        return math.log(self.close / self.open)


class MarketDataFeed(ABC):
    """
    Abstrakte Basisklasse für Market Data Feeds.
    
    Definiert das Pflichtinterface für alle Datenfeed-Implementierungen.
    Unterstützt sowohl historische Daten als auch Live-Streaming.
    
    Verfügbare Implementierungen:
    - LSEFeed: London Strategic Edge (Primary für CME Futures)
    - IBKRFeed: Interactive Brokers (Backup)
    - PolygonFeed: Polygon.io (Backup)
    - YFinanceFeed: Yahoo Finance (Development)
    """
    
    @abstractmethod
    def connect(self) -> bool:
        """
        Stellt Verbindung zum Datenprovider her.
        
        Returns:
            True bei Erfolg, False bei Fehler
        """
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        """Trennt die Verbindung zum Datenprovider."""
        pass
    
    @abstractmethod
    def get_historical_bars(
        self, 
        symbol: str, 
        bar_size: str, 
        start_date: datetime, 
        end_date: datetime
    ) -> List[BarData]:
        """
        Ruft historische Bars ab.
        
        Args:
            symbol: Instrumentensymbol (z.B. "6E1!")
            bar_size: Zeitintervall ("1m", "5m", "1h", "1d")
            start_date: Startdatum
            end_date: Enddatum
        
        Returns:
            Liste von BarData-Objekten
        """
        pass
    
    @abstractmethod
    def subscribe_ticks(self, symbols: List[str], callback: callable) -> bool:
        """
        Abonniert Tick-Daten für eine Liste von Symbolen.
        
        Args:
            symbols: Liste von Symbolen
            callback: Callback-Funktion für neue Ticks
        
        Returns:
            True bei Erfolg
        """
        pass
    
    @abstractmethod
    def unsubscribe_ticks(self, symbols: List[str]) -> bool:
        """
        De-abonniert Tick-Daten für eine Liste von Symbolen.
        
        Args:
            symbols: Liste von Symbolen
        
        Returns:
            True bei Erfolg
        """
        pass
    
    @abstractmethod
    def get_latest_tick(self, symbol: str) -> Optional[TickData]:
        """
        Ruft den neuesten Tick für ein Symbol ab.
        
        Args:
            symbol: Instrumentensymbol
        
        Returns:
            TickData oder None
        """
        pass
