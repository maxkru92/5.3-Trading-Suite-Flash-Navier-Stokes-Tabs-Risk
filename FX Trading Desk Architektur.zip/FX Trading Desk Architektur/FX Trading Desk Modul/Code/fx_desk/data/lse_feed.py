#!/usr/bin/env python3
"""
London Strategic Edge (LSE) Live Data Feed Integration
-------------------------------------------------------
Integriert den LSE-Scraper als Live-Datenquelle für das FX Trading Desk Modul.

Features:
- Streamt Live-Forex-Daten von londonstrategicedge.com
- Unterstützt alle CME Währungsfutures: 6E, 6J, 6B, 6A, 6C, 6S, 6N (+ Micros)
- Automatisches Cloudflare-Bypass via Scrapling
- Paralleler Download historischer Daten
- Human-readable Dateinamen durch automatische Umbenennung

Literatur/Referenzen:
- LSE API Dokumentation: https://londonstrategicedge.com/datasets
- Scrapling: https://github.com/D4Vinci/Scrapling

Autor: Qwen Coder als Senior Chief Quantitative Coder
Datum: 2026-08-21
"""

import os
import re
import sys
import json
import time
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

# Optional Scrapling-Import mit Fallback auf Standard-Requests
SCRAPLING_AVAILABLE = False
try:
    from scrapling.fetchers import StealthySession, Fetcher
    SCRAPLING_AVAILABLE = True
    # Suppress verbose Scrapling fetch logs
    logging.getLogger("scrapling").setLevel(logging.WARNING)
except ImportError:
    import warnings
    warnings.warn(
        "Scrapling nicht verfügbar. LSEFeed läuft im Fallback-Modus mit requests. "
        "Für Cloudflare-Bypass installieren: pip install scrapling"
    )
    StealthySession = None  # type: ignore
    Fetcher = None  # type: ignore

logger = logging.getLogger(__name__)

# Default endpoints
DATA_API = "https://data-api.londonstrategicedge.com"
BASE_URL = "https://londonstrategicedge.com"

# CME Currency Futures Mapping
CME_FUTURES_MAPPING = {
    # Major Currencies
    "6E": {"name": "Euro FX", "symbol": "6E1!", "category": "forex", "exchange": "CME"},
    "6J": {"name": "Japanese Yen", "symbol": "6J1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "6B": {"name": "British Pound", "symbol": "6B1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "6A": {"name": "Australian Dollar", "symbol": "6A1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "6C": {"name": "Canadian Dollar", "symbol": "6C1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "6S": {"name": "Swiss Franc", "symbol": "6S1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "6N": {"name": "New Zealand Dollar", "symbol": "6N1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    
    # Micro Futures
    "M6E": {"name": "Micro Euro FX", "symbol": "M6E1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "M6J": {"name": "Micro Japanese Yen", "symbol": "M6J1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "M6B": {"name": "Micro British Pound", "symbol": "M6B1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "M6A": {"name": "Micro Australian Dollar", "symbol": "M6A1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "M6C": {"name": "Micro Canadian Dollar", "symbol": "M6C1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "M6S": {"name": "Micro Swiss Franc", "symbol": "M6S1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
    "M6N": {"name": "Micro New Zealand Dollar", "symbol": "M6N1!", "category": "forex", "category_lse": "forex", "exchange": "CME"},
}

# Country codes mapping for Economic Calendar & Bond Yields
COUNTRY_NAMES = {
    "AR": "Argentina", "AU": "Australia", "BR": "Brazil", "CA": "Canada", "CN": "China",
    "DE": "Germany", "EA": "Eurozone", "FR": "France", "ID": "Indonesia", "IN": "India",
    "IT": "Italy", "JP": "Japan", "KR": "South Korea", "MX": "Mexico", "RU": "Russia",
    "SA": "Saudi Arabia", "TR": "Turkey", "US": "United States", "ZA": "South Africa",
    "GB": "United Kingdom", "UK": "United Kingdom", "AT": "Austria", "CH": "Switzerland",
    "CL": "Chile", "ES": "Spain", "GR": "Greece", "MY": "Malaysia", "NG": "Nigeria",
    "NL": "Netherlands", "NO": "Norway", "NZ": "New Zealand", "PT": "Portugal", "SE": "Sweden",
    "SG": "Singapore", "TH": "Thailand"
}


@dataclass
class LSECandleData:
    """Datenmodell für LSE Candle-Daten."""
    symbol: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: int
    category: str = "forex"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "symbol": self.symbol,
            "timestamp": self.timestamp.isoformat(),
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            "category": self.category
        }


@dataclass
class LSEMetadata:
    """Metadaten für LSE-Datensätze."""
    symbol: str
    human_name: str
    category: str
    years: List[int]
    files: List[str]


def request_json(url: str, cookie_str: Optional[str] = None) -> Optional[Dict]:
    """Fetch JSON from a URL using Scrapling Fetcher."""
    headers = {}
    if cookie_str:
        headers["Cookie"] = cookie_str
    for attempt in range(3):
        try:
            r = Fetcher.get(url, stealthy_headers=True, headers=headers)
            if r.status == 200:
                return r.json()
        except Exception:
            pass
        time.sleep(1)
    return None


def download_file(
    url: str, 
    dest_path: Path, 
    cookie_str: Optional[str] = None, 
    auth_token: Optional[str] = None,
    retries: int = 3, 
    delay: int = 2
) -> str:
    """Download a file with retries and cookie/token injection using Scrapling Fetcher."""
    dest_path = Path(dest_path)
    if dest_path.exists() and dest_path.stat().st_size > 1024:
        return "SKIP"
        
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    
    headers = {}
    if cookie_str:
        headers['Cookie'] = cookie_str
    if auth_token:
        headers['Authorization'] = auth_token if auth_token.startswith("Bearer ") else f"Bearer {auth_token}"
        
    for attempt in range(retries):
        try:
            r = Fetcher.get(url, stealthy_headers=True, headers=headers)
            if r.status == 200:
                body = r.body
                if isinstance(body, bytes):
                    data = body
                elif isinstance(body, str):
                    data = body.encode()
                else:
                    data = str(body).encode()
                    
                # Auth message check inside tiny responses
                if len(data) < 1000 and (b"Unauthorized" in data or b"Expired" in data or b"error" in data):
                    return "AUTH_ERR"
                    
                # Basic verification for CSV files
                if "format=csv" in url or "start_date" in url:
                    if data.startswith(b"<!DOCTYPE") or data.startswith(b"<html"):
                        err_text = data.decode('utf-8', errors='ignore').lower()
                        if "not found" in err_text or "does not exist" in err_text:
                            return "404"
                        return "INVALID_CSV"
                        
                dest_path.write_bytes(data)
                return "OK"
            elif r.status == 404:
                return "404"
            elif r.status in (401, 403):
                return f"HTTP_{r.status}"
        except Exception as e:
            if attempt == retries - 1:
                return f"ERR_{type(e).__name__}"
                
        time.sleep(delay)
    return "TIMEOUT"


def clean_name(name: str) -> str:
    """Clean filenames to be safe for OS file systems."""
    name = name.replace(" / ", " - ").replace("/", " - ")
    invalid_chars = r'\/:*?"<>|'
    for c in invalid_chars:
        name = name.replace(c, '')
    return name.strip()


class LSEFeed:
    """
    London Strategic Edge Live Data Feed für FX Trading Desk.
    
    Diese Klasse integriert den LSE-Scraper als primäre Datenquelle für:
    - CME Währungsfutures (6E, 6J, 6B, 6A, 6C, 6S, 6N)
    - Micro Währungsfutures (M6E, M6J, M6B, M6A, M6C, M6S, M6N)
    - Historische OHLCV-Daten (1-Minuten-Candles)
    - Level 3 Order Book Daten (mit Token)
    
    Usage:
        feed = LSEFeed(output_dir="./lse_data")
        feed.setup()  # Cloudflare-Bypass + Metadaten
        feed.download_candles(symbols=["6E", "6J", "6B"])
        candles = feed.load_candles("6E", year=2026)
    
    Literatur:
        - LSE API: https://londonstrategicedge.com/datasets
        - Scrapling: https://github.com/D4Vinci/Scrapling
    """
    
    def __init__(
        self, 
        output_dir: str = "./lse_datasets", 
        max_workers: int = 8, 
        token: Optional[str] = None
    ):
        """
        Initialisiert den LSE-Feed.
        
        Args:
            output_dir: Verzeichnis für gespeicherte Daten
            max_workers: Anzahl paralleler Download-Threads
            token: Bearer-Token für L3-Futures-Zugriff (optional)
        """
        self.output_dir = Path(output_dir)
        self.metadata_dir = self.output_dir / "_metadata"
        self.max_workers = max_workers
        self.token = token
        self.company_names: Dict[str, str] = {}
        self.cookie_str: Optional[str] = None
        self.symbol_mapping: Dict[str, LSEMetadata] = {}
        
    def setup(self) -> bool:
        """
        Erstellt Verzeichnisse, erwirbt Cloudflare-Cookies und lädt Metadaten.
        
        Returns:
            True bei Erfolg, False bei Fehlern
        """
        logger.info("Setting up LSE Feed...")
        
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_dir.mkdir(parents=True, exist_ok=True)
        
        # 1. Cloudflare Clearance Cookies erwerben
        logger.info("[1/3] Establishing Stealth Session to solve Cloudflare clearance...")
        try:
            with StealthySession(headless=True, solve_cloudflare=True) as session:
                resp = session.fetch(f"{BASE_URL}/datasets", network_idle=True, google_search=False)
                logger.info(f"  Connection established: Status {resp.status}")
                cookies = session.context.cookies()
                cookie_dict = {c['name']: c['value'] for c in cookies}
                self.cookie_str = "; ".join(f"{k}={v}" for k, v in cookie_dict.items())
                logger.info(f"  Successfully acquired {len(cookies)} cookies.")
        except Exception as e:
            logger.warning(f"  Warning: Could not run StealthySession browser context: {e}")
            logger.warning("  Attempting to proceed with default fetcher headers...")
            
        # 2. Metadaten-Dateien herunterladen
        logger.info("\n[2/3] Downloading Metadata Files...")
        metadata_files = {
            "datasets-manifest.json": f"{BASE_URL}/datasets-manifest.json",
            "options-manifest.json": f"{BASE_URL}/options-manifest.json",
            "r2-symbols.json": f"{BASE_URL}/r2-symbols.json",
            "company-names.json": f"{BASE_URL}/company-names.json",
            "economic-calendar-metadata.json": f"{BASE_URL}/economic-calendar-metadata.json",
        }
        
        for name, url in metadata_files.items():
            dest = self.metadata_dir / name
            status = download_file(url, dest, self.cookie_str)
            logger.info(f"  {name}: {status}")
            
        # Company-Name-Mappings laden
        mapping_file = self.metadata_dir / "company-names.json"
        if mapping_file.exists():
            try:
                with open(mapping_file, 'r', encoding='utf-8') as f:
                    self.company_names = json.load(f)
                logger.info(f"Loaded {len(self.company_names)} company mappings.")
            except Exception as e:
                logger.error(f"Error loading company names mapping: {e}")
        
        # Symbol-Mapping aufbauen
        self._build_symbol_mapping()
        
        return True
    
    def _build_symbol_mapping(self) -> None:
        """Buildet internes Symbol-Mapping aus LSE-Metadaten."""
        symbols_file = self.metadata_dir / "r2-symbols.json"
        if not symbols_file.exists():
            logger.warning("r2-symbols.json missing, using default CME mapping.")
            # Fallback auf hartkodierte CME-Mapping
            for ticker, info in CME_FUTURES_MAPPING.items():
                self.symbol_mapping[ticker] = LSEMetadata(
                    symbol=info["symbol"],
                    human_name=info["name"],
                    category=info.get("category_lse", "forex"),
                    years=list(range(2015, 2027)),
                    files=[]
                )
            return
        
        with open(symbols_file, 'r', encoding='utf-8') as f:
            symbols_data = json.load(f)
        
        symbols = symbols_data.get("symbols", [])
        for sym in symbols:
            symbol = sym["symbol"]
            category = sym.get("category", "stocks")
            years = sym.get("years", [])
            
            # Prüfen ob es ein Forex-Symbol ist
            if category == "forex":
                # Extrahiere Basis-Ticker (ohne Jahr)
                base_symbol = re.match(r"^([a-zA-Z0-9_]+)", symbol)
                if base_symbol:
                    ticker = base_symbol.group(1).upper()
                    self.symbol_mapping[ticker] = LSEMetadata(
                        symbol=symbol,
                        human_name=clean_name(symbol),
                        category=category,
                        years=[y for y in years],
                        files=[]
                    )
        
        logger.info(f"Built symbol mapping with {len(self.symbol_mapping)} symbols.")
    
    def get_symbol_mapping(self, symbol: str) -> Optional[Tuple[str, str]]:
        """
        Mappt einen Ticker-Symbol zu seinem human-readable Namen.
        
        Args:
            symbol: Ticker-Symbol (z.B. "6E", "6J")
            
        Returns:
            Tuple aus (Ticker, Human-Readable-Name) oder None
        """
        sym_lower = symbol.lower()
        if sym_lower in self.company_names:
            return sym_lower.upper(), clean_name(self.company_names[sym_lower])
        # Try without underscores
        clean_sym = sym_lower.replace('_', '')
        if clean_sym in self.company_names:
            return clean_sym.upper(), clean_name(self.company_names[clean_sym])
        return None
    
    def download_candles(
        self, 
        symbols: Optional[List[str]] = None, 
        years: Optional[List[int]] = None
    ) -> Dict[str, int]:
        """
        Lädt OHLCV-Minuten-Candles für Forex-Futures herunter.
        
        Args:
            symbols: Liste von Symbolen (z.B. ["6E", "6J", "6B"]). 
                     Wenn None, werden alle CME-Futures geladen.
            years: Liste von Jahren. Wenn None, werden 2015-2026 geladen.
        
        Returns:
            Dictionary mit Download-Statistiken
        """
        logger.info("\n[3/3] Downloading OHLCV Candles for FX Futures...")
        
        if symbols is None:
            symbols = list(CME_FUTURES_MAPPING.keys())
        
        if years is None:
            years = list(range(2015, 2027))
        
        tasks = []
        for sym in symbols:
            if sym not in CME_FUTURES_MAPPING:
                logger.warning(f"Symbol {sym} not in CME mapping, skipping.")
                continue
            
            info = CME_FUTURES_MAPPING[sym]
            category = info.get("category_lse", "forex")
            
            for y in years:
                tasks.append((category, sym, y))
        
        logger.info(f"  Total candle series to check/download: {len(tasks)}")
        
        stats = {"success": 0, "skipped": 0, "failed_404": 0, "failed_other": 0}
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}
            for cat, sym, yr in tasks:
                dest = self.output_dir / "candles" / cat / f"{sym}_{yr}.csv"
                url = f"{DATA_API}/dataset/{sym}?format=csv&start_date={yr}-01-01&end_date={yr}-12-31&limit=1000000"
                futures[executor.submit(download_file, url, dest, self.cookie_str)] = (sym, yr)
                
            for idx, future in enumerate(as_completed(futures)):
                sym, yr = futures[future]
                res = future.result()
                if res == "OK":
                    stats["success"] += 1
                elif res == "SKIP":
                    stats["skipped"] += 1
                elif res == "404":
                    stats["failed_404"] += 1
                else:
                    stats["failed_other"] += 1
                    
                if (idx + 1) % 50 == 0:
                    logger.info(f"  Progress: {idx+1}/{len(tasks)} checked "
                              f"(Success: {stats['success']}, Skipped: {stats['skipped']}, "
                              f"404: {stats['failed_404']})")
        
        logger.info(f"  Candle downloads finished: {stats['success']} downloaded, "
                   f"{stats['skipped']} skipped, {stats['failed_404']} unavailable (404), "
                   f"{stats['failed_other']} failed.")
        
        return stats
    
    def load_candles(
        self, 
        symbol: str, 
        year: int
    ) -> List[LSECandleData]:
        """
        Lädt gespeicherte Candle-Daten für ein Symbol und Jahr.
        
        Args:
            symbol: Ticker-Symbol (z.B. "6E")
            year: Jahr (z.B. 2026)
        
        Returns:
            Liste von LSECandleData-Objekten
        """
        if symbol not in CME_FUTURES_MAPPING:
            raise ValueError(f"Symbol {symbol} not in CME mapping")
        
        category = CME_FUTURES_MAPPING[symbol].get("category_lse", "forex")
        file_path = self.output_dir / "candles" / category / f"{symbol}_{year}.csv"
        
        if not file_path.exists():
            logger.warning(f"Candle file not found: {file_path}")
            return []
        
        candles = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                # Skip header line
                next(f, None)
                for line in f:
                    parts = line.strip().split(',')
                    if len(parts) >= 6:
                        try:
                            timestamp = datetime.fromisoformat(parts[0].replace('Z', '+00:00'))
                            candle = LSECandleData(
                                symbol=symbol,
                                timestamp=timestamp,
                                open=float(parts[1]),
                                high=float(parts[2]),
                                low=float(parts[3]),
                                close=float(parts[4]),
                                volume=int(parts[5]) if parts[5].isdigit() else 0,
                                category=category
                            )
                            candles.append(candle)
                        except (ValueError, IndexError) as e:
                            logger.debug(f"Error parsing line: {line}, error: {e}")
                            continue
        except Exception as e:
            logger.error(f"Error loading candles for {symbol}_{year}: {e}")
        
        logger.info(f"Loaded {len(candles)} candles for {symbol}_{year}")
        return candles
    
    def get_latest_candle(self, symbol: str) -> Optional[LSECandleData]:
        """
        Ruft die neueste verfügbare Candle für ein Symbol ab.
        
        Args:
            symbol: Ticker-Symbol (z.B. "6E")
        
        Returns:
            Neueste LSECandleData oder None
        """
        current_year = datetime.now().year
        candles = self.load_candles(symbol, current_year)
        
        if not candles:
            # Fallback auf vorheriges Jahr
            candles = self.load_candles(symbol, current_year - 1)
        
        if candles:
            return max(candles, key=lambda c: c.timestamp)
        
        return None
    
    def stream_live_data(
        self, 
        symbols: List[str], 
        callback: callable, 
        interval: int = 60
    ) -> None:
        """
        Streamt Live-Daten für eine Liste von Symbolen.
        
        Args:
            symbols: Liste von Symbolen zum Streamen
            callback: Callback-Funktion, die bei neuen Daten aufgerufen wird
            interval: Update-Intervall in Sekunden
        
        Usage:
            def on_new_candle(candle: LSECandleData):
                print(f"New candle: {candle.symbol} @ {candle.close}")
            
            feed.stream_live_data(["6E", "6J", "6B"], on_new_candle, interval=60)
        """
        logger.info(f"Starting live data stream for {symbols} (interval: {interval}s)")
        
        while True:
            for symbol in symbols:
                try:
                    candle = self.get_latest_candle(symbol)
                    if candle:
                        callback(candle)
                except Exception as e:
                    logger.error(f"Error streaming {symbol}: {e}")
            
            time.sleep(interval)
    
    def rename_all_datasets(self) -> Dict[str, int]:
        """
        Scannt Ordner und wendet human-readable Namen auf alle Datensätze an.
        
        Returns:
            Dictionary mit umbenannten Dateien pro Kategorie
        """
        logger.info("\nRenaming Datasets to Human-Readable Format...")
        stats = {}
        
        # Candles umbenennen
        candles_dir = self.output_dir / "candles"
        if candles_dir.exists():
            count = 0
            for category_path in candles_dir.iterdir():
                if not category_path.is_dir():
                    continue
                for file in category_path.iterdir():
                    if not file.is_file():
                        continue
                    
                    match = re.match(r"^([a-zA-Z0-9_\-]+)_(\d{4})\.csv$", file.name)
                    if match:
                        symbol, year = match.groups()
                        mapping = self.get_symbol_mapping(symbol)
                        if mapping:
                            ticker, human_name = mapping
                            new_name = f"{human_name} ({ticker}) - Candles {year}.csv"
                        else:
                            new_name = f"{symbol.upper()} - Candles {year}.csv"
                        
                        new_path = file.parent / new_name
                        if file != new_path:
                            file.rename(new_path)
                            count += 1
            
            stats["candles"] = count
            logger.info(f"  Renamed {count} Candle files.")
        
        return stats


# Beispiel-Callback für Live-Streaming
def example_candle_callback(candle: LSECandleData) -> None:
    """Beispiel-Callback für neue Candles."""
    logger.info(f"[LIVE] {candle.symbol} | O:{candle.open:.5f} H:{candle.high:.5f} "
               f"L:{candle.low:.5f} C:{candle.close:.5f} V:{candle.volume}")


if __name__ == "__main__":
    # Beispiel-Nutzung
    logging.basicConfig(level=logging.INFO)
    
    feed = LSEFeed(output_dir="./lse_datasets", max_workers=8)
    
    # Setup (Cloudflare-Bypass + Metadaten)
    feed.setup()
    
    # Lade Candles für alle CME-Futures (2024-2026)
    feed.download_candles(years=[2024, 2025, 2026])
    
    # Benenne Dateien um
    feed.rename_all_datasets()
    
    # Lade historische Daten für 6E (Euro FX)
    candles = feed.load_candles("6E", 2026)
    logger.info(f"Geladene Candles für 6E: {len(candles)}")
    
    # Hole neueste Candle
    latest = feed.get_latest_candle("6E")
    if latest:
        logger.info(f"Neueste 6E-Candle: {latest.to_dict()}")
    
    # Starte Live-Stream (uncomment to run)
    # feed.stream_live_data(["6E", "6J", "6B"], example_candle_callback, interval=60)
