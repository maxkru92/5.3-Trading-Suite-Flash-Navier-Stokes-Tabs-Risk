"""
Carry Strategy with Crash Volatility Filter - HYP_02 & HYP_07.

Implements carry trade enhanced with volatility-based crash protection.
Uses skew, risk-reversal, and variance risk premium to filter high-risk
carry positions during stress periods.

Literature: FX-006, FX-007, FX-018, FX-024, FX-054 (HYP_02)
            FX-041, FX-042, FX-067, FX-071 (HYP_07 - Safe Haven/JPY Carry Unwind)

Key Features:
- Interest rate differential as carry signal
- Volatility-based crash filter (skew, risk reversal, VRP)
- Safe-haven detection for JPY carry unwind scenarios
- Logarithmic returns for all calculations
- Volatility-based position sizing
"""

import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

from .base import Strategy, Signal, SignalDirection
from ..data.features import MarketContext, RegimeType

logger = logging.getLogger(__name__)


class CarryCrashFilterStrategy(Strategy):
    """
    Carry trade strategy with crash volatility filter.
    
    This strategy implements the classic carry trade (go long high-yielding
    currencies, short low-yielding currencies) but adds sophisticated
    crash protection based on options market signals.
    
    Literatur: FX-006, FX-007, FX-018, FX-024, FX-054
    
    Crash Filter Components:
    - Skew measure (negative skew = crash fear)
    - Risk reversal 25d delta (put/call asymmetry)
    - Variance risk premium (IV vs RV spread)
    - Volatility level threshold
    
    Safe-Haven Mode (HYP_07):
    - Detects JPY carry unwind conditions
    - Flips positioning during risk-off events
    - Activates when VIX > threshold or credit spreads widen
    """
    
    def __init__(self, params: Optional[Dict[str, Any]] = None):
        """
        Initialize carry strategy with crash filter.
        
        Args:
            params: Strategy parameters
                - crash_vol_threshold: Annualized vol threshold for crash mode (default: 0.25)
                - skew_threshold: Skew threshold for crash filter (default: -0.3)
                - risk_reversal_threshold: 25d RR threshold (default: -0.02)
                - vrp_threshold: Variance risk premium threshold (default: 0.03)
                - target_volatility: Target annualized vol for sizing (default: 0.10)
                - safe_haven_mode: Enable HYP_07 safe-haven logic (default: True)
        """
        default_params = {
            "crash_vol_threshold": 0.25,
            "skew_threshold": -0.3,
            "risk_reversal_threshold": -0.02,
            "vrp_threshold": 0.03,
            "target_volatility": 0.10,
            "safe_haven_mode": True,
            "vix_threshold": 25.0,  # For safe-haven mode
        }
        default_params.update(params or {})
        
        super().__init__(
            strategy_id="HYP_02",
            name="Carry mit Crash-Vol-Filter",
            paper_ids=["FX-006", "FX-007", "FX-018", "FX-024", "FX-054"],
            instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
            params=default_params
        )
        
        self.crash_vol_threshold = self.params["crash_vol_threshold"]
        self.skew_threshold = self.params["skew_threshold"]
        self.risk_reversal_threshold = self.params["risk_reversal_threshold"]
        self.vrp_threshold = self.params["vrp_threshold"]
        self.target_volatility = self.params["target_volatility"]
        self.safe_haven_mode = self.params["safe_haven_mode"]
        self.vix_threshold = self.params["vix_threshold"]
    
    def required_features(self) -> List[str]:
        """
        Return list of required features for carry strategy.
        
        Returns:
            List of feature names needed
        """
        return [
            "interest_rate_differential",
            "carry_score",
            "annualized_vol",
            "skew_63d",  # Proxy for options skew
        ]
    
    def regime_filter(self, context: MarketContext) -> bool:
        """
        Check if current regime allows carry trading.
        
        Carry trades work in RISK_ON regimes but must be closed during:
        - CRASH regimes (liquidity crisis)
        - Strong RISK_OFF regimes (carry unwind)
        
        The crash filter provides additional protection by checking:
        - Volatility level
        - Skew (crash fear indicator)
        - Risk reversal (put/call asymmetry)
        
        Args:
            context: MarketContext with current market state
            
        Returns:
            True if regime allows carry trading AND crash filter passes
        """
        if not context.regime:
            logger.debug(f"{self.strategy_id}: No regime data, using crash filter only")
            return self._check_crash_filter(context)
        
        # Block in CRASH regime
        if context.regime.regime_type == RegimeType.CRASH:
            logger.info(
                f"{self.strategy_id}: Regime filter blocked - CRASH regime detected"
            )
            return False
        
        # Block in strong RISK_OFF if safe-haven mode enabled
        if (context.regime.regime_type == RegimeType.RISK_OFF and 
            self.safe_haven_mode):
            # Check if this is a JPY carry unwind scenario
            if self._is_carry_unwind(context):
                logger.info(
                    f"{self.strategy_id}: Regime filter blocked - JPY carry unwind detected"
                )
                return False
        
        # Apply crash filter regardless of regime
        return self._check_crash_filter(context)
    
    def _check_crash_filter(self, context: MarketContext) -> bool:
        """
        Check crash filter conditions.
        
        Returns False (block trading) if ANY of these conditions are met:
        - Annualized vol > crash_vol_threshold
        - Skew < skew_threshold (strong negative skew = crash fear)
        - Risk reversal < threshold (put demand surge)
        - VRP > threshold (volatility spike expected)
        
        Args:
            context: MarketContext
            
        Returns:
            True if crash filter passes (safe to trade)
        """
        annualized_vol = context.get_feature("annualized_vol", 0.0)
        skew = context.get_feature("skew_63d", 0.0)
        
        # Check volatility level
        if annualized_vol > self.crash_vol_threshold:
            logger.info(
                f"{self.strategy_id}: Crash filter triggered - "
                f"vol={annualized_vol:.2%} > threshold={self.crash_vol_threshold:.2%}"
            )
            return False
        
        # Check skew (negative skew = crash fear)
        if skew < self.skew_threshold:
            logger.info(
                f"{self.strategy_id}: Crash filter triggered - "
                f"skew={skew:.4f} < threshold={self.skew_threshold:.4f}"
            )
            return False
        
        # Check risk reversal if available
        if context.risk_reversal is not None:
            if context.risk_reversal < self.risk_reversal_threshold:
                logger.info(
                    f"{self.strategy_id}: Crash filter triggered - "
                    f"risk_reversal={context.risk_reversal:.4f}"
                )
                return False
        
        # Check variance risk premium if available
        vrp = context.get_feature("variance_risk_premium", 0.0)
        if vrp > self.vrp_threshold:
            logger.info(
                f"{self.strategy_id}: Crash filter triggered - "
                f"vrp={vrp:.4f} > threshold={self.vrp_threshold:.4f}"
            )
            return False
        
        return True
    
    def _is_carry_unwind(self, context: MarketContext) -> bool:
        """
        Detect JPY carry unwind scenario (HYP_07).
        
        Carry unwinds typically occur when:
        - VIX spikes above threshold
        - JPY suddenly appreciates
        - Risk-off flows dominate
        
        Args:
            context: MarketContext
            
        Returns:
            True if carry unwind detected
        """
        if not self.safe_haven_mode:
            return False
        
        # Check VIX level (if available in metadata)
        vix_level = context.metadata.get("vix_level", 0.0)
        if vix_level > self.vix_threshold:
            logger.info(
                f"{self.strategy_id}: Carry unwind detected - "
                f"VIX={vix_level:.1f} > threshold={self.vix_threshold:.1f}"
            )
            return True
        
        # Check for JPY appreciation (if this is a JPY pair)
        if context.symbol in ["6J", "M6J"]:
            log_ret_5d = context.get_feature("log_return_5d", 0.0)
            # Positive log return = JPY appreciation (USD/JPY down)
            if log_ret_5d > 0.03:  # >3% move in 5 days
                logger.info(
                    f"{self.strategy_id}: Carry unwind detected - "
                    f"JPY appreciation log_ret_5d={log_ret_5d:.4f}"
                )
                return True
        
        return False
    
    def generate_signals(self, context: MarketContext) -> List[Signal]:
        """
        Generate carry trade signals with crash filter.
        
        Signal Logic:
        1. Calculate carry score from interest rate differential
        2. If carry_score > threshold AND crash filter passes → LONG
        3. If carry_score < -threshold AND crash filter passes → SHORT
        4. If crash filter fails → FLAT (no position)
        
        In safe-haven mode (HYP_07):
        - During carry unwind, flip signals (short high-yielders)
        
        Args:
            context: MarketContext with current market state
            
        Returns:
            List of Signal objects (0 or 1 signal)
        """
        # Validate context first
        if not self.validate_context(context):
            logger.warning(f"{self.strategy_id}: Context validation failed for {context.symbol}")
            return []
        
        # Check regime filter (includes crash filter)
        if not self.regime_filter(context):
            logger.debug(f"{self.strategy_id}: Regime/crash filter failed for {context.symbol}")
            return []
        
        # Get current price
        current_price = context.current_price
        if not current_price or current_price <= 0:
            logger.warning(f"{self.strategy_id}: Invalid current price for {context.symbol}")
            return []
        
        # Extract features
        carry_score = context.get_feature("carry_score", 0.0)
        interest_rate_diff = context.get_feature("interest_rate_differential", 0.0)
        annualized_vol = context.get_feature("annualized_vol", 0.0)
        skew = context.get_feature("skew_63d", 0.0)
        
        # Determine signal direction
        # Positive carry score = long this currency (high yielder)
        # Negative carry score = short this currency (low yielder)
        signal_threshold = 0.3  # Minimum carry score for signal
        
        if abs(carry_score) < signal_threshold:
            logger.debug(
                f"{self.strategy_id}: Carry score {carry_score:.4f} below "
                f"threshold {signal_threshold} for {context.symbol}"
            )
            return []
        
        # Check for safe-haven mode flip
        if self.safe_haven_mode and self._is_carry_unwind(context):
            # Flip signal during carry unwind
            carry_score = -carry_score
            logger.info(
                f"{self.strategy_id}: Safe-haven mode active - flipping carry signal"
            )
        
        # Calculate signal strength
        signal_strength = min(abs(carry_score), 1.0)
        
        # Determine direction
        if carry_score > 0:
            direction = SignalDirection.LONG
        else:
            direction = SignalDirection.SHORT
        
        # Calculate stop loss and take profit
        stop_loss = self.calculate_stop_loss(
            entry_price=current_price,
            direction=direction,
            stop_loss_pct=0.025,  # 2.5% stop (slightly wider for carry)
        )
        
        take_profit = self.calculate_take_profit(
            entry_price=current_price,
            direction=direction,
            take_profit_pct=0.05,  # 5% target (carry trades run longer)
        )
        
        # Build features used dictionary
        features_used = {
            "carry_score": carry_score,
            "interest_rate_differential": interest_rate_diff,
            "annualized_vol": annualized_vol,
            "skew_63d": skew,
            "daily_vol": annualized_vol / 17.9,
        }
        
        # Create signal
        signal = Signal(
            strategy_id=self.strategy_id,
            symbol=context.symbol,
            direction=direction,
            timestamp=datetime.utcnow(),
            strength=signal_strength,
            entry_price=current_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            features_used=features_used,
            metadata={
                "regime": context.regime.regime_type.value if context.regime else "UNKNOWN",
                "crash_filter_passed": True,
                "safe_haven_mode_active": self.safe_haven_mode and self._is_carry_unwind(context),
                "interest_rate_domestic": context.interest_rate_domestic,
                "interest_rate_foreign": context.interest_rate_foreign,
            },
            paper_ids=self.paper_ids
        )
        
        logger.info(
            f"{self.strategy_id}: Generated {direction.value} signal for {context.symbol} "
            f"with strength {signal_strength:.2f}, carry_score={carry_score:.4f}, "
            f"entry={current_price:.6f}"
        )
        
        return [signal]
    
    def calculate_position_size_for_signal(
        self,
        signal: Signal,
        nav: float,
        instrument_notional: float,
        max_position_pct: float = 0.12
    ) -> int:
        """
        Calculate position size for a specific signal.
        
        Uses inverse volatility targeting with lower target vol than momentum
        (carry trades are more sensitive to vol spikes).
        
        Args:
            signal: Signal object with features_used
            nav: Portfolio NAV
            instrument_notional: Contract notional value
            max_position_pct: Maximum position as % of NAV
            
        Returns:
            Number of contracts
        """
        annualized_vol = signal.features_used.get("annualized_vol", 0.10)
        
        return super().calculate_position_size(
            nav=nav,
            target_volatility=self.target_volatility,
            annualized_vol=annualized_vol,
            instrument_notional=instrument_notional,
            max_position_pct=max_position_pct
        )
