"""
Time-Series Momentum Strategy - HYP_01.

Implements time-series momentum in currency futures using multiple lookback periods.
Signals are generated when momentum exceeds threshold AND regime filter passes.

Literature: FX-004 (Menkhoff et al. 2012), FX-005, FX-012, FX-023

Key Features:
- Multi-horizon momentum scoring (21d, 63d, 126d)
- Logarithmic return calculations exclusively
- Volatility-based position sizing
- Regime filter: TREND or NEUTRAL markets only
"""

import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

from .base import Strategy, Signal, SignalDirection
from ..data.features import MarketContext, RegimeType

logger = logging.getLogger(__name__)


class MomentumStrategy(Strategy):
    """
    Time-Series Momentum strategy for currency futures.
    
    This strategy exploits the well-documented momentum anomaly in FX markets,
    where currencies that have appreciated (depreciated) continue to do so
    over medium-term horizons (1-12 months).
    
    Literatur: FX-004 (Menkhoff et al. 2012), FX-005, FX-012, FX-023
    
    Implementation Details:
    - Uses logarithmic returns for all calculations
    - Combines 21-day, 63-day, and 126-day momentum signals
    - Only trades in TREND or NEUTRAL regimes
    - Position size inversely proportional to volatility
    """
    
    def __init__(self, params: Optional[Dict[str, Any]] = None):
        """
        Initialize momentum strategy.
        
        Args:
            params: Strategy parameters
                - lookback_short: Short momentum lookback (default: 21)
                - lookback_medium: Medium momentum lookback (default: 63)
                - lookback_long: Long momentum lookback (default: 126)
                - signal_threshold: Minimum momentum score for signal (default: 0.15)
                - target_volatility: Target annualized vol for sizing (default: 0.12)
        """
        default_params = {
            "lookback_short": 21,
            "lookback_medium": 63,
            "lookback_long": 126,
            "signal_threshold": 0.15,
            "target_volatility": 0.12,
        }
        default_params.update(params or {})
        
        super().__init__(
            strategy_id="HYP_01",
            name="Time-Series Momentum",
            paper_ids=["FX-004", "FX-005", "FX-012", "FX-023"],
            instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
            params=default_params
        )
        
        self.lookback_short = self.params["lookback_short"]
        self.lookback_medium = self.params["lookback_medium"]
        self.lookback_long = self.params["lookback_long"]
        self.signal_threshold = self.params["signal_threshold"]
        self.target_volatility = self.params["target_volatility"]
    
    def required_features(self) -> List[str]:
        """
        Return list of required features for momentum strategy.
        
        Returns:
            List of feature names needed
        """
        return [
            "momentum_score",
            "annualized_vol",
            "log_return_21d",
            "log_return_63d",
            "log_return_126d",
        ]
    
    def regime_filter(self, context: MarketContext) -> bool:
        """
        Check if current regime allows momentum trading.
        
        Momentum strategies work best in:
        - TREND regimes (strong directional movement)
        - NEUTRAL regimes (no clear mean-reversion)
        
        Avoid:
        - RANGE regimes (mean-reverting conditions)
        - CRASH regimes (liquidity crisis, trend breaks)
        
        Args:
            context: MarketContext with current market state
            
        Returns:
            True if regime allows momentum trading
        """
        if not context.regime:
            # Default to allowing trade if no regime data
            logger.debug(f"{self.strategy_id}: No regime data, allowing by default")
            return True
        
        allowed_regimes = [RegimeType.TREND, RegimeType.NEUTRAL, RegimeType.RISK_ON]
        
        is_allowed = context.regime.regime_type in allowed_regimes
        
        if not is_allowed:
            logger.info(
                f"{self.strategy_id}: Regime filter blocked - "
                f"current regime: {context.regime.regime_type.value}"
            )
        
        return is_allowed
    
    def generate_signals(self, context: MarketContext) -> List[Signal]:
        """
        Generate momentum trading signals.
        
        Signal Logic:
        1. Calculate composite momentum score from multiple horizons
        2. If momentum > threshold → LONG signal
        3. If momentum < -threshold → SHORT signal
        4. If |momentum| < threshold → No signal (FLAT)
        
        Args:
            context: MarketContext with current market state
            
        Returns:
            List of Signal objects (0 or 1 signal)
        """
        # Validate context first
        if not self.validate_context(context):
            logger.warning(f"{self.strategy_id}: Context validation failed for {context.symbol}")
            return []
        
        # Check regime filter
        if not self.regime_filter(context):
            logger.debug(f"{self.strategy_id}: Regime filter failed for {context.symbol}")
            return []
        
        # Get current price
        current_price = context.current_price
        if not current_price or current_price <= 0:
            logger.warning(f"{self.strategy_id}: Invalid current price for {context.symbol}")
            return []
        
        # Extract features
        momentum_score = context.get_feature("momentum_score", 0.0)
        annualized_vol = context.get_feature("annualized_vol", 0.0)
        log_ret_21d = context.get_feature("log_return_21d", 0.0)
        log_ret_63d = context.get_feature("log_return_63d", 0.0)
        log_ret_126d = context.get_feature("log_return_126d", 0.0)
        
        # Determine signal direction and strength
        if abs(momentum_score) < self.signal_threshold:
            # Momentum too weak - no signal
            logger.debug(
                f"{self.strategy_id}: Momentum score {momentum_score:.4f} below "
                f"threshold {self.signal_threshold} for {context.symbol}"
            )
            return []
        
        # Calculate signal strength (normalized to 0-1)
        signal_strength = min(abs(momentum_score), 1.0)
        
        # Determine direction
        if momentum_score > 0:
            direction = SignalDirection.LONG
        else:
            direction = SignalDirection.SHORT
        
        # Calculate stop loss and take profit
        stop_loss = self.calculate_stop_loss(
            entry_price=current_price,
            direction=direction,
            stop_loss_pct=0.02,  # 2% stop
        )
        
        take_profit = self.calculate_take_profit(
            entry_price=current_price,
            direction=direction,
            take_profit_pct=0.04,  # 4% target
        )
        
        # Build features used dictionary
        features_used = {
            "momentum_score": momentum_score,
            "annualized_vol": annualized_vol,
            "daily_vol": annualized_vol / 17.9,  # Approximate daily vol
            "log_return_21d": log_ret_21d,
            "log_return_63d": log_ret_63d,
            "log_return_126d": log_ret_126d,
        }
        
        # Create signal
        signal = Signal(
            strategy_id=self.strategy_id,
            symbol=context.symbol,
            direction=direction,
            timestamp=datetime.utcnow(),
            strength=signal_strength,
            entry_price=current_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            features_used=features_used,
            metadata={
                "lookback_short": self.lookback_short,
                "lookback_medium": self.lookback_medium,
                "lookback_long": self.lookback_long,
                "regime": context.regime.regime_type.value if context.regime else "UNKNOWN",
                "trend_direction": context.regime.trend_direction if context.regime else None,
            },
            paper_ids=self.paper_ids
        )
        
        logger.info(
            f"{self.strategy_id}: Generated {direction.value} signal for {context.symbol} "
            f"with strength {signal_strength:.2f}, entry={current_price:.6f}"
        )
        
        return [signal]
    
    def calculate_position_size_for_signal(
        self,
        signal: Signal,
        nav: float,
        instrument_notional: float,
        max_position_pct: float = 0.15
    ) -> int:
        """
        Calculate position size for a specific signal.
        
        Uses inverse volatility targeting based on signal's features.
        
        Args:
            signal: Signal object with features_used
            nav: Portfolio NAV
            instrument_notional: Contract notional value
            max_position_pct: Maximum position as % of NAV
            
        Returns:
            Number of contracts
        """
        annualized_vol = signal.features_used.get("annualized_vol", 0.12)
        
        return super().calculate_position_size(
            nav=nav,
            target_volatility=self.target_volatility,
            annualized_vol=annualized_vol,
            instrument_notional=instrument_notional,
            max_position_pct=max_position_pct
        )
