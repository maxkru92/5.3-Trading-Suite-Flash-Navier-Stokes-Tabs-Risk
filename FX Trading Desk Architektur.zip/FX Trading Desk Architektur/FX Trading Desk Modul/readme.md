# Institutional-grade FX Trading Desk Modul -KC-

Projektstruktur:

---

fx_desk/
├── config/
│   ├── instruments.py       # InstrumentConfig für 6E, 6J, 6B, 6A, 6C, 6S, 6N, Micros
│   └── strategies.py        # StrategyConfig-Registry, referenziert die 12 Hypothesen + Paper-IDs
├── data/
│   ├── feed_interface.py    # abstrakte MarketDataFeed-Klasse (Live)
│   ├── historical_store.py  # HistoricalDataStore für Backtests, Continuous-Contract-Roll-Logik
│   └── features.py          # Feature-Engineering: log-returns, realized vol, IV-RV-spread, COT-z-score, term structure slope, skew/risk reversal, HMM-Regime-State
├── strategies/
│   ├── base.py               # abstrakte Strategy-Basisklasse
│   ├── momentum.py            # Hypothese 1
│   ├── carry_crash_filter.py  # Hypothese 2, 7
│   ├── value_ppp.py           # Hypothese 3
│   ├── cot_positioning.py     # Hypothese 4
│   ├── vol_risk_premium.py    # Hypothese 5
│   ├── options_skew.py        # Hypothese 6
│   ├── calendar_spread.py     # Hypothese 8
│   ├── mean_reversion.py      # Hypothese 9
│   ├── event_regime_nlp.py    # Hypothese 10 (nur als optionaler, klar gekennzeichneter Baustein)
│   └── ml_regime_filter.py    # Hypothese 11/12, HMM + einfacher Klassifikator, NICHT Alpha-Quelle
├── screening/
│   ├── screening_engine.py    # Dauerlauf-Loop, evaluiert alle Strategien x Instrumente
│   ├── signal_bus.py
│   └── signal_aggregator.py   # Multi-Strategie-Score, Konfliktauflösung
├── risk/
│   ├── risk_manager.py        # Vol-Targeting-Sizing, Max-Leverage, Max-Drawdown, Tail-Risk-Limits
│   └── portfolio_allocator.py
├── execution/
│   ├── execution_engine.py    # Order-Übersetzung, Slippage-/Kostenmodell, Roll-Execution
│   └── broker_adapter.py      # Interface für z.B. Interactive Brokers API
├── backtest/
│   ├── backtest_engine.py     # Event-getriebener Backtest
│   └── validation_suite.py    # Walk-Forward, Monte Carlo, Deflated Sharpe Ratio, White Reality Check
├── suggestions/
│   └── trade_suggestion.py    # TradeSuggestion-Datenmodell + Review-/Auto-Trade-Interface
├── main.py                    # Orchestrierung: Registrierung, Start des Screeners, Ausgabe
└── tests/
   └── ...                    # Unit-Tests für Kern-Komponenten
