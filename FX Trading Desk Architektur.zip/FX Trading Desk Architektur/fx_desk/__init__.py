"""
FX Trading Desk Modul - Institutional Grade Architecture

ARCHITEKTUR-ÜBERSICHT:
======================

Dieses Modul implementiert eine vollständige FX-Trading-Desk-Plattform für einen 
institutionellen Hedgefonds. Die Architektur folgt strengen Prinzipien:

1. TRENNUNG VON SORGEN (Separation of Concerns):
   - Data Layer: MarketDataFeed, HistoricalDataStore, Feature-Engineering
   - Strategy Layer: 12 Strategie-Hypothesen als unabhängige Module
   - Screening Layer: Dauerlauf zur Signalerkennung über alle Strategien/Instrumente
   - Risk Layer: Vol-Targeting, Drawdown-Limits, Tail-Risk-Überwachung
   - Execution Layer: Order-Übersetzung, Slippage-Modellierung, Broker-Integration
   - Backtest Layer: Walk-Forward, Monte-Carlo, Deflated-Sharpe-Ratio

2. STRATEGIE-INTEGRATION:
   - Jede der 12 Hypothesen ist als eigenständige Strategy-Klasse implementiert
   - Paper-Referenzen sind im Docstring jeder Strategie dokumentiert
   - ML-Modelle dienen AUSSCHLIESSLICH als Regime-Filter (nicht als Alpha-Quelle)
   - Reinforcement Learning ist explizit ausgeschlossen (Production-ungeeignet)

3. RISIKOMANAGEMENT:
   - Positionsgrößen basieren ausschließlich auf inverser Volatilität (Vol-Targeting)
   - Harte Limits: Max-Leverage, Max-Drawdown, Tail-Risk
   - Jede Position wird mit Begründung (Strategie + Paper-IDs + Features) protokolliert

4. VALIDIERUNG:
   - Vor Live-Aktivierung: Walk-Forward-Analyse, Monte-Carlo-Simulation, 
     Deflated-Sharpe-Ratio, White-Reality-Check
   - Kostenmodellierung: Slippage, Kommissionen, Roll-Kosten sind obligatorisch

5. PRODUKTIONSREADINESS:
   - Dependency-Injection für alle externen Abhängigkeiten
   - Type Hints und Google-Style-Docstrings durchgängig
   - Logging statt print() für Production-Tracking
   - Async-fähige Screening-Engine für Echtzeit-Verarbeitung

DATENFLUSS:
===========
MarketDataFeed → Feature-Engine → [Strategy 1..12] → SignalAggregator → 
RiskManager → ExecutionEngine → BrokerAdapter

Jede Strategie prüft zuerst den Regime-Filter (ML-basiert), dann generiert sie 
Signale nur bei positivem Filter-Ergebnis. Der SignalAggregator löst Konflikte 
auf (z.B. Long-Signal aus Momentum vs. Short-Signal aus Value).

PAPER-REFERENZEN:
=================
- FX-001 bis FX-100: Basis-Papers zu Futures, Options, Volatility, Factors, Macro, Micro
- AI-001 bis AI-022: ML/AI-Papers (davon nur AI-007–AI-011 für Produktion freigegeben)
- FX-031, FX-032: Methodische Referenzen für Backtest-Validierung

"""
