"""
Instrument Configuration für FX Futures und Micros.

Definiert alle handelbaren Instrumente mit ihren Spezifikationen:
- CME FX Futures: 6E (EUR), 6J (JPY), 6B (GBP), 6A (AUD), 6C (CAD), 6S (CHF), 6N (NZD)
- Micro FX Futures: M6E, M6J, M6B, M6A, M6C, M6S, M6N
- Contract-Größen, Tick-Werte, Margin-Anforderungen, Roll-Schedule
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum


class CurrencyCode(Enum):
    """ISO 4217 Currency Codes."""
    EUR = "EUR"
    JPY = "JPY"
    GBP = "GBP"
    AUD = "AUD"
    CAD = "CAD"
    CHF = "CHF"
    NZD = "NZD"
    USD = "USD"


class ContractMonth(Enum):
    """CME Futures Contract Months."""
    H = "March"      # März
    M = "June"       # Juni
    U = "September"  # September
    Z = "December"   # Dezember


@dataclass(frozen=True)
class InstrumentConfig:
    """
    Konfiguration eines FX-Futures-Instruments.
    
    Attributes:
        symbol: CME-Symbol (z.B. '6E', 'M6E')
        currency: Basiswährung als CurrencyCode
        contract_size: Kontraktgröße in Einheiten der Basiswährung
        tick_size: Minimale Preisbewegung in Quote-Währung (USD)
        tick_value: USD-Wert pro Tick
        initial_margin: Initiale Margin-Anforderung in USD
        maintenance_margin: Maintenance Margin in USD
        roll_days_before_expiry: Anzahl Tage vor Verfall für Roll
        trading_hours: Handelszeiten als String (z.B. '17:00-16:00 CT')
        quote_currency: Quote-Währung (immer USD für CME FX Futures)
    """
    symbol: str
    currency: CurrencyCode
    contract_size: int
    tick_size: float
    tick_value: float
    initial_margin: float
    maintenance_margin: float
    roll_days_before_expiry: int
    trading_hours: str
    quote_currency: CurrencyCode = CurrencyCode.USD
    
    def __post_init__(self):
        """Validierung der Konfiguration."""
        if self.contract_size <= 0:
            raise ValueError("contract_size muss positiv sein")
        if self.tick_size <= 0:
            raise ValueError("tick_size muss positiv sein")
        if self.tick_value <= 0:
            raise ValueError("tick_value muss positiv sein")
    
    def get_contract_symbol(self, year: int, month: ContractMonth) -> str:
        """
        Generiert das vollständige Futures-Symbol für ein gegebenes Verfallsdatum.
        
        Args:
            year: Verfallsjahr (z.B. 2025)
            month: Verfallsmonat als ContractMonth
            
        Returns:
            Vollständiges Symbol (z.B. '6EH25' für März 2025)
        """
        month_code = month.value[0]  # Erster Buchstabe des Monatsnamens
        year_suffix = str(year)[-2:]
        return f"{self.symbol}{month_code}{year_suffix}"
    
    def ticks_to_usd(self, ticks: float) -> float:
        """
        Konvertiert Ticks in USD-Wert.
        
        Args:
            ticks: Anzahl Ticks
            
        Returns:
            USD-Wert
        """
        return ticks * self.tick_value
    
    def usd_to_ticks(self, usd_amount: float) -> float:
        """
        Konvertiert USD-Betrag in Ticks.
        
        Args:
            usd_amount: USD-Betrag
            
        Returns:
            Anzahl Ticks
        """
        return usd_amount / self.tick_value


# ============================================================================
# STANDARD FX FUTURES (CME)
# ============================================================================

INSTRUMENT_CONFIGS: Dict[str, InstrumentConfig] = {
    # EUR/USD - Euro FX Futures
    "6E": InstrumentConfig(
        symbol="6E",
        currency=CurrencyCode.EUR,
        contract_size=125_000,
        tick_size=0.0001,
        tick_value=12.50,
        initial_margin=5_500,
        maintenance_margin=5_000,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    # JPY/USD - Japanese Yen Futures
    "6J": InstrumentConfig(
        symbol="6J",
        currency=CurrencyCode.JPY,
        contract_size=12_500_000,
        tick_size=0.0000005,
        tick_value=6.25,
        initial_margin=3_800,
        maintenance_margin=3_500,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    # GBP/USD - British Pound Futures
    "6B": InstrumentConfig(
        symbol="6B",
        currency=CurrencyCode.GBP,
        contract_size=62_500,
        tick_size=0.0001,
        tick_value=6.25,
        initial_margin=4_200,
        maintenance_margin=3_800,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    # AUD/USD - Australian Dollar Futures
    "6A": InstrumentConfig(
        symbol="6A",
        currency=CurrencyCode.AUD,
        contract_size=100_000,
        tick_size=0.0001,
        tick_value=10.00,
        initial_margin=3_500,
        maintenance_margin=3_200,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    # CAD/USD - Canadian Dollar Futures
    "6C": InstrumentConfig(
        symbol="6C",
        currency=CurrencyCode.CAD,
        contract_size=100_000,
        tick_size=0.0001,
        tick_value=10.00,
        initial_margin=3_200,
        maintenance_margin=2_900,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    # CHF/USD - Swiss Franc Futures
    "6S": InstrumentConfig(
        symbol="6S",
        currency=CurrencyCode.CHF,
        contract_size=125_000,
        tick_size=0.0001,
        tick_value=12.50,
        initial_margin=4_000,
        maintenance_margin=3_600,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    # NZD/USD - New Zealand Dollar Futures
    "6N": InstrumentConfig(
        symbol="6N",
        currency=CurrencyCode.NZD,
        contract_size=100_000,
        tick_size=0.0001,
        tick_value=10.00,
        initial_margin=3_000,
        maintenance_margin=2_700,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    # MICRO FX FUTURES
    "M6E": InstrumentConfig(
        symbol="M6E",
        currency=CurrencyCode.EUR,
        contract_size=12_500,  # 1/10 der Standard-Größe
        tick_size=0.0001,
        tick_value=1.25,
        initial_margin=550,
        maintenance_margin=500,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    "M6J": InstrumentConfig(
        symbol="M6J",
        currency=CurrencyCode.JPY,
        contract_size=1_250_000,
        tick_size=0.0000005,
        tick_value=0.625,
        initial_margin=380,
        maintenance_margin=350,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    "M6B": InstrumentConfig(
        symbol="M6B",
        currency=CurrencyCode.GBP,
        contract_size=6_250,
        tick_size=0.0001,
        tick_value=0.625,
        initial_margin=420,
        maintenance_margin=380,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    "M6A": InstrumentConfig(
        symbol="M6A",
        currency=CurrencyCode.AUD,
        contract_size=10_000,
        tick_size=0.0001,
        tick_value=1.00,
        initial_margin=350,
        maintenance_margin=320,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    "M6C": InstrumentConfig(
        symbol="M6C",
        currency=CurrencyCode.CAD,
        contract_size=10_000,
        tick_size=0.0001,
        tick_value=1.00,
        initial_margin=320,
        maintenance_margin=290,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    "M6S": InstrumentConfig(
        symbol="M6S",
        currency=CurrencyCode.CHF,
        contract_size=12_500,
        tick_size=0.0001,
        tick_value=1.25,
        initial_margin=400,
        maintenance_margin=360,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
    
    "M6N": InstrumentConfig(
        symbol="M6N",
        currency=CurrencyCode.NZD,
        contract_size=10_000,
        tick_size=0.0001,
        tick_value=1.00,
        initial_margin=300,
        maintenance_margin=270,
        roll_days_before_expiry=5,
        trading_hours="17:00-16:00 CT",
    ),
}


def get_instrument(symbol: str) -> InstrumentConfig:
    """
    Ruft die Konfiguration für ein Instrument ab.
    
    Args:
        symbol: Instrumentsymbol (z.B. '6E', 'M6E')
        
    Returns:
        InstrumentConfig für das angegebene Symbol
        
    Raises:
        KeyError: Wenn das Symbol nicht gefunden wird
    """
    if symbol not in INSTRUMENT_CONFIGS:
        raise KeyError(f"Instrument '{symbol}' nicht gefunden. "
                      f"Verfügbare Symbole: {list(INSTRUMENT_CONFIGS.keys())}")
    return INSTRUMENT_CONFIGS[symbol]


def get_all_instruments() -> List[InstrumentConfig]:
    """
    Gibt alle verfügbaren Instrumentenkonfigurationen zurück.
    
    Returns:
        Liste aller InstrumentConfig-Objekte
    """
    return list(INSTRUMENT_CONFIGS.values())


def get_standard_fx_futures() -> List[InstrumentConfig]:
    """
    Gibt nur die Standard-FX-Futures zurück (ohne Micros).
    
    Returns:
        Liste der Standard-FX-Futures InstrumentConfigs
    """
    return [cfg for cfg in INSTRUMENT_CONFIGS.values() 
            if not cfg.symbol.startswith("M")]


def get_micro_fx_futures() -> List[InstrumentConfig]:
    """
    Gibt nur die Micro-FX-Futures zurück.
    
    Returns:
        Liste der Micro-FX-Futures InstrumentConfigs
    """
    return [cfg for cfg in INSTRUMENT_CONFIGS.values() 
            if cfg.symbol.startswith("M")]
