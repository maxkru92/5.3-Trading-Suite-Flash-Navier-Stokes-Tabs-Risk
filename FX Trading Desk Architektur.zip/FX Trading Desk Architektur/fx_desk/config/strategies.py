"""
Strategy Configuration Registry.

Registriert alle 12 Strategie-Hypothesen mit ihren Metadaten:
- Paper-Referenzen aus der Masterbibliographie
- Geeignete Märkte/Instrumente
- Erwartete Haltezeiten
- Kosten-/Slippage-Sensitivität
- Evidenzstärke
- Hauptfehlerquellen
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class StrategyCategory(Enum):
    """Kategorien für Strategien basierend auf den Paper-Tags."""
    MOMENTUM = "MOMENTUM"
    CARRY = "CARRY"
    VALUE = "VALUE"
    POSITIONING = "POSITIONING"
    VOLATILITY = "VOLATILITY"
    OPTIONS = "OPTIONS"
    TERM_STRUCTURE = "TERM_STRUCTURE"
    MEAN_REVERSION = "MEAN_REVERSION"
    EVENT_DRIVEN = "EVENT_DRIVEN"
    ML_FILTER = "ML_FILTER"


class EvidenceStrength(Enum):
    """Evidenzstärke basierend auf der Literatur."""
    STRONG = "STRONG"           # Multiple unabhängige Studien, lange Historie
    MODERATE = "MODERATE"       # Einige Studien, konsistente Ergebnisse
    EMERGING = "EMERGING"       # Begrenzte Evidenz, vielversprechend
    SPECULATIVE = "SPECULATIVE" # Theoretisch plausibel, wenig empirische Daten


@dataclass(frozen=True)
class StrategyConfig:
    """
    Konfiguration einer Trading-Strategie.
    
    Attributes:
        strategy_id: Eindeutige ID der Strategie (z.B. 'HYP_01')
        name: Menschlesbarer Name
        category: Strategie-Kategorie
        hypothesis_number: Nummer der Hypothese (1-12) aus der Synthese
        paper_ids: Liste der Paper-IDs aus der Masterbibliographie
        instruments: Liste der geeigneten Instrumente (z.B. ['6E', '6J', '6B'])
        holding_period_days: Erwartete Haltezeit in Tagen
        turnover_expected: Erwarteter Umsatz (Low/Medium/High)
        cost_sensitivity: Sensitivität gegenüber Kosten/Slippage (Low/Medium/High)
        evidence_strength: Evidenzstärke laut Literatur
        primary_risk: Hauptfehlerquelle/Risiko
        requires_options_data: Benötigt Optionsdaten (IV, Skew, etc.)
        requires_cot_data: Benötigt COT-Positionierungsdaten
        ml_filter_required: Benötigt ML-Regime-Filter
        activation_threshold_min_sharpe: Minimaler Sharpe für Live-Aktivierung
        walk_forward_required: Walk-Forward-Test obligatorisch vor Aktivierung
    """
    strategy_id: str
    name: str
    category: StrategyCategory
    hypothesis_number: int
    paper_ids: List[str]
    instruments: List[str]
    holding_period_days: int
    turnover_expected: str  # 'LOW', 'MEDIUM', 'HIGH'
    cost_sensitivity: str   # 'LOW', 'MEDIUM', 'HIGH'
    evidence_strength: EvidenceStrength
    primary_risk: str
    requires_options_data: bool = False
    requires_cot_data: bool = False
    ml_filter_required: bool = False
    activation_threshold_min_sharpe: float = 1.0
    walk_forward_required: bool = True
    
    def __post_init__(self):
        """Validierung der Konfiguration."""
        if self.holding_period_days <= 0:
            raise ValueError("holding_period_days muss positiv sein")
        if self.turnover_expected not in ['LOW', 'MEDIUM', 'HIGH']:
            raise ValueError("turnover_expected muss LOW, MEDIUM oder HIGH sein")
        if self.cost_sensitivity not in ['LOW', 'MEDIUM', 'HIGH']:
            raise ValueError("cost_sensitivity muss LOW, MEDIUM oder HIGH sein")
        if not self.paper_ids:
            logger.warning(f"Strategie {self.strategy_id} hat keine Paper-IDs")


# ============================================================================
# STRATEGIE-REGISTRY - Alle 12 Hypothesen
# ============================================================================

STRATEGY_REGISTRY: Dict[str, StrategyConfig] = {
    # Hypothese 1: Time-Series-Momentum in Currency Futures
    "HYP_01": StrategyConfig(
        strategy_id="HYP_01",
        name="Time-Series Momentum",
        category=StrategyCategory.MOMENTUM,
        hypothesis_number=1,
        paper_ids=["FX-004", "FX-005", "FX-012", "FX-023"],
        instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
        holding_period_days=21,
        turnover_expected="MEDIUM",
        cost_sensitivity="MEDIUM",
        evidence_strength=EvidenceStrength.STRONG,
        primary_risk="Regime-Wechsel von Trend zu Range",
        ml_filter_required=True,
    ),
    
    # Hypothese 2: Carry mit Crash-Vol-Filter
    "HYP_02": StrategyConfig(
        strategy_id="HYP_02",
        name="Carry with Crash-Vol Filter",
        category=StrategyCategory.CARRY,
        hypothesis_number=2,
        paper_ids=["FX-006", "FX-007", "FX-034", "FX-054"],
        instruments=["6E", "6J", "6B", "6A", "6N"],
        holding_period_days=63,
        turnover_expected="LOW",
        cost_sensitivity="LOW",
        evidence_strength=EvidenceStrength.STRONG,
        primary_risk="Tail-Risk / Carry-Unwind Events",
        requires_options_data=True,
        ml_filter_required=True,
    ),
    
    # Hypothese 3: Currency-Value/PPP als langsamer Drift-Faktor
    "HYP_03": StrategyConfig(
        strategy_id="HYP_03",
        name="Currency Value / PPP",
        category=StrategyCategory.VALUE,
        hypothesis_number=3,
        paper_ids=["FX-008", "FX-009", "FX-024"],
        instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
        holding_period_days=252,
        turnover_expected="LOW",
        cost_sensitivity="LOW",
        evidence_strength=EvidenceStrength.MODERATE,
        primary_risk="Lange Drawdown-Perioden, Timing-Risiko",
    ),
    
    # Hypothese 4: COT-Positionierungs-Extremsignale
    "HYP_04": StrategyConfig(
        strategy_id="HYP_04",
        name="COT Positioning Extremes",
        category=StrategyCategory.POSITIONING,
        hypothesis_number=4,
        paper_ids=["FX-041", "FX-042", "FX-043"],
        instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
        holding_period_days=42,
        turnover_expected="LOW",
        cost_sensitivity="LOW",
        evidence_strength=EvidenceStrength.MODERATE,
        primary_risk="Frühzeitige Gegenpositionierung bei anhaltendem Trend",
        requires_cot_data=True,
    ),
    
    # Hypothese 5: Volatility-Risk-Premium (IV vs. RV)
    "HYP_05": StrategyConfig(
        strategy_id="HYP_05",
        name="Volatility Risk Premium",
        category=StrategyCategory.VOLATILITY,
        hypothesis_number=5,
        paper_ids=["FX-034", "FX-035", "FX-036", "AI-007"],
        instruments=["6E", "6J", "6B"],
        holding_period_days=21,
        turnover_expected="MEDIUM",
        cost_sensitivity="MEDIUM",
        evidence_strength=EvidenceStrength.STRONG,
        primary_risk="Volatilitäts-Spike, IV-Expansion",
        requires_options_data=True,
    ),
    
    # Hypothese 6: FX-Options-Skew/Smile/Risk-Reversal
    "HYP_06": StrategyConfig(
        strategy_id="HYP_06",
        name="Options Skew / Risk Reversal",
        category=StrategyCategory.OPTIONS,
        hypothesis_number=6,
        paper_ids=["FX-037", "FX-038", "FX-054"],
        instruments=["6E", "6J", "6B"],
        holding_period_days=21,
        turnover_expected="MEDIUM",
        cost_sensitivity="HIGH",
        evidence_strength=EvidenceStrength.MODERATE,
        primary_risk="Skew-Inversion, Liquiditätsrisiko",
        requires_options_data=True,
    ),
    
    # Hypothese 7: Safe-Haven/JPY-Carry-Unwind-Regime
    "HYP_07": StrategyConfig(
        strategy_id="HYP_07",
        name="Safe Haven / JPY Carry Unwind",
        category=StrategyCategory.CARRY,
        hypothesis_number=7,
        paper_ids=["FX-007", "FX-044", "FX-045"],
        instruments=["6J", "6E", "6A", "6N"],
        holding_period_days=14,
        turnover_expected="HIGH",
        cost_sensitivity="MEDIUM",
        evidence_strength=EvidenceStrength.MODERATE,
        primary_risk="Falsche Regime-Erkennung, späte Ausstiege",
        ml_filter_required=True,
    ),
    
    # Hypothese 8: Calendar-/Termstruktur-Spreads
    "HYP_08": StrategyConfig(
        strategy_id="HYP_08",
        name="Calendar Spread / Term Structure",
        category=StrategyCategory.TERM_STRUCTURE,
        hypothesis_number=8,
        paper_ids=["FX-025", "FX-026"],
        instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
        holding_period_days=30,
        turnover_expected="MEDIUM",
        cost_sensitivity="MEDIUM",
        evidence_strength=EvidenceStrength.EMERGING,
        primary_risk="Roll-Kosten, Termstruktur-Inversion",
    ),
    
    # Hypothese 9: Mean Reversion unter Liquiditäts-/Regimebedingungen
    "HYP_09": StrategyConfig(
        strategy_id="HYP_09",
        name="Mean Reversion (Conditional)",
        category=StrategyCategory.MEAN_REVERSION,
        hypothesis_number=9,
        paper_ids=["FX-013", "FX-014", "FX-027"],
        instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
        holding_period_days=7,
        turnover_expected="HIGH",
        cost_sensitivity="HIGH",
        evidence_strength=EvidenceStrength.MODERATE,
        primary_risk="Trend-Regime statt Range, Stop-Outs",
        ml_filter_required=True,
    ),
    
    # Hypothese 10: Event-/Zentralbank-Regime mit NLP-Filter
    "HYP_10": StrategyConfig(
        strategy_id="HYP_10",
        name="Event / Central Bank Regime (NLP)",
        category=StrategyCategory.EVENT_DRIVEN,
        hypothesis_number=10,
        paper_ids=["AI-018", "AI-019", "AI-020"],
        instruments=["6E", "6J", "6B"],
        holding_period_days=5,
        turnover_expected="HIGH",
        cost_sensitivity="HIGH",
        evidence_strength=EvidenceStrength.SPECULATIVE,
        primary_risk="NLP-Fehlklassifikation, Latenz-Nachteil",
        # TODO: Nur als optionaler Baustein, nicht für vollautomatischen Handel
    ),
    
    # Hypothese 11: ML-basierte Regimeklassifikation als Filter
    "HYP_11": StrategyConfig(
        strategy_id="HYP_11",
        name="ML Regime Classification Filter",
        category=StrategyCategory.ML_FILTER,
        hypothesis_number=11,
        paper_ids=["FX-091", "FX-092", "FX-093", "FX-094", "AI-011"],
        instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
        holding_period_days=1,  # Tägliche Regime-Update
        turnover_expected="LOW",
        cost_sensitivity="LOW",
        evidence_strength=EvidenceStrength.MODERATE,
        primary_risk="Overfitting, Look-Ahead-Bias",
        # WICHTIG: Diese Strategie dient AUSSCHLIESSLICH als Filter für andere Strategien
        # NIEMALS als direkter Alpha-Generator oder Signalgeber
    ),
    
    # Hypothese 12: Deep-Learning-Volatilitätsprognose als Risk-Input
    "HYP_12": StrategyConfig(
        strategy_id="HYP_12",
        name="Deep Learning Volatility Forecast",
        category=StrategyCategory.ML_FILTER,
        hypothesis_number=12,
        paper_ids=["AI-007", "AI-008", "AI-009", "AI-010"],
        instruments=["6E", "6J", "6B", "6A", "6C", "6S", "6N"],
        holding_period_days=1,  # Tägliche Vol-Prognose
        turnover_expected="LOW",
        cost_sensitivity="LOW",
        evidence_strength=EvidenceStrength.EMERGING,
        primary_risk="Modell-Drift, Overfitting auf historische Vol-Cluster",
        # Dient als Input für Risk-Manager, nicht als direkter Signalgeber
    ),
}


def get_strategy_config(strategy_id: str) -> StrategyConfig:
    """
    Ruft die Konfiguration für eine Strategie ab.
    
    Args:
        strategy_id: Strategie-ID (z.B. 'HYP_01')
        
    Returns:
        StrategyConfig für die angegebene Strategie
        
    Raises:
        KeyError: Wenn die Strategie-ID nicht gefunden wird
    """
    if strategy_id not in STRATEGY_REGISTRY:
        raise KeyError(f"Strategie '{strategy_id}' nicht gefunden. "
                      f"Verfügbare IDs: {list(STRATEGY_REGISTRY.keys())}")
    return STRATEGY_REGISTRY[strategy_id]


def get_all_strategies() -> List[StrategyConfig]:
    """
    Gibt alle registrierten Strategien zurück.
    
    Returns:
        Liste aller StrategyConfig-Objekte
    """
    return list(STRATEGY_REGISTRY.values())


def get_strategies_by_category(category: StrategyCategory) -> List[StrategyConfig]:
    """
    Gibt Strategien einer bestimmten Kategorie zurück.
    
    Args:
        category: Strategie-Kategorie
        
    Returns:
        Liste der StrategyConfig-Objekte der Kategorie
    """
    return [cfg for cfg in STRATEGY_REGISTRY.values() 
            if cfg.category == category]


def get_strategies_requiring_options_data() -> List[StrategyConfig]:
    """
    Gibt Strategien zurück, die Optionsdaten benötigen.
    
    Returns:
        Liste der StrategyConfig-Objekte mit requires_options_data=True
    """
    return [cfg for cfg in STRATEGY_REGISTRY.values() 
            if cfg.requires_options_data]


def get_strategies_requiring_cot_data() -> List[StrategyConfig]:
    """
    Gibt Strategien zurück, die COT-Daten benötigen.
    
    Returns:
        Liste der StrategyConfig-Objekte mit requires_cot_data=True
    """
    return [cfg for cfg in STRATEGY_REGISTRY.values() 
            if cfg.requires_cot_data]


def get_strategies_with_ml_filter() -> List[StrategyConfig]:
    """
    Gibt Strategien zurück, die ML-Regime-Filter benötigen.
    
    Returns:
        Liste der StrategyConfig-Objekte mit ml_filter_required=True
    """
    return [cfg for cfg in STRATEGY_REGISTRY.values() 
            if cfg.ml_filter_required]


def validate_strategy_activation(strategy_id: str, 
                                  min_sharpe: float,
                                  walk_forward_passed: bool) -> bool:
    """
    Prüft, ob eine Strategie für Live-Aktivierung freigegeben ist.
    
    Args:
        strategy_id: Strategie-ID
        min_sharpe: Erreichter minimaler Sharpe im Backtest
        walk_forward_passed: Ob Walk-Forward-Test bestanden wurde
        
    Returns:
        True wenn Aktivierung erlaubt, False sonst
    """
    config = get_strategy_config(strategy_id)
    
    if min_sharpe < config.activation_threshold_min_sharpe:
        logger.warning(f"Strategie {strategy_id}: Sharpe {min_sharpe:.2f} "
                      f"unterhalb Threshold {config.activation_threshold_min_sharpe}")
        return False
    
    if config.walk_forward_required and not walk_forward_passed:
        logger.warning(f"Strategie {strategy_id}: Walk-Forward-Test nicht bestanden")
        return False
    
    logger.info(f"Strategie {strategy_id} für Live-Aktivierung freigegeben")
    return True
