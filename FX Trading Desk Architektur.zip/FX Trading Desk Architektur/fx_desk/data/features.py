"""
Feature Engineering für FX Trading Strategien.

Berechnet alle benötigten Features aus Preis- und Optionsdaten:
- Logarithmische Renditen (niemals einfache Prozentänderungen)
- Realized Volatility (Parkinson, Garman-Klass, realized var)
- IV-RV-Spread (Volatility Risk Premium)
- COT-Z-Scores (Positionierungs-Extrema)
- Term Structure Slope (Calendar Spreads)
- Skew / Risk Reversal (Options-Implizite Verteilung)
- HMM-Regime-State (ML-basierte Klassifikation)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
import math
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


@dataclass
class PriceData:
    """
    Rohpreisdaten für ein Instrument.
    
    Attributes:
        symbol: Instrumentsymbol
        timestamps: Liste von Datumsangaben
        open: Öffnungspreise
        high: Höchstkurse
        low: Tiefstkurse
        close: Schlusskurse
        volume: Handelsvolumen
        open_interest: Open Interest (bei Futures)
    """
    symbol: str
    timestamps: List[datetime]
    open: List[float]
    high: List[float]
    low: List[float]
    close: List[float]
    volume: List[int]
    open_interest: List[int] = field(default_factory=list)
    
    def __len__(self) -> int:
        return len(self.close)
    
    def get_latest_prices(self, n: int = 1) -> Dict[str, float]:
        """
        Ruft die neuesten n Preise ab.
        
        Args:
            n: Anzahl der zurückzugebenden Preise
            
        Returns:
            Dictionary mit latest OHLC
        """
        if n > len(self):
            raise ValueError(f"n={n} überschreitet verfügbare Daten (len={len(self)})")
        return {
            'open': self.open[-n],
            'high': self.high[-n],
            'low': self.low[-n],
            'close': self.close[-n],
        }


@dataclass
class OptionsData:
    """
    Optionsdaten für IV, Skew, Risk Reversal Berechnungen.
    
    Attributes:
        symbol: Underlying-Symbol
        expiry: Verfallsdatum
        iv_atm: Implizite Volatilität at-the-money
        iv_25d_call: IV für 25-Delta Call
        iv_25d_put: IV für 25-Delta Put
        iv_10d_call: IV für 10-Delta Call
        iv_10d_put: IV für 10-Delta Put
    """
    symbol: str
    expiry: datetime
    iv_atm: float
    iv_25d_call: float
    iv_25d_put: float
    iv_10d_call: float = None
    iv_10d_put: float = None


@dataclass
class COTData:
    """
    COT (Commitments of Traders) Positionierungsdaten.
    
    Attributes:
        symbol: Instrumentsymbol
        report_date: Berichtsdatum (wöchentlich, Freitag)
        commercial_long: Commercial Long-Positionen
        commercial_short: Commercial Short-Positionen
        non_commercial_long: Non-Commercial (Speculator) Long
        non_commercial_short: Non-Commercial Short
        non_reportable_long: Non-Reportable Long
        non_reportable_short: Non-Reportable Short
    """
    symbol: str
    report_date: datetime
    commercial_long: int
    commercial_short: int
    non_commercial_long: int
    non_commercial_short: int
    non_reportable_long: int
    non_reportable_short: int


@dataclass
class FeatureSet:
    """
    Berechnete Features für ein Instrument zu einem Zeitpunkt.
    
    Attributes:
        symbol: Instrumentsymbol
        timestamp: Berechnungszeitpunkt
        log_returns: Logarithmische Renditen (various lookbacks)
        realized_vol: Realized Volatility (various estimators)
        iv_rv_spread: IV minus RV (Volatility Risk Premium)
        cot_zscore: COT-Z-Score für Positionierung
        term_structure_slope: Steigung der Termstruktur
        skew_25d: 25-Delta Skew (Call - Put IV)
        risk_reversal_25d: 25-Delta Risk Reversal
        hmm_regime_state: HMM-Regime-Zustand (0=Range, 1=Trend)
        hmm_regime_prob: Wahrscheinlichkeit des Regime-States
    """
    symbol: str
    timestamp: datetime
    log_returns: Dict[str, float]  # key: lookback_days, value: log-return
    realized_vol: Dict[str, float]  # key: estimator_type, value: vol
    iv_rv_spread: Optional[float]
    cot_zscore: Optional[float]
    term_structure_slope: Optional[float]
    skew_25d: Optional[float]
    risk_reversal_25d: Optional[float]
    hmm_regime_state: Optional[int]
    hmm_regime_prob: Optional[float]


class FeatureEngine:
    """
    Feature-Engine für FX-Instrumente.
    
    Berechnet alle benötigten Features aus Rohdaten unter strikter
    Einhaltung der Anforderungen:
    - Ausschließlich logarithmische Renditen
    - Robuste Volatilitätsschätzer
    - Look-Ahead-Bias-frei
    """
    
    TRADING_DAYS_PER_YEAR = 252
    
    def __init__(self):
        """Initialisiert die Feature-Engine."""
        pass
    
    @staticmethod
    def calculate_log_returns(prices: List[float], 
                               lookback: int = 1) -> List[float]:
        """
        Berechnet logarithmische Renditen.
        
        Args:
            prices: Liste von Preisen (Close-Preise)
            lookback: Lookback-Periode in Tagen (default: täglich)
            
        Returns:
            Liste der log-Renditen (length = len(prices) - lookback)
            
        Literatur: FX-004, FX-005 (Standard-Methode für Momentum)
        """
        if len(prices) <= lookback:
            logger.warning("Nicht genügend Daten für log-Renditen")
            return []
        
        returns = []
        for i in range(lookback, len(prices)):
            # Strikte Verwendung logarithmischer Renditen
            log_ret = math.log(prices[i] / prices[i - lookback])
            returns.append(log_ret)
        
        return returns
    
    @staticmethod
    def calculate_realized_vol_parkinson(highs: List[float], 
                                          lows: List[float], 
                                          window: int = 21) -> Optional[float]:
        """
        Parkinson-Volatilitätsschätzer (High-Low-basiert).
        
        Args:
            highs: Höchstkurse
            lows: Tiefstkurse
            window: Fensterlänge für Berechnung
            
        Returns:
            Annualisierte Parkinson-Volatilität oder None
            
        Literatur: FX-034, AI-007 (Robuster als Close-Close-RV)
        """
        if len(highs) < window or len(lows) < window:
            return None
        
        recent_highs = highs[-window:]
        recent_lows = lows[-window:]
        
        # Parkinson-Formel: σ² = (1 / (4 * ln(2))) * (1/n) * Σ(ln(H/L))²
        sum_sq = 0.0
        for h, l in zip(recent_highs, recent_lows):
            if l > 0:
                log_hl = math.log(h / l)
                sum_sq += log_hl ** 2
        
        variance = sum_sq / (4 * math.log(2) * window)
        vol_daily = math.sqrt(variance)
        
        # Annualisierung
        vol_annual = vol_daily * math.sqrt(FeatureEngine.TRADING_DAYS_PER_YEAR)
        
        return vol_annual
    
    @staticmethod
    def calculate_realized_vol_garman_klass(opens: List[float],
                                             highs: List[float],
                                             lows: List[float],
                                             closes: List[float],
                                             window: int = 21) -> Optional[float]:
        """
        Garman-Klass-Volatilitätsschätzer (OHLC-basiert).
        
        Args:
            opens: Öffnungspreise
            highs: Höchstkurse
            lows: Tiefstkurse
            closes: Schlusskurse
            window: Fensterlänge
            
        Returns:
            Annualisierte Garman-Klass-Volatilität oder None
            
        Literatur: FX-034 (Effizienterer Schätzer als Parkinson)
        """
        if len(opens) < window or len(highs) < window or len(lows) < window or len(closes) < window:
            return None
        
        recent_opens = opens[-window:]
        recent_highs = highs[-window:]
        recent_lows = lows[-window:]
        recent_closes = closes[-window:]
        
        sum_var = 0.0
        for o, h, l, c in zip(recent_opens, recent_highs, recent_lows, recent_closes):
            if o > 0 and l > 0:
                log_ho = math.log(h / o)
                log_lo = math.log(l / o)
                log_co = math.log(c / o)
                log_cl = math.log(c / l)
                
                # Garman-Klass-Formel
                term = 0.5 * (log_ho - log_lo) ** 2 - (2 * math.log(2) - 1) * log_co ** 2
                term += (2 * math.log(2) - 1) * log_cl ** 2
                sum_var += term
        
        variance = sum_var / window
        vol_daily = math.sqrt(variance)
        vol_annual = vol_daily * math.sqrt(FeatureEngine.TRADING_DAYS_PER_YEAR)
        
        return vol_annual
    
    @staticmethod
    def calculate_realized_vol_simple(closes: List[float], 
                                       window: int = 21) -> Optional[float]:
        """
        Einfache Realized Volatility (Close-Close-Standardabweichung).
        
        Args:
            closes: Schlusskurse
            window: Fensterlänge
            
        Returns:
            Annualisierte Volatilität oder None
        """
        if len(closes) < window + 1:
            return None
        
        # Log-Renditen berechnen
        log_rets = FeatureEngine.calculate_log_returns(closes, lookback=1)[-window:]
        
        if len(log_rets) < 2:
            return None
        
        # Mittelwert und Varianz
        mean_ret = sum(log_rets) / len(log_rets)
        variance = sum((r - mean_ret) ** 2 for r in log_rets) / (len(log_rets) - 1)
        
        vol_daily = math.sqrt(variance)
        vol_annual = vol_daily * math.sqrt(FeatureEngine.TRADING_DAYS_PER_YEAR)
        
        return vol_annual
    
    def calculate_iv_rv_spread(self, iv_atm: float, rv: float) -> float:
        """
        Berechnet IV-RV-Spread (Volatility Risk Premium).
        
        Args:
            iv_atm: Implizite Volatilität ATM
            rv: Realized Volatility
            
        Returns:
            Spread (IV - RV) in Dezimalform
            
        Literatur: FX-034, FX-035, AI-007 (VRP als Carry-Proxy)
        """
        return iv_atm - rv
    
    def calculate_cot_zscore(self, 
                              current_position: float,
                              historical_mean: float,
                              historical_std: float) -> float:
        """
        Berechnet Z-Score für COT-Positionierung.
        
        Args:
            current_position: Aktuelle Nettoposition (Non-Commercial)
            historical_mean: Historischer Mittelwert
            historical_std: Historische Standardabweichung
            
        Returns:
            Z-Score (Anzahl Standardabweichungen vom Mittelwert)
            
        Literatur: FX-041, FX-042, FX-043 (COT-Extrema als Contrarian-Signal)
        """
        if historical_std <= 0:
            logger.warning("Historische Std <= 0 für COT-Z-Score")
            return 0.0
        
        z_score = (current_position - historical_mean) / historical_std
        return z_score
    
    def calculate_term_structure_slope(self, 
                                        near_iv: float, 
                                        far_iv: float,
                                        near_months: float,
                                        far_months: float) -> float:
        """
        Berechnet Steigung der Volatilitäts-Termstruktur.
        
        Args:
            near_iv: IV des näheren Contracts
            far_iv: IV des entfernteren Contracts
            near_months: Monate bis Near-Expiry
            far_months: Monate bis Far-Expiry
            
        Returns:
            Slope (IV-Änderung pro Monat)
            
        Literatur: FX-025, FX-026 (Termstruktur als Signal)
        """
        month_diff = far_months - near_months
        if month_diff <= 0:
            logger.warning("Ungültige Month-Diff für Termstruktur")
            return 0.0
        
        slope = (far_iv - near_iv) / month_diff
        return slope
    
    def calculate_skew_25d(self, iv_25d_call: float, iv_25d_put: float) -> float:
        """
        Berechnet 25-Delta-Skew (Call IV - Put IV).
        
        Args:
            iv_25d_call: 25-Delta-Call-IV
            iv_25d_put: 25-Delta-Put-IV
            
        Returns:
            Skew in Dezimalform
            
        Literatur: FX-037, FX-038, FX-054 (Skew als Risikoprämie)
        """
        return iv_25d_call - iv_25d_put
    
    def calculate_risk_reversal_25d(self, 
                                     iv_25d_call: float, 
                                     iv_25d_put: float) -> float:
        """
        Berechnet 25-Delta-Risk-Reversal.
        
        Args:
            iv_25d_call: 25-Delta-Call-IV
            iv_25d_put: 25-Delta-Put-IV
            
        Returns:
            Risk Reversal (identisch zu Skew für 25-Delta)
            
        Literatur: FX-037, FX-054 (Risk Reversal als Sentiment)
        """
        return self.calculate_skew_25d(iv_25d_call, iv_25d_put)
    
    def compute_features(self, 
                         price_data: PriceData,
                         options_data: Optional[OptionsData] = None,
                         cot_data: Optional[COTData] = None,
                         hmm_model: Optional[Any] = None) -> FeatureSet:
        """
        Berechnet vollständiges Feature-Set für ein Instrument.
        
        Args:
            price_data: Preisdaten (OHLCV)
            options_data: Optionsdaten (optional, für IV-basierte Features)
            cot_data: COT-Daten (optional, für Positionierungs-Features)
            hmm_model: HMM-Modell (optional, für Regime-Klassifikation)
            
        Returns:
            FeatureSet mit allen berechneten Features
        """
        timestamp = price_data.timestamps[-1] if price_data.timestamps else datetime.now()
        
        # 1. Log-Renditen für verschiedene Lookbacks
        log_returns = {}
        for lookback in [1, 5, 21, 63, 252]:  # Täglich, wöchentlich, monatlich, quartalsweise, jährlich
            rets = self.calculate_log_returns(price_data.close, lookback=lookback)
            if rets:
                log_returns[f"{lookback}d"] = rets[-1]  # Neueste Rendite
        
        # 2. Realized Volatility (verschiedene Schätzer)
        realized_vol = {}
        
        rv_parkinson = self.calculate_realized_vol_parkinson(
            price_data.high, price_data.low, window=21
        )
        if rv_parkinson is not None:
            realized_vol['parkinson_21d'] = rv_parkinson
        
        rv_gk = self.calculate_realized_vol_garman_klass(
            price_data.open, price_data.high, price_data.low, price_data.close, window=21
        )
        if rv_gk is not None:
            realized_vol['garman_klass_21d'] = rv_gk
        
        rv_simple = self.calculate_realized_vol_simple(price_data.close, window=21)
        if rv_simple is not None:
            realized_vol['simple_21d'] = rv_simple
        
        # 3. IV-RV-Spread (wenn Optionsdaten verfügbar)
        iv_rv_spread = None
        if options_data is not None and 'simple_21d' in realized_vol:
            iv_rv_spread = self.calculate_iv_rv_spread(
                options_data.iv_atm, realized_vol['simple_21d']
            )
        
        # 4. COT-Z-Score (wenn COT-Daten verfügbar)
        cot_zscore = None
        if cot_data is not None:
            # Non-Commercial Nettoposition
            nc_net = cot_data.non_commercial_long - cot_data.non_commercial_short
            # TODO: Hier historische Mittelwerte/Std aus Datenbank laden
            # Platzhalter für Demo
            hist_mean = 0.0
            hist_std = 10000.0
            cot_zscore = self.calculate_cot_zscore(nc_net, hist_mean, hist_std)
        
        # 5. Term Structure Slope (wenn mehrere IVs verfügbar)
        term_structure_slope = None
        # TODO: Implementierung bei Verfügbarkeit von Multi-Expiry-Optionsdaten
        
        # 6. Skew / Risk Reversal (wenn Optionsdaten verfügbar)
        skew_25d = None
        risk_reversal_25d = None
        if options_data is not None:
            skew_25d = self.calculate_skew_25d(
                options_data.iv_25d_call, options_data.iv_25d_put
            )
            risk_reversal_25d = self.calculate_risk_reversal_25d(
                options_data.iv_25d_call, options_data.iv_25d_put
            )
        
        # 7. HMM-Regime-State (wenn Modell verfügbar)
        hmm_regime_state = None
        hmm_regime_prob = None
        if hmm_model is not None:
            # TODO: HMM-Modell anwenden auf aktuelle Features
            # Platzhalter: Model.predict([features])
            # hmm_regime_state = model.predict(...)[0]
            # hmm_regime_prob = model.predict_proba(...)[0][hmm_regime_state]
            pass
        
        return FeatureSet(
            symbol=price_data.symbol,
            timestamp=timestamp,
            log_returns=log_returns,
            realized_vol=realized_vol,
            iv_rv_spread=iv_rv_spread,
            cot_zscore=cot_zscore,
            term_structure_slope=term_structure_slope,
            skew_25d=skew_25d,
            risk_reversal_25d=risk_reversal_25d,
            hmm_regime_state=hmm_regime_state,
            hmm_regime_prob=hmm_regime_prob,
        )


def create_feature_engine() -> FeatureEngine:
    """
    Factory-Funktion zur Erstellung einer Feature-Engine.
    
    Returns:
        Initialisierte FeatureEngine-Instanz
    """
    return FeatureEngine()
