"""
Main Orchestration Module für FX Trading Desk.

Startet und koordiniert alle Komponenten:
1. Registrierung aller Strategien
2. Initialisierung von Risk Manager, Feature Engine, Screening Engine
3. Start des kontinuierlichen Screenings
4. Ausgabe von TradeSuggestions mit Begründung

Dies ist der Haupteinstiegspunkt für die Produktion.
"""

import logging
import sys
from datetime import datetime
from typing import List, Optional

# Lokale Imports
from config.instruments import get_standard_fx_futures, INSTRUMENT_CONFIGS
from config.strategies import STRATEGY_REGISTRY, get_all_strategies, StrategyCategory
from strategies.base import BaseStrategy
from strategies.momentum import create_momentum_strategy
from strategies.carry_crash_filter import create_carry_crash_filter_strategy
from strategies.ml_regime_filter import create_ml_regime_filter
from risk.risk_manager import create_risk_manager, RiskLimits
from screening.screening_engine import create_screening_engine, ScreeningEngine
from suggestions.trade_suggestion import TradeSuggestion

# Logging konfigurieren
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        # logging.FileHandler('fx_desk.log'),  # Optional: File-Logging
    ]
)

logger = logging.getLogger(__name__)


class FXTradingDesk:
    """
    Hauptklasse für den FX Trading Desk.
    
    Orchestriert alle Komponenten und stellt die Schnittstelle für:
    - Einmaliges Screening (on-demand)
    - Kontinuierliches Screening (Dauerlauf)
    - Manuelle Review-Prozesse
    """
    
    def __init__(self, 
                 nav: float = 1_000_000_000,  # $1Mrd NAV als Default
                 include_micros: bool = False,
                 screening_interval: int = 60):
        """
        Initialisiert den FX Trading Desk.
        
        Args:
            nav: Net Asset Value des Fonds in USD
            include_micros: Ob Micro-Futures einbezogen werden sollen
            screening_interval: Intervall zwischen Screenings in Sekunden
        """
        self.nav = nav
        self.include_micros = include_micros
        self.screening_interval = screening_interval
        
        self.logger = logging.getLogger(f"{__name__}.FXTradingDesk")
        self.logger.info(f"Initialisiere FX Trading Desk mit NAV=${nav:,.0f}")
        
        # Komponenten initialisieren
        self._initialize_components()
    
    def _initialize_components(self):
        """Initialisiert alle Komponenten des Trading Desk."""
        
        # 1. Instrumente festlegen
        if self.include_micros:
            self.instruments = list(INSTRUMENT_CONFIGS.keys())
        else:
            self.instruments = [cfg.symbol for cfg in get_standard_fx_futures()]
        
        self.logger.info(f"Handelbare Instrumente: {len(self.instruments)}")
        
        # 2. Risk Manager erstellen
        limits = RiskLimits(
            max_leverage=5.0,
            max_drawdown_pct=0.05,
            max_daily_var_95=5_000_000,  # $5M Daily VaR Limit
            vol_target_annual=0.10,  # 10% Vol-Target
        )
        self.risk_manager = create_risk_manager(nav=self.nav, limits=limits)
        self.logger.info("Risk Manager initialisiert")
        
        # 3. Strategien registrieren
        self.strategies: List[BaseStrategy] = []
        
        # Mindestens die 3 vollständig implementierten Strategien laden
        momentum = create_momentum_strategy()
        carry_filter = create_carry_crash_filter_strategy()
        ml_regime = create_ml_regime_filter(hmm_model=None, vol_forecast_model=None)
        
        self.strategies.extend([momentum, carry_filter, ml_regime])
        
        self.logger.info(f"{len(self.strategies)} Strategien initialisiert:")
        for strategy in self.strategies:
            self.logger.info(f"  - {strategy.name} ({strategy.strategy_id})")
        
        # 4. Screening Engine erstellen
        self.screening_engine = create_screening_engine(
            strategies=self.strategies,
            instruments=self.instruments,
            risk_manager=self.risk_manager,
            screening_interval=self.screening_interval,
        )
        self.logger.info("Screening Engine initialisiert")
    
    def run_single_screening(self) -> List[TradeSuggestion]:
        """
        Führt einen einzelnen Screening-Zyklus durch.
        
        Returns:
            Liste der generierten TradeSuggestions
        """
        self.logger.info("=" * 80)
        self.logger.info("START SINGLE SCREENING CYCLE")
        self.logger.info("=" * 80)
        
        suggestions = self.screening_engine.run_screening_cycle()
        
        if suggestions:
            self.logger.info(f"\n{'='*80}")
            self.logger.info(f"GENERIERTE TRADE SUGGESTIONS: {len(suggestions)}")
            self.logger.info(f"{'='*80}\n")
            
            for suggestion in suggestions:
                # Ausgabe im geforderten Format mit Paper-IDs und Begründung
                print(suggestion.format_for_logging())
        else:
            self.logger.info("Keine TradeSuggestions generiert")
        
        return suggestions
    
    def run_continuous(self, max_cycles: Optional[int] = None):
        """
        Startet kontinuierliches Screening.
        
        Args:
            max_cycles: Maximale Anzahl Zyklen (None für unbegrenzt)
        """
        self.logger.info("=" * 80)
        self.logger.info("START CONTINUOUS SCREENING")
        self.logger.info(f"Intervall: {self.screening_interval} Sekunden")
        self.logger.info(f"Max Zyklen: {max_cycles if max_cycles else 'unbegrenzt'}")
        self.logger.info("=" * 80)
        
        try:
            self.screening_engine.run_continuous_sync(max_cycles=max_cycles)
        except KeyboardInterrupt:
            self.logger.info("Screening durch Benutzer gestoppt")
        finally:
            self.screening_engine.stop()
    
    def get_status(self) -> dict:
        """
        Gibt aktuellen Status des Trading Desk zurück.
        
        Returns:
            Dictionary mit Status-Informationen
        """
        portfolio_state = self.risk_manager.get_portfolio_state()
        pending_suggestions = self.screening_engine.get_pending_suggestions()
        
        return {
            'timestamp': datetime.now().isoformat(),
            'nav': self.nav,
            'instruments_count': len(self.instruments),
            'strategies_count': len(self.strategies),
            'portfolio': {
                'total_exposure_usd': portfolio_state.total_exposure_usd,
                'effective_leverage': portfolio_state.effective_leverage,
                'var_95_usd': portfolio_state.portfolio_var_95,
                'drawdown_pct': portfolio_state.current_drawdown_pct,
            },
            'pending_suggestions': len(pending_suggestions),
        }
    
    def shutdown(self):
        """Fährt den Trading Desk ordnungsgemäß herunter."""
        self.logger.info("Shutdown FX Trading Desk...")
        self.screening_engine.stop()
        self.logger.info("FX Trading Desk heruntergefahren")


def main():
    """
    Haupteinstiegspunkt für die Kommandozeile.
    
    Verwendung:
        python -m fx_desk.main [--single|--continuous] [--nav=VALUE] [--interval=SECONDS]
    """
    import argparse
    
    parser = argparse.ArgumentParser(description='FX Trading Desk - Institutional Platform')
    parser.add_argument('--mode', choices=['single', 'continuous'], default='single',
                       help='Betriebsmodus: single (ein Zyklus) oder continuous (Dauerlauf)')
    parser.add_argument('--nav', type=float, default=1_000_000_000,
                       help='Net Asset Value in USD (Default: 1 Mrd)')
    parser.add_argument('--interval', type=int, default=60,
                       help='Screening-Intervall in Sekunden (Default: 60)')
    parser.add_argument('--cycles', type=int, default=None,
                       help='Maximale Zyklen für continuous-Modus')
    parser.add_argument('--micros', action='store_true',
                       help='Micro-Futures einbeziehen')
    
    args = parser.parse_args()
    
    # Trading Desk initialisieren
    desk = FXTradingDesk(
        nav=args.nav,
        include_micros=args.micros,
        screening_interval=args.interval,
    )
    
    try:
        if args.mode == 'single':
            suggestions = desk.run_single_screening()
            return 0 if suggestions is not None else 1
        
        elif args.mode == 'continuous':
            desk.run_continuous(max_cycles=args.cycles)
            return 0
    
    except Exception as e:
        logger.error(f"Fehler im Trading Desk: {e}", exc_info=True)
        return 1
    
    finally:
        desk.shutdown()


if __name__ == '__main__':
    sys.exit(main())
