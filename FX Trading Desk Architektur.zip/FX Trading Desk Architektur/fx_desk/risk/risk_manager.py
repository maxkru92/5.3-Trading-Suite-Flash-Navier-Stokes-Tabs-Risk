"""
Risk Manager für FX Trading Desk.

Implementiert institutionelles Risikomanagement mit:
- Volatilitäts-basiertem Position Sizing (Vol-Targeting)
- Harten Limits: Max-Leverage, Max-Drawdown, Tail-Risk
- VaR und Expected Shortfall Berechnung
- Portfolio-Level-Risikoüberwachung

Alle Positionsgrößen werden AUSSCHLIESSLICH volatilitätsbasiert berechnet
(inverses Vol-Targeting), niemals fixe Kontraktzahlen.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import math
import logging

logger = logging.getLogger(__name__)


@dataclass
class RiskLimits:
    """
    Globale Risikolimits für den Trading Desk.
    
    Attributes:
        max_leverage: Maximaler Hebel (x NAV)
        max_drawdown_pct: Maximaler Drawdown in Prozent
        max_daily_var_95: Maximaler 1-Tages-VaR (95%) in USD
        max_position_usd: Maximale Positionsgröße pro Instrument in USD
        max_total_exposure_usd: Maximale Gesamtexposure in USD
        vol_target_annual: Zielvolatilität annualisiert (für Vol-Targeting)
        max_correlation_exposure: Maximale Exposure in hochkorrelierten Instrumenten
    """
    max_leverage: float = 5.0  # Max 5x Hebel
    max_drawdown_pct: float = 0.05  # Max 5% Drawdown
    max_daily_var_95: float = 1_000_000  # Max $1M Daily VaR
    max_position_usd: float = 10_000_000  # Max $10M pro Position
    max_total_exposure_usd: float = 50_000_000  # Max $50M Total Exposure
    vol_target_annual: float = 0.10  # 10% annualisierte Volatilität als Ziel
    max_correlation_exposure: float = 20_000_000  # Max $20M in korrelierten Positionen


@dataclass
class PositionRisk:
    """
    Risikokennzahlen einer einzelnen Position.
    
    Attributes:
        symbol: Instrumentsymbol
        position_size_usd: Positionsgröße in USD
        annualized_vol: Annualisierte Volatilität
        daily_var_95: 1-Tages-VaR (95%) in USD
        expected_shortfall_95: Expected Shortfall (95%) in USD
        max_loss_stop: Maximalverlust bei Stop-Loss
        margin_requirement: Margin-Anforderung in USD
        leverage: Hebel der Position
    """
    symbol: str
    position_size_usd: float
    annualized_vol: float
    daily_var_95: float
    expected_shortfall_95: float
    max_loss_stop: float
    margin_requirement: float
    leverage: float


@dataclass
class PortfolioRiskState:
    """
    Aktueller Risikozustand des Portfolios.
    
    Attributes:
        timestamp: Zeitpunkt der Berechnung
        total_exposure_usd: Gesamtexposure in USD
        net_exposure_usd: Netto-Exposure (Long - Short)
        gross_exposure_usd: Brutto-Exposure (|Long| + |Short|)
        portfolio_var_95: Portfolio-VaR (95%) in USD
        portfolio_expected_shortfall: Portfolio-ES in USD
        current_drawdown_pct: Aktueller Drawdown in Prozent
        max_drawdown_ytd_pct: Maximaler Drawdown YTD
        effective_leverage: Effektiver Hebel
        utilization_limits: Auslastung der Limits in Prozent
    """
    timestamp: datetime
    total_exposure_usd: float
    net_exposure_usd: float
    gross_exposure_usd: float
    portfolio_var_95: float
    portfolio_expected_shortfall: float
    current_drawdown_pct: float
    max_drawdown_ytd_pct: float
    effective_leverage: float
    utilization_limits: Dict[str, float] = field(default_factory=dict)


class RiskManager:
    """
    Institutional Risk Manager für FX Trading.
    
    Verantwortlichkeiten:
    1. Position Sizing basierend auf Volatilität (Vol-Targeting)
    2. Prüfung gegen Risikolimits vor Trade-Freigabe
    3. Portfolio-Level-Risikoüberwachung
    4. VaR und Expected Shortfall Berechnung
    
    WICHTIG: Alle Positionsgrößen werden volatilitätsbasiert berechnet!
    """
    
    # Konstanten für Risikoberechnung
    TRADING_DAYS_PER_YEAR = 252
    VAR_CONFIDENCE = 0.95
    ES_CONFIDENCE = 0.95
    
    def __init__(self, nav: float, limits: Optional[RiskLimits] = None):
        """
        Initialisiert den Risk Manager.
        
        Args:
            nav: Net Asset Value des Fonds in USD
            limits: Optionale benutzerdefinierte Limits
        """
        self.nav = nav
        self.limits = limits if limits is not None else RiskLimits()
        self.positions: Dict[str, PositionRisk] = {}
        self.logger = logging.getLogger(f"{__name__}.RiskManager")
        
        # Drawdown-Tracking
        self.high_water_mark = nav
        self.current_drawdown = 0.0
        self.max_drawdown_ytd = 0.0
    
    def calculate_vol_target_position_size(self, 
                                           instrument_config: Any,
                                           annualized_vol: float,
                                           target_vol: Optional[float] = None) -> Tuple[int, float]:
        """
        Berechnet Positionsgröße basierend auf Volatilitäts-Targeting.
        
        Formel:
            Position Size = (NAV * Target Vol) / (Annualized Vol * Contract Multiplier)
        
        Args:
            instrument_config: InstrumentConfig aus config/instruments.py
            annualized_vol: Annualisierte Volatilität des Instruments
            target_vol: Zielvolatilität (default: aus Limits)
            
        Returns:
            Tuple (contract_count, position_size_usd)
            
        Literatur: FX-034, AI-007 (Vol-Targeting als Standard-Risikomanagement)
        """
        if target_vol is None:
            target_vol = self.limits.vol_target_annual
        
        if annualized_vol <= 0:
            self.logger.warning(f"Ungültige Volatilität {annualized_vol} für Position Sizing")
            return 0, 0.0
        
        # Maximale Positionsgröße basierend auf NAV und Vol-Target
        max_position_value = (self.nav * target_vol) / annualized_vol
        
        # Auf maximale Einzelposition begrenzen
        max_position_value = min(max_position_value, self.limits.max_position_usd)
        
        # Anzahl Kontrakte berechnen
        contract_value = instrument_config.contract_size * instrument_config.tick_value / instrument_config.tick_size
        # Vereinfacht: contract_value = Notional pro Kontrakt
        
        # Bei Futures: Contract-Größe gibt Notional in Basiswährung
        # Für USD-denominierte Futures ist das direkt der USD-Wert
        notional_per_contract = instrument_config.contract_size
        
        # Anzahl Kontrakte (auf ganze Zahl runden)
        contract_count = int(max_position_value / notional_per_contract)
        
        # Tatsächliche Positionsgröße in USD
        position_size_usd = contract_count * notional_per_contract
        
        # Auf Maximum prüfen
        if position_size_usd > self.limits.max_position_usd:
            contract_count = int(self.limits.max_position_usd / notional_per_contract)
            position_size_usd = contract_count * notional_per_contract
        
        return contract_count, position_size_usd
    
    def calculate_var_95(self, 
                          position_size_usd: float, 
                          daily_vol: float,
                          confidence: float = 0.95) -> float:
        """
        Berechnet 1-Tages-VaR (Value at Risk) bei 95% Konfidenz.
        
        Annahme: Normalverteilung der Renditen
        
        Args:
            position_size_usd: Positionsgröße in USD
            daily_vol: Tägliche Volatilität (dezimal)
            confidence: Konfidenzniveau
            
        Returns:
            VaR in USD (positiver Wert = potenzieller Verlust)
        """
        # Z-Score für 95% Konfidenz = 1.645
        z_score = 1.645 if confidence == 0.95 else 2.326  # 99%
        
        var = position_size_usd * daily_vol * z_score
        return var
    
    def calculate_expected_shortfall(self, 
                                      position_size_usd: float,
                                      daily_vol: float,
                                      confidence: float = 0.95) -> float:
        """
        Berechnet Expected Shortfall (CVaR) bei gegebener Konfidenz.
        
        ES ist der erwartete Verlust WENN der VaR überschritten wird.
        Für Normalverteilung: ES = VaR * (φ(z) / (1-α)) / z
        
        Args:
            position_size_usd: Positionsgröße in USD
            daily_vol: Tägliche Volatilität
            confidence: Konfidenzniveau
            
        Returns:
            Expected Shortfall in USD
        """
        # Vereinfachte Näherung: ES ≈ 1.25 * VaR für 95% Konfidenz
        var = self.calculate_var_95(position_size_usd, daily_vol, confidence)
        es_multiplier = 1.25 if confidence == 0.95 else 1.40  # 99%
        
        return var * es_multiplier
    
    def evaluate_position_risk(self,
                                symbol: str,
                                instrument_config: Any,
                                position_size_usd: float,
                                annualized_vol: float,
                                entry_price: float,
                                stop_loss: float) -> PositionRisk:
        """
        Bewertet das Risiko einer einzelnen Position.
        
        Args:
            symbol: Instrumentsymbol
            instrument_config: InstrumentConfig
            position_size_usd: Positionsgröße in USD
            annualized_vol: Annualisierte Volatilität
            entry_price: Einstiegspreis
            stop_loss: Stop-Loss-Preis
            
        Returns:
            PositionRisk Objekt
        """
        # Tägliche Volatilität aus annualisierter Vol
        daily_vol = annualized_vol / math.sqrt(self.TRADING_DAYS_PER_YEAR)
        
        # VaR und ES berechnen
        var_95 = self.calculate_var_95(position_size_usd, daily_vol)
        es_95 = self.calculate_expected_shortfall(position_size_usd, daily_vol)
        
        # Maximalverlust bei Stop-Loss
        stop_distance_pct = abs(entry_price - stop_loss) / entry_price
        max_loss_stop = position_size_usd * stop_distance_pct
        
        # Margin-Anforderung
        margin_requirement = instrument_config.initial_margin * (position_size_usd / instrument_config.contract_size)
        
        # Hebel berechnen
        leverage = position_size_usd / self.nav if self.nav > 0 else 0
        
        return PositionRisk(
            symbol=symbol,
            position_size_usd=position_size_usd,
            annualized_vol=annualized_vol,
            daily_var_95=var_95,
            expected_shortfall_95=es_95,
            max_loss_stop=max_loss_stop,
            margin_requirement=margin_requirement,
            leverage=leverage,
        )
    
    def check_trade_against_limits(self, 
                                    position_risk: PositionRisk,
                                    is_additive: bool = True) -> Tuple[bool, str]:
        """
        Prüft einen Trade gegen alle Risikolimits.
        
        Args:
            position_risk: PositionRisk des geplanten Trades
            is_additive: Ob die Position zu bestehenden hinzugefügt wird
            
        Returns:
            Tuple (approved, reason) - approved=True wenn Trade erlaubt
        """
        reasons = []
        
        # 1. Einzelpositions-Limit prüfen
        if position_risk.position_size_usd > self.limits.max_position_usd:
            reasons.append(f"Position ${position_risk.position_size_usd:,.0f} "
                          f"überschreitet Limit ${self.limits.max_position_usd:,.0f}")
        
        # 2. Hebel-Limit prüfen
        total_leverage = self._calculate_current_leverage()
        if is_additive:
            total_leverage += position_risk.leverage
        
        if total_leverage > self.limits.max_leverage:
            reasons.append(f"Hebel {total_leverage:.2f}x überschreitet Limit {self.limits.max_leverage}x")
        
        # 3. VaR-Limit prüfen
        current_var = self._calculate_portfolio_var()
        new_var = current_var + position_risk.daily_var_95 if is_additive else position_risk.daily_var_95
        
        if new_var > self.limits.max_daily_var_95:
            reasons.append(f"Portfolio-VaR ${new_var:,.0f} überschreitet Limit ${self.limits.max_daily_var_95:,.0f}")
        
        # 4. Drawdown-Limit prüfen
        if self.current_drawdown >= self.limits.max_drawdown_pct:
            reasons.append(f"Drawdown {self.current_drawdown:.2%} erreicht Limit "
                          f"{self.limits.max_drawdown_pct:.2%}")
        
        # Ergebnis
        approved = len(reasons) == 0
        reason_str = "; ".join(reasons) if reasons else "Trade innerhalb aller Limits"
        
        if approved:
            self.logger.debug(f"Trade genehmigt: {reason_str}")
        else:
            self.logger.warning(f"Trade abgelehnt: {reason_str}")
        
        return approved, reason_str
    
    def _calculate_current_leverage(self) -> float:
        """Berechnet aktuellen Hebel aus bestehenden Positionen."""
        total_exposure = sum(p.position_size_usd for p in self.positions.values())
        return total_exposure / self.nav if self.nav > 0 else 0
    
    def _calculate_portfolio_var(self) -> float:
        """
        Berechnet aktuellen Portfolio-VaR.
        
        TODO: Korrekturen für Diversifikation (bei korrelierten Positionen)
        Aktuell: Einfache Summation (konservativ)
        """
        return sum(p.daily_var_95 for p in self.positions.values())
    
    def update_nav(self, new_nav: float):
        """
        Aktualisiert NAV nach P&L.
        
        Args:
            new_nav: Neuer NAV-Wert
        """
        # Drawdown aktualisieren
        if new_nav > self.high_water_mark:
            self.high_water_mark = new_nav
            self.current_drawdown = 0.0
        else:
            self.current_drawdown = (self.high_water_mark - new_nav) / self.high_water_mark
            self.max_drawdown_ytd = max(self.max_drawdown_ytd, self.current_drawdown)
        
        self.nav = new_nav
        self.logger.info(f"NAV aktualisiert: ${new_nav:,.2f}, "
                        f"Drawdown: {self.current_drawdown:.2%}")
    
    def add_position(self, position_risk: PositionRisk):
        """
        Fügt Position zum Portfolio hinzu.
        
        Args:
            position_risk: PositionRisk der neuen Position
        """
        self.positions[position_risk.symbol] = position_risk
        self.logger.info(f"Position hinzugefügt: {position_risk.symbol}, "
                        f"${position_risk.position_size_usd:,.2f}")
    
    def remove_position(self, symbol: str):
        """
        Entfernt Position aus Portfolio.
        
        Args:
            symbol: Instrumentsymbol
        """
        if symbol in self.positions:
            del self.positions[symbol]
            self.logger.info(f"Position entfernt: {symbol}")
    
    def get_portfolio_state(self) -> PortfolioRiskState:
        """
        Gibt aktuellen Portfolio-Risikozustand zurück.
        
        Returns:
            PortfolioRiskState Objekt
        """
        total_exposure = sum(p.position_size_usd for p in self.positions.values())
        portfolio_var = self._calculate_portfolio_var()
        portfolio_es = sum(p.expected_shortfall_95 for p in self.positions.values())
        
        # Limit-Auslastung berechnen
        utilization = {
            'leverage': total_exposure / (self.nav * self.limits.max_leverage) if self.nav > 0 else 0,
            'var': portfolio_var / self.limits.max_daily_var_95,
            'drawdown': self.current_drawdown / self.limits.max_drawdown_pct,
        }
        
        return PortfolioRiskState(
            timestamp=datetime.now(),
            total_exposure_usd=total_exposure,
            net_exposure_usd=total_exposure,  # TODO: Netto-Berechnung mit Direction
            gross_exposure_usd=total_exposure,
            portfolio_var_95=portfolio_var,
            portfolio_expected_shortfall=portfolio_es,
            current_drawdown_pct=self.current_drawdown,
            max_drawdown_ytd_pct=self.max_drawdown_ytd,
            effective_leverage=total_exposure / self.nav if self.nav > 0 else 0,
            utilization_limits=utilization,
        )


def create_risk_manager(nav: float, 
                         limits: Optional[RiskLimits] = None) -> RiskManager:
    """
    Factory-Funktion zur Erstellung eines Risk Managers.
    
    Args:
        nav: Net Asset Value des Fonds
        limits: Optionale benutzerdefinierte Limits
        
    Returns:
        Initialisierter RiskManager
    """
    return RiskManager(nav=nav, limits=limits)
