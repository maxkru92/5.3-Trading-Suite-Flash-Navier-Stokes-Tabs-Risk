"""
Screening Engine für FX Trading Desk.

Dauerlauf-Loop die:
1. Live-Daten über MarketDataFeed bezieht
2. Alle registrierten Strategien pro Instrument auswertet
3. Bei erfülltem Regimefilter + Signalkriterium TradeSuggestions erzeugt
4. Begründung mit Strategie-Name, Paper-IDs und Feature-Werten hinzufügt
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import logging
import time
import asyncio

from ..strategies.base import BaseStrategy, Signal, StrategyContext, RegimeState
from ..data.features import FeatureSet, PriceData, FeatureEngine
from ..config.instruments import InstrumentConfig, get_instrument
from ..suggestions.trade_suggestion import (
    TradeSuggestion, RiskMetrics, create_trade_suggestion, SuggestionStatus
)
from ..risk.risk_manager import RiskManager, PositionRisk

logger = logging.getLogger(__name__)


class ScreeningEngine:
    """
    Screening Engine für kontinuierliche Signalgenerierung.
    
    Verantwortlichkeiten:
    1. Kontinuierlicher Datenabruf (Live oder Historical)
    2. Feature-Berechnung für alle Instrumente
    3. Auswertung aller registrierten Strategien
    4. Erstellung von TradeSuggestions bei Signalen
    5. Weiterleitung an Risk Manager zur Prüfung
    
    Der ScreeningEngine läuft als Dauerloop mit konfigurierbarem Intervall.
    """
    
    DEFAULT_SCREENING_INTERVAL_SECONDS = 60  # 1 Minute
    
    def __init__(self, 
                 strategies: List[BaseStrategy],
                 instruments: List[str],
                 risk_manager: RiskManager,
                 feature_engine: Optional[FeatureEngine] = None,
                 data_feed: Optional[Any] = None,
                 screening_interval: int = DEFAULT_SCREENING_INTERVAL_SECONDS):
        """
        Initialisiert die Screening Engine.
        
        Args:
            strategies: Liste der zu evaluierenden Strategien
            instruments: Liste der Instrumentsymbole (z.B. ['6E', '6J', '6B'])
            risk_manager: RiskManager für Limit-Prüfung
            feature_engine: FeatureEngine für Feature-Berechnung
            data_feed: MarketDataFeed für Live-Daten (optional)
            screening_interval: Intervall in Sekunden zwischen Screenings
        """
        self.strategies = {s.strategy_id: s for s in strategies}
        self.instruments = instruments
        self.risk_manager = risk_manager
        self.feature_engine = feature_engine if feature_engine else FeatureEngine()
        self.data_feed = data_feed
        self.screening_interval = screening_interval
        
        self.logger = logging.getLogger(f"{__name__}.ScreeningEngine")
        self.is_running = False
        self.suggestions_queue: List[TradeSuggestion] = []
        
        self.logger.info(f"ScreeningEngine initialisiert mit "
                        f"{len(self.strategies)} Strategien, "
                        f"{len(self.instruments)} Instrumenten")
    
    def _fetch_price_data(self, symbol: str) -> Optional[PriceData]:
        """
        Ruft Preisdaten für ein Instrument ab.
        
        Args:
            symbol: Instrumentsymbol
            
        Returns:
            PriceData Objekt oder None bei Fehler
            
        TODO: Integration mit echtem MarketDataFeed
        Aktuell: Platzhalter für Demo-Zwecke
        """
        if self.data_feed is not None:
            # Live-Daten abrufen
            # return self.data_feed.get_price_data(symbol)
            pass
        
        # Platzhalter-Daten für Demo
        import random
        base_price = 1.1000 if symbol == '6E' else 0.9000
        
        # Simulierte Daten generieren (letzte 252 Tage)
        timestamps = [datetime.now() - timedelta(days=i) for i in range(252)]
        timestamps.reverse()
        
        closes = [base_price * (1 + random.gauss(0, 0.0005)) for _ in range(252)]
        highs = [c * (1 + abs(random.gauss(0, 0.0003))) for c in closes]
        lows = [c * (1 - abs(random.gauss(0, 0.0003))) for c in closes]
        opens = [closes[i-1] if i > 0 else c for i, c in enumerate(closes)]
        
        return PriceData(
            symbol=symbol,
            timestamps=timestamps,
            open=opens,
            high=highs,
            low=lows,
            close=closes,
            volume=[10000] * 252,
        )
    
    def _get_current_regime_state(self, features: FeatureSet) -> RegimeState:
        """
        Ermittelt aktuellen Regime-State aus Features.
        
        TODO: Integration mit ML-Regime-Filter
        Aktuell: Heuristische Bestimmung
        
        Args:
            features: Berechnete Features
            
        Returns:
            RegimeState Objekt
        """
        # Heuristische Regime-Bestimmung
        vol = features.realized_vol.get('simple_21d', 0.15)
        
        if vol > 0.40:
            regime_type = 'CRISIS'
            confidence = 0.9
        elif vol > 0.20:
            regime_type = 'VOLATILE'
            confidence = 0.8
        else:
            # Trend-Konsistenz prüfen
            returns = features.log_returns
            signs = [1 if returns.get(f'{lb}d', 0) > 0 else -1 
                    for lb in [21, 63, 126] if f'{lb}d' in returns]
            
            if len(signs) >= 2 and all(s == signs[0] for s in signs):
                regime_type = 'TREND'
                confidence = 0.7 + 0.1 * len(signs) / 3
            else:
                regime_type = 'RANGE'
                confidence = 0.6
        
        return RegimeState(
            timestamp=datetime.now(),
            regime_type=regime_type,
            confidence=confidence,
            trend_direction=signs[0] if regime_type == 'TREND' and signs else 0,
            volatility_level='HIGH' if vol > 0.20 else 'MEDIUM',
            liquidity_condition='NORMAL',
        )
    
    def _evaluate_strategy(self, 
                           strategy: BaseStrategy,
                           symbol: str,
                           price_data: PriceData,
                           features: FeatureSet,
                           regime_state: RegimeState) -> List[Signal]:
        """
        Evaluiert eine einzelne Strategie für ein Instrument.
        
        Args:
            strategy: Strategie-Objekt
            symbol: Instrumentsymbol
            price_data: Preisdaten
            features: Berechnete Features
            regime_state: Aktueller Regime-State
            
        Returns:
            Liste von Signalen
        """
        try:
            # Instrument-Konfiguration laden
            instrument_config = get_instrument(symbol)
            
            # StrategyContext erstellen
            context = StrategyContext(
                symbol=symbol,
                features=features,
                regime_state=regime_state,
                current_price=price_data.close[-1],
                timestamp=datetime.now(),
                instrument_config=instrument_config,
            )
            
            # Strategie evaluieren
            signals = strategy.generate_signals(context)
            
            return signals
            
        except Exception as e:
            self.logger.error(f"Fehler bei Strategie-Evaluation "
                            f"{strategy.strategy_id}/{symbol}: {e}")
            return []
    
    def _create_trade_suggestion(self,
                                  signal: Signal,
                                  symbol: str,
                                  strategy_name: str,
                                  strategy_id: str,
                                  paper_ids: List[str],
                                  regime_state: RegimeState,
                                  annualized_vol: float) -> Optional[TradeSuggestion]:
        """
        Erstellt TradeSuggestion aus einem Signal mit Risikobewertung.
        
        Args:
            signal: Signal der Strategie
            symbol: Instrumentsymbol
            strategy_name: Name der Strategie
            strategy_id: ID der Strategie
            paper_ids: Paper-Referenzen
            regime_state: Marktregime
            annualized_vol: Annualisierte Volatilität
            
        Returns:
            TradeSuggestion oder None wenn Risk-Check nicht bestanden
        """
        try:
            instrument_config = get_instrument(symbol)
            
            # Positionsgröße berechnen (Vol-Targeting)
            contract_count, position_size_usd = \
                self.risk_manager.calculate_vol_target_position_size(
                    instrument_config, annualized_vol
                )
            
            if contract_count <= 0:
                self.logger.warning(f"Positionsgröße 0 für {symbol} - Volatilität zu hoch?")
                return None
            
            # Risiko bewerten
            position_risk = self.risk_manager.evaluate_position_risk(
                symbol=symbol,
                instrument_config=instrument_config,
                position_size_usd=position_size_usd,
                annualized_vol=annualized_vol,
                entry_price=signal.entry_price,
                stop_loss=signal.stop_loss if signal.stop_loss else signal.entry_price * 0.95,
            )
            
            # Gegen Limits prüfen
            approved, reason = self.risk_manager.check_trade_against_limits(position_risk)
            
            if not approved:
                self.logger.warning(f"Trade abgelehnt durch Risk-Manager: {reason}")
                return None
            
            # RiskMetrics für TradeSuggestion erstellen
            risk_metrics = RiskMetrics(
                position_size_usd=position_size_usd,
                position_size_contracts=contract_count,
                annualized_vol=annualized_vol,
                daily_var_95=position_risk.daily_var_95,
                expected_shortfall=position_risk.expected_shortfall_95,
                max_loss_stop=position_risk.max_loss_stop,
                margin_requirement=position_risk.margin_requirement,
                leverage=position_risk.leverage,
            )
            
            # TradeSuggestion erstellen
            suggestion = create_trade_suggestion(
                signal=signal,
                symbol=symbol,
                strategy_name=strategy_name,
                strategy_id=strategy_id,
                paper_ids=paper_ids,
                risk_metrics=risk_metrics,
                regime_state=regime_state.regime_type,
            )
            
            self.logger.info(f"TradeSuggestion erstellt: {suggestion.suggestion_id} "
                           f"- {symbol} {signal.direction} via {strategy_name}")
            
            return suggestion
            
        except Exception as e:
            self.logger.error(f"Fehler bei TradeSuggestion-Erstellung: {e}")
            return None
    
    def run_screening_cycle(self) -> List[TradeSuggestion]:
        """
        Führt einen einzelnen Screening-Zyklus durch.
        
        Returns:
            Liste der generierten TradeSuggestions
        """
        self.logger.info("Starte Screening-Zyklus...")
        suggestions = []
        
        for symbol in self.instruments:
            try:
                # 1. Preisdaten abrufen
                price_data = self._fetch_price_data(symbol)
                if price_data is None or len(price_data) < 252:
                    self.logger.warning(f"Unzureichende Daten für {symbol}")
                    continue
                
                # 2. Features berechnen
                features = self.feature_engine.compute_features(price_data)
                
                # 3. Regime-State bestimmen
                regime_state = self._get_current_regime_state(features)
                
                self.logger.debug(f"{symbol}: Regime={regime_state.regime_type}, "
                                f"Confidence={regime_state.confidence:.2f}")
                
                # 4. Alle Strategien evaluieren
                for strategy_id, strategy in self.strategies.items():
                    signals = self._evaluate_strategy(
                        strategy=strategy,
                        symbol=symbol,
                        price_data=price_data,
                        features=features,
                        regime_state=regime_state,
                    )
                    
                    # 5. TradeSuggestions für aktive Signale erstellen
                    for signal in signals:
                        if signal.direction in ['LONG', 'SHORT']:
                            annualized_vol = list(features.realized_vol.values())[0] \
                                           if features.realized_vol else 0.15
                            
                            suggestion = self._create_trade_suggestion(
                                signal=signal,
                                symbol=symbol,
                                strategy_name=strategy.name,
                                strategy_id=strategy.strategy_id,
                                paper_ids=strategy.paper_ids,
                                regime_state=regime_state,
                                annualized_vol=annualized_vol,
                            )
                            
                            if suggestion is not None:
                                suggestions.append(suggestion)
                                self.suggestions_queue.append(suggestion)
                
            except Exception as e:
                self.logger.error(f"Fehler im Screening-Zyklus für {symbol}: {e}")
                continue
        
        self.logger.info(f"Screening-Zyklus abgeschlossen: "
                        f"{len(suggestions)} TradeSuggestions generiert")
        
        return suggestions
    
    async def run_continuous_async(self, max_cycles: Optional[int] = None):
        """
        Führt Screening kontinuierlich als Async-Task aus.
        
        Args:
            max_cycles: Maximale Anzahl Zyklen (None für unbegrenzt)
        """
        self.is_running = True
        cycle_count = 0
        
        self.logger.info(f"Starte kontinuierliches Screening "
                        f"(Intervall: {self.screening_interval}s)")
        
        while self.is_running and (max_cycles is None or cycle_count < max_cycles):
            try:
                suggestions = self.run_screening_cycle()
                
                # Suggestions weiterverarbeiten (z.B. an Execution Engine senden)
                if suggestions:
                    self.logger.info(f"Zyklus {cycle_count + 1}: "
                                   f"{len(suggestions)} neue Suggestions")
                
                cycle_count += 1
                
                # Warten bis zum nächsten Zyklus
                await asyncio.sleep(self.screening_interval)
                
            except KeyboardInterrupt:
                self.logger.info("Screening durch Benutzer unterbrochen")
                break
            except Exception as e:
                self.logger.error(f"Fehler im kontinuierlichen Screening: {e}")
                await asyncio.sleep(self.screening_interval)
        
        self.is_running = False
        self.logger.info("Kontinuierliches Screening beendet")
    
    def run_continuous_sync(self, max_cycles: Optional[int] = None):
        """
        Führt Screening kontinuierlich synchron aus (Blocking).
        
        Args:
            max_cycles: Maximale Anzahl Zyklen (None für unbegrenzt)
        """
        asyncio.run(self.run_continuous_async(max_cycles))
    
    def stop(self):
        """Stoppt das kontinuierliche Screening."""
        self.is_running = False
        self.logger.info("Screening Engine gestoppt")
    
    def get_pending_suggestions(self) -> List[TradeSuggestion]:
        """
        Gibt ausstehende TradeSuggestions zurück.
        
        Returns:
            Liste der pending Suggestions
        """
        return [s for s in self.suggestions_queue 
                if s.status == SuggestionStatus.PENDING_REVIEW]
    
    def clear_suggestions_queue(self):
        """Leert die Suggestions-Queue."""
        self.suggestions_queue.clear()
        self.logger.info("Suggestions-Queue geleert")


def create_screening_engine(strategies: List[BaseStrategy],
                             instruments: List[str],
                             risk_manager: RiskManager,
                             screening_interval: int = 60) -> ScreeningEngine:
    """
    Factory-Funktion zur Erstellung einer Screening Engine.
    
    Args:
        strategies: Liste der Strategien
        instruments: Liste der Instrumentsymbole
        risk_manager: RiskManager
        screening_interval: Intervall in Sekunden
        
    Returns:
        Initialisierte ScreeningEngine
    """
    return ScreeningEngine(
        strategies=strategies,
        instruments=instruments,
        risk_manager=risk_manager,
        screening_interval=screening_interval,
    )
