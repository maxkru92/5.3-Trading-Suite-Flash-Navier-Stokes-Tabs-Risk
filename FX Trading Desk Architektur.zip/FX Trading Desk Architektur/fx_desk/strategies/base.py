"""
Abstract Base Strategy Class.

Definiert das Interface für alle Trading-Strategien:
- required_features(): Welche Features werden benötigt
- regime_filter(context): Prüft Regime-Bedingungen
- generate_signals(context): Generiert Handelssignale

Jede Strategie MUSS diese Methoden implementieren.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class Signal:
    """
    Handelssignal einer Strategie.
    
    Attributes:
        strategy_id: ID der generierenden Strategie
        symbol: Instrumentsymbol
        timestamp: Signal-Zeitpunkt
        direction: 'LONG', 'SHORT' oder 'FLAT'
        strength: Signalstärke (-1.0 bis +1.0)
        entry_price: Empfohlener Einstiegspreis
        stop_loss: Stop-Loss-Preis (optional)
        take_profit: Take-Profit-Preis (optional)
        rationale: Begründung des Signals
        features_used: Verwendete Feature-Werte
        paper_ids: Paper-Referenzen aus der Masterbibliographie
        confidence: Konfidenz (0.0 bis 1.0)
    """
    strategy_id: str
    symbol: str
    timestamp: datetime
    direction: str  # 'LONG', 'SHORT', 'FLAT'
    strength: float  # -1.0 to +1.0
    entry_price: float
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    rationale: str = ""
    features_used: Dict[str, float] = field(default_factory=dict)
    paper_ids: List[str] = field(default_factory=list)
    confidence: float = 0.5
    
    def __post_init__(self):
        """Validierung des Signals."""
        if self.direction not in ['LONG', 'SHORT', 'FLAT']:
            raise ValueError(f"Ungültige Direction: {self.direction}")
        if not -1.0 <= self.strength <= 1.0:
            raise ValueError(f"Strength außerhalb [-1, 1]: {self.strength}")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(f"Confidence außerhalb [0, 1]: {self.confidence}")


@dataclass
class RegimeState:
    """
    Zustand des Marktes laut Regime-Filter.
    
    Attributes:
        timestamp: Zeitpunkt der Klassifikation
        regime_type: 'TREND', 'RANGE', 'VOLATILE', 'CRISIS'
        confidence: Konfidenz der Klassifikation
        trend_direction: Bei Trend-Regime: '+1' (up), '-1' (down), '0' (neutral)
        volatility_level: 'LOW', 'MEDIUM', 'HIGH'
        liquidity_condition: 'NORMAL', 'STRESSED', 'CRISIS'
    """
    timestamp: datetime
    regime_type: str
    confidence: float
    trend_direction: int = 0  # +1, -1, 0
    volatility_level: str = "MEDIUM"
    liquidity_condition: str = "NORMAL"


@dataclass
class StrategyContext:
    """
    Kontext für die Signalgenerierung.
    
    Wird an jede Strategie übergeben und enthält:
    - Aktuelle Features
    - Regime-State
    - Historische Daten
    - Instrumenten-Konfiguration
    """
    symbol: str
    features: Any  # FeatureSet aus data/features.py
    regime_state: Optional[RegimeState]
    current_price: float
    timestamp: datetime
    instrument_config: Any
    historical_data: Optional[Any] = None
    options_data: Optional[Any] = None
    cot_data: Optional[Any] = None


class BaseStrategy(ABC):
    """
    Abstrakte Basisklasse für alle Trading-Strategien.
    
    Jede Strategie muss implementieren:
    1. required_features(): Liste der benötigten Features
    2. regime_filter(context): Gibt True zurück wenn Strategie aktiv sein darf
    3. generate_signals(context): Generiert Signal-Liste
    
    WICHTIG: 
    - Alle Preisberechnungen nutzen logarithmische Renditen
    - Positionsgrößen sind ausschließlich volatilitätsbasiert
    - Paper-Referenzen müssen im Docstring stehen
    """
    
    def __init__(self, strategy_id: str, name: str, paper_ids: List[str]):
        """
        Initialisiert die Basis-Strategie.
        
        Args:
            strategy_id: Eindeutige ID (z.B. 'HYP_01')
            name: Menschlesbarer Name
            paper_ids: Liste der Paper-Referenzen
        """
        self.strategy_id = strategy_id
        self.name = name
        self.paper_ids = paper_ids
        self.logger = logging.getLogger(f"{__name__}.{strategy_id}")
    
    @abstractmethod
    def required_features(self) -> List[str]:
        """
        Gibt Liste der benötigten Feature-Namen zurück.
        
        Returns:
            Liste von Feature-Namen (z.B. ['log_returns_21d', 'realized_vol_21d'])
        """
        pass
    
    @abstractmethod
    def regime_filter(self, context: StrategyContext) -> bool:
        """
        Prüft ob Regime-Bedingungen für die Strategie erfüllt sind.
        
        Args:
            context: StrategyContext mit aktuellen Features und Regime-State
            
        Returns:
            True wenn Strategie aktiv sein darf, False sonst
            
        Hinweis:
            - Strategien mit ml_filter_required=True MÜSSEN diesen Filter prüfen
            - Bei False darf generate_signals keine aktiven Signale erzeugen
        """
        pass
    
    @abstractmethod
    def generate_signals(self, context: StrategyContext) -> List[Signal]:
        """
        Generiert Handelssignale basierend auf aktuellen Features.
        
        Args:
            context: StrategyContext mit allen benötigten Daten
            
        Returns:
            Liste von Signal-Objekten (kann leer sein wenn kein Signal)
            
        Hinweis:
            - Vor Aufruf MUSS regime_filter() geprüft werden
            - Bei regime_filter=False sollte nur FLAT oder leere Liste zurückgegeben werden
            - Alle Signale müssen rationale Begründung enthalten
        """
        pass
    
    def validate_features(self, context: StrategyContext) -> bool:
        """
        Prüft ob alle benötigten Features verfügbar sind.
        
        Args:
            context: StrategyContext
            
        Returns:
            True wenn alle Features vorhanden, False sonst
        """
        required = self.required_features()
        if context.features is None:
            self.logger.warning(f"Keine Features verfügbar für {context.symbol}")
            return False
        
        # TODO: Feature-Verfügbarkeit prüfen anhand von context.features
        # Dies hängt von der konkreten Implementierung ab
        
        return True
    
    def get_metadata(self) -> Dict[str, Any]:
        """
        Gibt Metadaten der Strategie zurück.
        
        Returns:
            Dictionary mit Strategie-Metadaten
        """
        return {
            'strategy_id': self.strategy_id,
            'name': self.name,
            'paper_ids': self.paper_ids,
            'required_features': self.required_features(),
        }
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id={self.strategy_id}, name={self.name})"
