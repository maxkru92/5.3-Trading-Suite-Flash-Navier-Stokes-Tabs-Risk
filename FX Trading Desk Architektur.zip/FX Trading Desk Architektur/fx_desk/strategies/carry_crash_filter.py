"""
Carry Strategy with Crash-Vol Filter (Hypothesen 2 & 7).

Implementiert Carry-Strategie mit Volatilitäts-basiertem Crash-Filter:
- Carry-Signal aus Zinsdifferenzen / Forward-Punkten
- IV-RV-Spread als Crash-Risiko-Indikator
- Options-Skew als Tail-Risk-Warnung
- Safe-Haven/JPY-Carry-Unwind-Regime-Erkennung

Literatur: 
- HYP_02: FX-006, FX-007, FX-034, FX-054
- HYP_07: FX-007, FX-044, FX-045
"""

from typing import List, Dict, Optional
from datetime import datetime
import math
import logging

from .base import BaseStrategy, Signal, StrategyContext, RegimeState

logger = logging.getLogger(__name__)


class CarryCrashFilterStrategy(BaseStrategy):
    """
    Carry-Strategie mit Crash-Volatilitäts-Filter.
    
    Diese Strategie handelt Carry-Pockets (hohe Zinsdifferenz) aber filtert
    Situationen mit erhöhtem Crash-Risiko heraus anhand von:
    - IV-RV-Spread (Volatility Risk Premium überhöht)
    - Risk Reversal Skew (einseitige Absicherung)
    - Regime-Erkennung für Carry-Unwind
    
    Literatur:
        - FX-006: Lustig & Roussanov (2012) - Carry Trades systematisch
        - FX-007: Brunnermeier et al. (2009) - Carry Unwind und Crash-Risiko
        - FX-034: Della Corte et al. (2012) - Volatility Risk Premium in FX
        - FX-054: Jurek (2014) - Crash-Neutralität in Carry Trades
        - FX-044: Koolmuus & Luciani (2020) - JPY Safe-Haven-Dynamik
        - FX-045: Gabaix & Maggiori (2015) - International Risk Premium
    
    Signallogik:
        - Long High-Yield Currency wenn Carry > Threshold UND Crash-Filter OK
        - Short Low-Yield Currency entsprechend
        - Crash-Filter: IV-RV < 5%, Risk Reversal nicht extrem, kein Unwind-Regime
    
    Risikomanagement:
        - Positionsgröße invers zur Volatilität
        - Stop-Loss bei 3x täglicher Volatilität (weiter wegen Carry-Charakter)
        - Reduzierte Größe bei erhöhtem IV-RV-Spread
    """
    
    # Schwellenwerte
    CARRY_THRESHOLD_ANNUAL = 0.02  # 2% p.a. minimale Carry-Prämie
    IV_RV_MAX_SPREAD = 0.05  # Maximal 5% IV-RV-Spread
    SKEW_EXTREME_THRESHOLD = 0.03  # 3% Skew als Extremwert
    VOL_TARGET = 0.10  # 10% annualisierte Volatilität als Ziel
    
    def __init__(self):
        """Initialisiert die Carry-Crash-Filter-Strategie."""
        paper_ids = ["FX-006", "FX-007", "FX-034", "FX-054", "FX-044", "FX-045"]
        super().__init__(
            strategy_id="HYP_02/HYP_07",
            name="Carry with Crash-Vol Filter",
            paper_ids=paper_ids,
        )
    
    def required_features(self) -> List[str]:
        """
        Benötigte Features für Carry-Strategie.
        
        Returns:
            Liste der Feature-Namen
        """
        return [
            'carry_annualized',      # Annualisierte Carry-Prämie
            'iv_rv_spread',          # IV minus RV
            'skew_25d',              # 25-Delta Skew
            'risk_reversal_25d',     # 25-Delta Risk Reversal
            'realized_vol_21d',      # Realized Volatility
        ]
    
    def regime_filter(self, context: StrategyContext) -> bool:
        """
        Prüft ob Carry-Regime aktiv sein darf (kein Unwind/Crisis).
        
        Carry-Strategien sollten in folgenden Situationen deaktiviert werden:
        - Crisis-Regime (Liquiditätsstress)
        - Volatile-Regime mit niedriger Konfidenz
        - Explizites Carry-Unwind-Regime (JPY-Flucht)
        
        Args:
            context: StrategyContext mit Regime-State
            
        Returns:
            True wenn Carry-Handel erlaubt, False sonst
        """
        if context.regime_state is None:
            self.logger.warning(f"Kein Regime-State für {context.symbol} - konservativ")
            return False
        
        # Crisis-Regime immer meiden
        if context.regime_state.regime_type == 'CRISIS':
            self.logger.info(f"{context.symbol}: CRISIS-Regime - Carry deaktiviert")
            return False
        
        # Volatile-Regime nur bei hoher Konfidenz
        if context.regime_state.regime_type == 'VOLATILE':
            if context.regime_state.confidence < 0.7:
                self.logger.info(f"{context.symbol}: VOLATILE-Regime mit niedriger Konfidenz")
                return False
        
        # Carry-Unwind-Regime erkennen (typisch: JPY stark im Trend)
        if hasattr(context.regime_state, 'liquidity_condition'):
            if context.regime_state.liquidity_condition == 'CRISIS':
                self.logger.info(f"{context.symbol}: Liquiditäts-Crisis - Carry deaktiviert")
                return False
        
        return True
    
    def _check_crash_filter(self, features: any) -> tuple[bool, str]:
        """
        Prüft Crash-Risiko-Filter basierend auf Optionsdaten.
        
        Args:
            features: FeatureSet mit IV/RV/Skew-Daten
            
        Returns:
            Tuple (filter_ok, reason)
        """
        reasons = []
        
        # 1. IV-RV-Spread prüfen (zu hohe VRP = Crash-Risiko)
        if features.iv_rv_spread is not None:
            if features.iv_rv_spread > self.IV_RV_MAX_SPREAD:
                reasons.append(f"IV-RV-Spread zu hoch: {features.iv_rv_spread:.2%}")
        
        # 2. Skew prüfen (extreme einseitige Absicherung)
        if features.skew_25d is not None:
            if abs(features.skew_25d) > self.SKEW_EXTREME_THRESHOLD:
                skew_sign = "put" if features.skew_25d < 0 else "call"
                reasons.append(f"Extremer {skew_sign}-Skew: {features.skew_25d:.2%}")
        
        # Filter ist OK wenn keine Warngründe
        filter_ok = len(reasons) == 0
        reason_str = "; ".join(reasons) if reasons else "Crash-Filter OK"
        
        return filter_ok, reason_str
    
    def generate_signals(self, context: StrategyContext) -> List[Signal]:
        """
        Generiert Carry-Signale mit Crash-Filter.
        
        Args:
            context: StrategyContext mit Features
            
        Returns:
            Liste von Signalen (maximal 1 Signal pro Aufruf)
        """
        signals = []
        
        # Zuerst Regime-Filter prüfen
        if not self.regime_filter(context):
            flat_signal = Signal(
                strategy_id=self.strategy_id,
                symbol=context.symbol,
                timestamp=context.timestamp,
                direction='FLAT',
                strength=0.0,
                entry_price=context.current_price,
                rationale="Regime-Filter nicht erfüllt (Crisis/Volatile-Regime)",
                paper_ids=self.paper_ids,
                confidence=0.5,
            )
            return [flat_signal]
        
        # Features extrahieren
        features = context.features
        if features is None:
            self.logger.error(f"Keine Features verfügbar für {context.symbol}")
            return []
        
        # Carry-Wert extrahieren (muss im FeatureSet vorhanden sein)
        # TODO: carry_annualized muss im FeatureSet ergänzt werden
        carry_annualized = features.log_returns.get('carry_annualized', 0.0)
        
        # Crash-Filter prüfen
        crash_filter_ok, crash_reason = self._check_crash_filter(features)
        
        if not crash_filter_ok:
            self.logger.info(f"{context.symbol}: Crash-Filter ausgelöst - {crash_reason}")
            flat_signal = Signal(
                strategy_id=self.strategy_id,
                symbol=context.symbol,
                timestamp=context.timestamp,
                direction='FLAT',
                strength=0.0,
                entry_price=context.current_price,
                rationale=f"Crash-Filter: {crash_reason}",
                paper_ids=self.paper_ids,
                confidence=0.7,
            )
            return [flat_signal]
        
        # Carry-Signal bewerten
        if abs(carry_annualized) < self.CARRY_THRESHOLD_ANNUAL:
            # Carry zu niedrig für Trade
            return []
        
        # Richtung bestimmen (positiver Carry = Long High-Yield)
        if carry_annualized > 0:
            direction = 'LONG'
        else:
            direction = 'SHORT'
        
        # Signalstärke basierend auf Carry-Höhe (normalisiert)
        # Typischer Carry-Bereich: -5% bis +5% p.a.
        signal_strength = carry_annualized / 0.05  # Normalisierung
        signal_strength = max(-1.0, min(1.0, signal_strength))
        
        # Volatilität für Sizing und Stop-Loss
        vol = None
        if 'simple_21d' in features.realized_vol:
            vol = features.realized_vol['simple_21d']
        elif 'parkinson_21d' in features.realized_vol:
            vol = features.realized_vol['parkinson_21d']
        
        if vol is None or vol <= 0:
            self.logger.warning(f"Keine gültige Volatilität für {context.symbol}")
            return []
        
        daily_vol = vol / math.sqrt(252)
        
        # Stop-Loss (3x tägliche Volatilität - weiter für Carry-Trades)
        stop_distance = 3 * daily_vol * context.current_price
        if direction == 'LONG':
            stop_loss = context.current_price * (1 - stop_distance / context.current_price)
        else:
            stop_loss = context.current_price * (1 + stop_distance / context.current_price)
        
        # Rationale zusammenstellen
        rationale_parts = [
            f"Annualisierter Carry: {carry_annualized:.2%}",
            f"Crash-Filter: {crash_reason}",
            f"Annualisierte Vol: {vol:.2%}",
        ]
        
        if features.iv_rv_spread is not None:
            rationale_parts.append(f"IV-RV-Spread: {features.iv_rv_spread:.2%}")
        if features.skew_25d is not None:
            rationale_parts.append(f"25D-Skew: {features.skew_25d:.2%}")
        
        rationale = "; ".join(rationale_parts)
        
        # Signal erstellen
        signal = Signal(
            strategy_id=self.strategy_id,
            symbol=context.symbol,
            timestamp=context.timestamp,
            direction=direction,
            strength=signal_strength,
            entry_price=context.current_price,
            stop_loss=stop_loss,
            rationale=rationale,
            features_used={
                'carry_annualized': carry_annualized,
                'iv_rv_spread': features.iv_rv_spread,
                'skew_25d': features.skew_25d,
                'annualized_vol': vol,
            },
            paper_ids=self.paper_ids,
            confidence=min(1.0, abs(signal_strength)),
        )
        
        signals.append(signal)
        self.logger.info(f"{context.symbol}: {direction} Carry-Signal mit Stärke {signal_strength:.2f}")
        
        return signals


def create_carry_crash_filter_strategy() -> CarryCrashFilterStrategy:
    """
    Factory-Funktion zur Erstellung einer Carry-Crash-Filter-Strategie.
    
    Returns:
        Initialisierte CarryCrashFilterStrategy-Instanz
    """
    return CarryCrashFilterStrategy()
