"""
ML Regime Filter Strategy (Hypothesen 11 & 12).

Implementiert ML-basierte Regimeklassifikation als FILTER für andere Strategien:
- HMM (Hidden Markov Model) für Regime-Erkennung (Trend/Range/Volatile/Crisis)
- Deep-Learning-Volatilitätsprognose als Risk-Input
- KEIN direkter Alpha-Generator, ausschließlich Filterfunktion

WICHTIG: Diese Strategie dient AUSSCHLIESSLICH als Filter für andere Strategien.
Sie generiert KEINE eigenen Handelssignale für direkte Positionierung.

Literatur: 
- HYP_11: FX-091, FX-092, FX-093, FX-094, AI-011
- HYP_12: AI-007, AI-008, AI-009, AI-010
"""

from typing import List, Dict, Optional, Tuple, Any
from datetime import datetime
import math
import logging

from .base import BaseStrategy, Signal, StrategyContext, RegimeState

logger = logging.getLogger(__name__)


class MLRegimeFilterStrategy(BaseStrategy):
    """
    ML-basierter Regime-Filter für FX-Trading.
    
    Diese Komponente verwendet Machine Learning zur Klassifikation von Marktregimen:
    - TREND: Gerichtete Bewegung, Momentum-Strategien aktivierbar
    - RANGE: Seitwärtsbewegung, Mean-Reversion-Strategien aktivierbar
    - VOLATILE: Hohe Volatilität, Vorsicht bei allen Strategien
    - CRISIS: Liquiditätsstress, alle Strategien deaktivieren
    
    Zusätzlich wird eine Deep-Learning-Volatilitätsprognose berechnet als
    Input für den Risk-Manager (nicht für direkte Signalgenerierung).
    
    WICHTIGER HINWEIS:
    ====================
    Diese Strategie darf NIEMALS als direkter Alpha-Generator verwendet werden.
    Sie dient AUSSCHLIESSLICH als Filter für andere Strategien.
    
    RL/Reinforcement-Learning ist explizit NICHT implementiert, da laut
    AI-Sonderanalyse für Produktion ungeeignet (AI-016, AI-017).
    
    Literatur:
        - FX-091: Ang & Bekaert (2002) - Regime Switching in FX
        - FX-092: Guidolin & Timmermann (2007) - Asset Allocation with Regimes
        - FX-093: Dai et al. (2019) - HMM for FX Regimes
        - FX-094: Nystrup et al. (2020) - Dynamic Regime Detection
        - AI-011: Hidden Markov Models für Financial Time Series
        - AI-007: Deep Learning für Volatilitätsprognose
        - AI-008: LSTM für Volatilitäts-Forecasting
        - AI-009: CNN-LSTM Hybrid für Vol-Prognosen
        - AI-010: Attention-Mechanismen für Vol-Modellierung
    """
    
    # Regime-Typen
    REGIME_TYPES = ['TREND', 'RANGE', 'VOLATILE', 'CRISIS']
    
    # Schwellenwerte für Regime-Klassifikation (ohne ML-Modell als Fallback)
    VOL_HIGH_THRESHOLD = 0.20  # 20% annualisierte Vol = HIGH
    VOL_CRISIS_THRESHOLD = 0.40  # 40% = CRISIS
    MOMENTUM_CONSISTENCY_THRESHOLD = 0.6  # Konsistenz der Renditen
    
    def __init__(self, hmm_model: Optional[Any] = None, vol_forecast_model: Optional[Any] = None):
        """
        Initialisiert den ML-Regime-Filter.
        
        Args:
            hmm_model: Trainiertes HMM-Modell (optional, Fallback zu Heuristik)
            vol_forecast_model: Deep-Learning-Volatility-Forecaster (optional)
        """
        paper_ids = ["FX-091", "FX-092", "FX-093", "FX-094", "AI-011", 
                     "AI-007", "AI-008", "AI-009", "AI-010"]
        super().__init__(
            strategy_id="HYP_11/HYP_12",
            name="ML Regime Classification Filter",
            paper_ids=paper_ids,
        )
        self.hmm_model = hmm_model
        self.vol_forecast_model = vol_forecast_model
        
        # Hinweis im Log bei Initialisierung
        logger.info("ML Regime Filter initialisiert - NUR als Filter, NICHT als Alpha-Quelle")
    
    def required_features(self) -> List[str]:
        """
        Benötigte Features für Regime-Klassifikation.
        
        Returns:
            Liste der Feature-Namen
        """
        return [
            'log_returns_1d',
            'log_returns_5d',
            'log_returns_21d',
            'realized_vol_21d',
            'realized_vol_63d',
        ]
    
    def regime_filter(self, context: StrategyContext) -> bool:
        """
        Prüft ob Regime-Filter für diese Strategie erfüllt ist.
        
        Da dies SELBST die Filter-Strategie ist,返回 True wenn:
        - Features verfügbar sind
        - Klassifikation erfolgreich war
        
        Args:
            context: StrategyContext
            
        Returns:
            True wenn Filter betriebsbereit, False sonst
        """
        if context.features is None:
            return False
        
        # Immer betriebsbereit wenn Features da sind
        return True
    
    def classify_regime_heuristic(self, features: Any) -> RegimeState:
        """
        Heuristische Regime-Klassifikation als Fallback ohne ML-Modell.
        
        Verwendet einfache Regeln basierend auf Volatilität und Momentum-Konsistenz:
        - CRISIS: Vol > 40% annualisiert
        - VOLATILE: Vol > 20% annualisiert
        - TREND: Konsistente Renditen über verschiedene Lookbacks
        - RANGE: Inkonsistente Renditen, niedrige Vol
        
        Args:
            features: FeatureSet mit Renditen und Volatilitäten
            
        Returns:
            RegimeState Objekt
        """
        timestamp = datetime.now()
        
        # Volatilität extrahieren
        vol = None
        if 'simple_21d' in features.realized_vol:
            vol = features.realized_vol['simple_21d']
        elif 'parkinson_21d' in features.realized_vol:
            vol = features.realized_vol['parkinson_21d']
        
        if vol is None:
            vol = 0.15  # Default 15% bei fehlenden Daten
        
        # 1. Crisis-Check
        if vol > self.VOL_CRISIS_THRESHOLD:
            return RegimeState(
                timestamp=timestamp,
                regime_type='CRISIS',
                confidence=0.9,
                volatility_level='HIGH',
                liquidity_condition='CRISIS',
            )
        
        # 2. Volatile-Check
        if vol > self.VOL_HIGH_THRESHOLD:
            return RegimeState(
                timestamp=timestamp,
                regime_type='VOLATILE',
                confidence=0.8,
                volatility_level='HIGH',
                liquidity_condition='STRESSED',
            )
        
        # 3. Trend vs. Range anhand Momentum-Konsistenz
        log_returns = features.log_returns
        
        # Konsistenz prüfen: Haben alle Lookbacks gleiche Richtung?
        signs = []
        for key in ['1d', '5d', '21d']:
            if f'{key}d' in log_returns or key in log_returns:
                ret_key = f'{key}d' if f'{key}d' in log_returns else key
                ret = log_returns[ret_key]
                signs.append(1 if ret > 0 else -1)
        
        if len(signs) >= 2:
            # Konsistenz berechnen (alle gleiches Vorzeichen?)
            consistency = 1.0 if all(s == signs[0] for s in signs) else 0.0
            
            if consistency >= self.MOMENTUM_CONSISTENCY_THRESHOLD:
                trend_direction = signs[0]
                return RegimeState(
                    timestamp=timestamp,
                    regime_type='TREND',
                    confidence=0.7 + 0.2 * consistency,
                    trend_direction=trend_direction,
                    volatility_level='MEDIUM' if vol < 0.15 else 'HIGH',
                    liquidity_condition='NORMAL',
                )
        
        # Default: Range-Regime
        return RegimeState(
            timestamp=timestamp,
            regime_type='RANGE',
            confidence=0.6,
            trend_direction=0,
            volatility_level='LOW' if vol < 0.10 else 'MEDIUM',
            liquidity_condition='NORMAL',
        )
    
    def classify_regime_ml(self, features: Any) -> Optional[RegimeState]:
        """
        ML-basierte Regime-Klassifikation mit HMM.
        
        TODO: Implementierung erfordert trainiertes HMM-Modell.
        Platzhalter für zukünftige Integration.
        
        Args:
            features: FeatureSet
            
        Returns:
            RegimeState oder None wenn Modell nicht verfügbar
        """
        if self.hmm_model is None:
            logger.debug("Kein HMM-Modell verfügbar - verwende Heuristik")
            return None
        
        # TODO: Hier HMM-Modell anwenden
        # Beispiel-Code (wenn Modell verfügbar):
        # feature_vector = self._extract_feature_vector(features)
        # regime_idx = self.hmm_model.predict([feature_vector])[0]
        # regime_prob = self.hmm_model.predict_proba([feature_vector])[0][regime_idx]
        # regime_type = self.REGIME_TYPES[regime_idx]
        
        return None
    
    def forecast_volatility_dl(self, features: Any) -> Optional[float]:
        """
        Deep-Learning-Volatilitätsprognose.
        
        TODO: Implementierung erfordert trainiertes DL-Modell (LSTM/CNN).
        Platzhalter für zukünftige Integration.
        
        Args:
            features: FeatureSet
            
        Returns:
            Prognostizierte Volatilität oder None
        """
        if self.vol_forecast_model is None:
            logger.debug("Kein Vol-Forecast-Modell verfügbar")
            return None
        
        # TODO: Hier DL-Modell anwenden
        # Beispiel-Code (wenn Modell verfügbar):
        # feature_sequence = self._prepare_sequence(features)
        # vol_forecast = self.vol_forecast_model.predict(feature_sequence)
        
        return None
    
    def generate_signals(self, context: StrategyContext) -> List[Signal]:
        """
        Generiert KEINE direkten Handelssignale.
        
        Diese Methode gibt immer eine leere Liste zurück, da der ML-Regime-Filter
        AUSSCHLIESSLICH als Filter für andere Strategien dient.
        
        Die Regime-Information wird über den StrategyContext bereitgestellt
 und von anderen Strategien genutzt.
        
        Args:
            context: StrategyContext
            
        Returns:
            Leere Liste (keine eigenen Signale)
            
        WARNUNG: Wenn hier Signale generiert würden, wäre das ein Architekturfehler!
        """
        # Explizite Warnung im Log
        self.logger.debug(f"ML Regime Filter: KEINE Signale generiert (nur Filter-Funktion)")
        
        # Rückgabe eines Informations-Signals mit Regime-State
        # Dies dient NUR der Protokollierung, nicht dem Trading
        regime_state = self.classify_regime(context.features)
        
        info_signal = Signal(
            strategy_id=self.strategy_id,
            symbol=context.symbol,
            timestamp=context.timestamp,
            direction='FLAT',
            strength=0.0,
            entry_price=context.current_price,
            rationale=f"Regime-Klassifikation: {regime_state.regime_type} "
                     f"(Konfidenz: {regime_state.confidence:.2f})",
            features_used={
                'regime_type': regime_state.regime_type,
                'regime_confidence': regime_state.confidence,
                'volatility_level': regime_state.volatility_level,
            },
            paper_ids=self.paper_ids,
            confidence=regime_state.confidence,
        )
        
        return [info_signal]
    
    def classify_regime(self, features: Any) -> RegimeState:
        """
        Hauptmethode zur Regime-Klassifikation.
        
        Versucht zuerst ML-Klassifikation, fällt zurück auf Heuristik.
        
        Args:
            features: FeatureSet
            
        Returns:
            RegimeState Objekt
        """
        # Versuch ML-Klassifikation
        if self.hmm_model is not None:
            ml_regime = self.classify_regime_ml(features)
            if ml_regime is not None:
                return ml_regime
        
        # Fallback zu heuristischer Klassifikation
        return self.classify_regime_heuristic(features)
    
    def get_regime_for_strategy(self, features: Any, 
                                 strategy_requires_trend: bool = False) -> bool:
        """
        Hilfsfunktion für andere Strategien: Ist Regime geeignet?
        
        Args:
            features: FeatureSet
            strategy_requires_trend: Ob die Strategie Trend-Regime benötigt
            
        Returns:
            True wenn Regime für Strategie geeignet
        """
        regime = self.classify_regime(features)
        
        if strategy_requires_trend:
            return regime.regime_type == 'TREND'
        
        # Für Carry: Nicht in CRISIS
        if regime.regime_type == 'CRISIS':
            return False
        
        # Für Mean Reversion: Nur in RANGE
        # Für Momentum: Nur in TREND
        
        return True


def create_ml_regime_filter(hmm_model: Optional[Any] = None,
                             vol_forecast_model: Optional[Any] = None) -> MLRegimeFilterStrategy:
    """
    Factory-Funktion zur Erstellung eines ML-Regime-Filters.
    
    Args:
        hmm_model: Optionales HMM-Modell
        vol_forecast_model: Optionales Deep-Learning-Volatility-Modell
        
    Returns:
        Initialisierte MLRegimeFilterStrategy-Instanz
    """
    return MLRegimeFilterStrategy(hmm_model=hmm_model, vol_forecast_model=vol_forecast_model)
