"""
Time-Series Momentum Strategy (Hypothese 1).

Implementiert Time-Series-Momentum in Currency Futures basierend auf:
- Log-Renditen über verschiedene Lookback-Perioden
- Volatilitäts-adjustierte Signalstärke
- ML-Regime-Filter (Trend vs. Range)

Literatur: FX-004 (Menkhoff et al. 2012), FX-005, FX-012, FX-023
"""

from typing import List, Dict, Optional
from datetime import datetime
import math
import logging

from .base import BaseStrategy, Signal, StrategyContext, RegimeState

logger = logging.getLogger(__name__)


class MomentumStrategy(BaseStrategy):
    """
    Time-Series Momentum Strategie für FX Futures.
    
    Diese Strategie identifiziert trendfolgende Signale basierend auf
    historischen logarithmischen Renditen über verschiedene Zeithorizonte.
    
    Literatur:
        - FX-004: Menkhoff et al. (2012) - Carry und Momentum als Hauptfaktoren
        - FX-005: Moskowitz et al. (2012) - Time-Series Momentum global
        - FX-012: Asness et al. (2013) - Momentum überall
        - FX-023: Baltas & Kosowski (2017) - Momentum in FX Futures
    
    Signallogik:
        - Long wenn log-return(lookback) > 0 und Regime = TREND
        - Short wenn log-return(lookback) < 0 und Regime = TREND
        - Signalstärke proportional zur Rendite / Volatilität (Sharpe-artig)
    
    Risikomanagement:
        - Positionsgröße invers zur Volatilität (Vol-Targeting)
        - Stop-Loss bei 2x täglicher Volatilität
        - Nur aktiv im Trend-Regime (laut HMM-Filter)
    """
    
    # Konfiguration der Lookback-Perioden
    LOOKBACK_PERIODS = [21, 63, 126]  # ~1, 3, 6 Monate
    MOMENTUM_WEIGHTS = [0.5, 0.3, 0.2]  # Gewichtung der Perioden
    
    def __init__(self):
        """Initialisiert die Momentum-Strategie."""
        paper_ids = ["FX-004", "FX-005", "FX-012", "FX-023"]
        super().__init__(
            strategy_id="HYP_01",
            name="Time-Series Momentum",
            paper_ids=paper_ids,
        )
    
    def required_features(self) -> List[str]:
        """
        Benötigte Features für Momentum-Strategie.
        
        Returns:
            Liste der Feature-Namen
        """
        return [
            'log_returns_21d',
            'log_returns_63d',
            'log_returns_126d',
            'realized_vol_21d',
        ]
    
    def regime_filter(self, context: StrategyContext) -> bool:
        """
        Prüft ob Trend-Regime vorherrscht.
        
        Momentum-Strategien funktionieren nur im Trend-Regime zuverlässig.
        Im Range-Regime sollten keine Signale generiert werden.
        
        Args:
            context: StrategyContext mit Regime-State
            
        Returns:
            True wenn TREND-Regime erkannt, False sonst
        """
        if context.regime_state is None:
            # Ohne Regime-Information konservativ bleiben
            self.logger.warning(f"Kein Regime-State für {context.symbol} -保守ative Einstellung")
            return False
        
        # Nur im Trend-Regime handeln
        if context.regime_state.regime_type != 'TREND':
            self.logger.debug(f"{context.symbol}: Nicht im Trend-Regime "
                            f"({context.regime_state.regime_type})")
            return False
        
        # Zusätzliche Prüfung: Trendrichtung sollte konsistent sein
        if context.regime_state.confidence < 0.6:
            self.logger.debug(f"{context.symbol}: Regime-Konfidenz zu niedrig "
                            f"({context.regime_state.confidence:.2f})")
            return False
        
        return True
    
    def generate_signals(self, context: StrategyContext) -> List[Signal]:
        """
        Generiert Momentum-Signale basierend auf gewichteten Lookback-Renditen.
        
        Args:
            context: StrategyContext mit Features
            
        Returns:
            Liste von Signalen (maximal 1 Signal pro Aufruf)
        """
        signals = []
        
        # Zuerst Regime-Filter prüfen
        if not self.regime_filter(context):
            # Kein aktives Signal im falschen Regime
            flat_signal = Signal(
                strategy_id=self.strategy_id,
                symbol=context.symbol,
                timestamp=context.timestamp,
                direction='FLAT',
                strength=0.0,
                entry_price=context.current_price,
                rationale="Regime-Filter nicht erfüllt (kein Trend-Regime)",
                paper_ids=self.paper_ids,
                confidence=0.5,
            )
            return [flat_signal]
        
        # Features extrahieren
        features = context.features
        if features is None:
            self.logger.error(f"Keine Features verfügbar für {context.symbol}")
            return []
        
        # Log-Renditen für alle Lookback-Perioden extrahieren
        momentum_score = 0.0
        for lookback, weight in zip(self.LOOKBACK_PERIODS, self.MOMENTUM_WEIGHTS):
            key = f"{lookback}d"
            if key in features.log_returns:
                ret = features.log_returns[key]
                momentum_score += weight * ret
        
        # Realized Volatility für Skalierung
        vol = None
        if 'simple_21d' in features.realized_vol:
            vol = features.realized_vol['simple_21d']
        elif 'parkinson_21d' in features.realized_vol:
            vol = features.realized_vol['parkinson_21d']
        
        if vol is None or vol <= 0:
            self.logger.warning(f"Keine gültige Volatilität für {context.symbol}")
            return []
        
        # Signalstärke berechnen (volatilitäts-adjustiert, Sharpe-artig)
        # Tägliche Volatilität aus annualisierter Vol berechnen
        daily_vol = vol / math.sqrt(252)
        if daily_vol <= 0:
            return []
        
        # Momentum-Score normalisieren (typischeRange: -0.1 bis +0.1 für log-returns)
        signal_strength = momentum_score / daily_vol
        # Clipping auf [-1, 1]
        signal_strength = max(-1.0, min(1.0, signal_strength))
        
        # Richtung bestimmen
        if abs(signal_strength) < 0.2:  # Threshold für minimales Signal
            direction = 'FLAT'
        elif signal_strength > 0:
            direction = 'LONG'
        else:
            direction = 'SHORT'
        
        # Stop-Loss berechnen (2x tägliche Volatilität)
        stop_distance = 2 * daily_vol * context.current_price
        if direction == 'LONG':
            stop_loss = context.current_price * (1 - stop_distance / context.current_price)
        elif direction == 'SHORT':
            stop_loss = context.current_price * (1 + stop_distance / context.current_price)
        else:
            stop_loss = None
        
        # Rationale zusammenstellen
        rationale_parts = [
            f"Momentum-Score: {momentum_score:.4f}",
            f"Annualisierte Vol: {vol:.2%}",
            f"Regime: {context.regime_state.regime_type}",
        ]
        if context.regime_state.trend_direction != 0:
            trend_dir_str = "UP" if context.regime_state.trend_direction > 0 else "DOWN"
            rationale_parts.append(f"Trend-Richtung: {trend_dir_str}")
        
        rationale = "; ".join(rationale_parts)
        
        # Signal erstellen
        signal = Signal(
            strategy_id=self.strategy_id,
            symbol=context.symbol,
            timestamp=context.timestamp,
            direction=direction,
            strength=signal_strength,
            entry_price=context.current_price,
            stop_loss=stop_loss,
            rationale=rationale,
            features_used={
                'momentum_score': momentum_score,
                'annualized_vol': vol,
                'daily_vol': daily_vol,
            },
            paper_ids=self.paper_ids,
            confidence=min(1.0, abs(signal_strength)),
        )
        
        signals.append(signal)
        self.logger.info(f"{context.symbol}: {direction} Signal mit Stärke {signal_strength:.2f}")
        
        return signals


def create_momentum_strategy() -> MomentumStrategy:
    """
    Factory-Funktion zur Erstellung einer Momentum-Strategie.
    
    Returns:
        Initialisierte MomentumStrategy-Instanz
    """
    return MomentumStrategy()
