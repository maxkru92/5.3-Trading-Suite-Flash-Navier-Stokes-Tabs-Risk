"""
Trade Suggestion Data Model.

Definiert das TradeSuggestion-Datenmodell für die Kommunikation zwischen:
- Screening Engine (erkennt Signale)
- Risk Manager (prüft Limits)
- Execution Engine (führt Orders aus)

Jede TradeSuggestion enthält vollständige Begründung mit:
- Strategie-Name und Paper-IDs
- Feature-Werte die zum Signal führten
- Regime-Zustand bei Signalgenerierung
- Risikokennzahlen (Volatilität, Stop-Loss, etc.)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class SuggestionStatus(Enum):
    """Status einer TradeSuggestion im Review-Prozess."""
    PENDING_REVIEW = "PENDING_REVIEW"      # Wartet auf manuelle Prüfung
    AUTO_APPROVED = "AUTO_APPROVED"        # Automatisch genehmigt (unter Limits)
    MANUALLY_APPROVED = "MANUALLY_APPROVED"  # Manuell genehmigt
    REJECTED = "REJECTED"                  # Abgelehnt (Risk/Compliance)
    EXECUTED = "EXECUTED"                  # Ausgeführt
    CANCELLED = "CANCELLED"                # Storniert


class ReviewDecision(Enum):
    """Entscheidung im Review-Prozess."""
    APPROVE = "APPROVE"
    REJECT = "REJECT"
    MODIFY = "MODIFY"  # Mit Änderungen genehmigen
    DEFER = "DEFER"    # Zurückstellen für spätere Prüfung


@dataclass
class RiskMetrics:
    """
    Risikokennzahlen für eine TradeSuggestion.
    
    Attributes:
        position_size_usd: Positionsgröße in USD
        position_size_contracts: Anzahl Kontrakte
        annualized_vol: Annualisierte Volatilität
        daily_var_95: 1-Tages-VaR (95%)
        expected_shortfall: Expected Shortfall (Tail Risk)
        max_loss_stop: Maximalverlust bei Stop-Loss-Auslösung
        margin_requirement: Margin-Anforderung
        leverage: Hebel der Position
    """
    position_size_usd: float
    position_size_contracts: int
    annualized_vol: float
    daily_var_95: float
    expected_shortfall: float
    max_loss_stop: float
    margin_requirement: float
    leverage: float


@dataclass
class TradeSuggestion:
    """
    Vorschlag für einen Trade zur Prüfung und Ausführung.
    
    Wird von der ScreeningEngine generiert und durchläuft:
    1. Risk-Manager-Prüfung (Limits, Sizing)
    2. Optional: Manuelles Review (bei großen Positionen)
    3. Execution (wenn genehmigt)
    
    Attributes:
        suggestion_id: Eindeutige ID der Suggestions
        timestamp: Erstellungszeitpunkt
        symbol: Instrumentsymbol
        strategy_name: Name der generierenden Strategie
        strategy_id: ID der generierenden Strategie
        paper_ids: Paper-Referenzen aus der Masterbibliographie
        direction: 'LONG' oder 'SHORT'
        entry_price: Empfohlener Einstiegspreis
        stop_loss: Stop-Loss-Preis
        take_profit: Take-Profit-Preis (optional)
        signal_strength: Stärke des Signals (-1.0 bis +1.0)
        rationale: Vollständige Begründung des Signals
        features_used: Dictionary der verwendeten Feature-Werte
        regime_state: Marktregime bei Signalgenerierung
        risk_metrics: Berechnete Risikokennzahlen
        status: Aktueller Status im Review-Prozess
        reviewer_notes: Notizen des Reviewers (bei manueller Prüfung)
        execution_price: Tatsächlicher Ausführungspreis (nach Execution)
        created_by: 'AUTO' oder 'MANUAL'
    """
    suggestion_id: str
    timestamp: datetime
    symbol: str
    strategy_name: str
    strategy_id: str
    paper_ids: List[str]
    direction: str  # 'LONG' or 'SHORT'
    entry_price: float
    stop_loss: float
    take_profit: Optional[float] = None
    signal_strength: float = 0.5
    rationale: str = ""
    features_used: Dict[str, float] = field(default_factory=dict)
    regime_state: Optional[str] = None
    risk_metrics: Optional[RiskMetrics] = None
    status: SuggestionStatus = SuggestionStatus.PENDING_REVIEW
    reviewer_notes: str = ""
    execution_price: Optional[float] = None
    created_by: str = "AUTO"
    
    def __post_init__(self):
        """Validierung der TradeSuggestion."""
        if self.direction not in ['LONG', 'SHORT']:
            raise ValueError(f"Ungültige Direction: {self.direction}")
        if not -1.0 <= self.signal_strength <= 1.0:
            raise ValueError(f"Signal-Stärke außerhalb [-1, 1]: {self.signal_strength}")
        if not self.paper_ids:
            logger.warning(f"TradeSuggestion {self.suggestion_id} ohne Paper-IDs")
    
    def to_review_dict(self) -> Dict[str, Any]:
        """
        Konvertiert TradeSuggestion in ein für Review geeignetes Dictionary.
        
        Returns:
            Dictionary mit allen relevanten Informationen für Reviewer
        """
        return {
            'suggestion_id': self.suggestion_id,
            'timestamp': self.timestamp.isoformat(),
            'symbol': self.symbol,
            'strategy': f"{self.strategy_name} ({self.strategy_id})",
            'paper_references': self.paper_ids,
            'direction': self.direction,
            'entry_price': self.entry_price,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit,
            'signal_strength': f"{self.signal_strength:.2f}",
            'rationale': self.rationale,
            'features': self.features_used,
            'regime': self.regime_state,
            'risk_metrics': {
                'position_usd': self.risk_metrics.position_size_usd if self.risk_metrics else None,
                'contracts': self.risk_metrics.position_size_contracts if self.risk_metrics else None,
                'var_95': self.risk_metrics.daily_var_95 if self.risk_metrics else None,
                'max_loss': self.risk_metrics.max_loss_stop if self.risk_metrics else None,
                'leverage': self.risk_metrics.leverage if self.risk_metrics else None,
            } if self.risk_metrics else None,
        }
    
    def format_for_logging(self) -> str:
        """
        Formatiert TradeSuggestion für Log-Ausgabe.
        
        Returns:
            Formatierter String für Logs
        """
        lines = [
            "=" * 80,
            f"TRADE SUGGESTION: {self.suggestion_id}",
            "=" * 80,
            f"Timestamp:    {self.timestamp.isoformat()}",
            f"Instrument:   {self.symbol}",
            f"Strategy:     {self.strategy_name} ({self.strategy_id})",
            f"Paper IDs:    {', '.join(self.paper_ids)}",
            "-" * 40,
            f"Direction:    {self.direction}",
            f"Entry Price:  {self.entry_price:.6f}",
            f"Stop Loss:    {self.stop_loss:.6f}",
            f"Take Profit:  {self.take_profit if self.take_profit else 'N/A'}",
            f"Signal Strength: {self.signal_strength:.2f}",
            "-" * 40,
            f"Regime State: {self.regime_state}",
            f"Rationale:    {self.rationale}",
        ]
        
        if self.features_used:
            lines.append("-" * 40)
            lines.append("Features Used:")
            for key, value in self.features_used.items():
                if isinstance(value, float):
                    lines.append(f"  {key}: {value:.6f}")
                else:
                    lines.append(f"  {key}: {value}")
        
        if self.risk_metrics:
            lines.append("-" * 40)
            lines.append("Risk Metrics:")
            lines.append(f"  Position Size: ${self.risk_metrics.position_size_usd:,.2f} "
                        f"({self.risk_metrics.position_size_contracts} contracts)")
            lines.append(f"  Daily VaR (95%): ${self.risk_metrics.daily_var_95:,.2f}")
            lines.append(f"  Max Loss (Stop): ${self.risk_metrics.max_loss_stop:,.2f}")
            lines.append(f"  Leverage: {self.risk_metrics.leverage:.2f}x")
            lines.append(f"  Margin: ${self.risk_metrics.margin_requirement:,.2f}")
        
        lines.append("=" * 80)
        
        return "\n".join(lines)
    
    def apply_review_decision(self, decision: ReviewDecision, 
                               notes: str = "", 
                               modified_entry: Optional[float] = None,
                               modified_size: Optional[int] = None) -> bool:
        """
        Wendet Review-Entscheidung auf TradeSuggestion an.
        
        Args:
            decision: Review-Entscheidung
            notes: Notizen des Reviewers
            modified_entry: Geänderter Einstiegspreis (bei MODIFY)
            modified_size: Geänderte Positionsgröße (bei MODIFY)
            
        Returns:
            True wenn Entscheidung erfolgreich angewendet
        """
        if decision == ReviewDecision.APPROVE:
            self.status = SuggestionStatus.MANUALLY_APPROVED
            self.reviewer_notes = notes
            return True
        
        elif decision == ReviewDecision.REJECT:
            self.status = SuggestionStatus.REJECTED
            self.reviewer_notes = f"Abgelehnt: {notes}"
            return True
        
        elif decision == ReviewDecision.MODIFY:
            if modified_entry is not None:
                self.entry_price = modified_entry
            if modified_size is not None and self.risk_metrics is not None:
                self.risk_metrics.position_size_contracts = modified_size
                # TODO: Risikokennzahlen neu berechnen
            
            self.status = SuggestionStatus.MANUALLY_APPROVED
            self.reviewer_notes = f"Modifiziert: {notes}"
            return True
        
        elif decision == ReviewDecision.DEFER:
            self.status = SuggestionStatus.PENDING_REVIEW
            self.reviewer_notes = f"Zurückgestellt: {notes}"
            return True
        
        return False
    
    def mark_executed(self, execution_price: float):
        """
        Markiert TradeSuggestion als ausgeführt.
        
        Args:
            execution_price: Tatsächlicher Ausführungspreis
        """
        self.status = SuggestionStatus.EXECUTED
        self.execution_price = execution_price
        logger.info(f"TradeSuggestion {self.suggestion_id} ausgeführt zu {execution_price:.6f}")
    
    def mark_cancelled(self, reason: str):
        """
        Markiert TradeSuggestion als storniert.
        
        Args:
            reason: Stornierungsgrund
        """
        self.status = SuggestionStatus.CANCELLED
        self.reviewer_notes = f"Storniert: {reason}"
        logger.info(f"TradeSuggestion {self.suggestion_id} storniert: {reason}")


def create_trade_suggestion(signal: Any,  # Signal aus Strategy
                             symbol: str,
                             strategy_name: str,
                             strategy_id: str,
                             paper_ids: List[str],
                             risk_metrics: RiskMetrics,
                             regime_state: Optional[str] = None,
                             suggestion_id: Optional[str] = None) -> TradeSuggestion:
    """
    Factory-Funktion zur Erstellung einer TradeSuggestion aus einem Signal.
    
    Args:
        signal: Signal-Objekt aus Strategy.generate_signals()
        symbol: Instrumentsymbol
        strategy_name: Name der Strategie
        strategy_id: ID der Strategie
        paper_ids: Paper-Referenzen
        risk_metrics: Berechnete Risikokennzahlen
        regime_state: Marktregime
        suggestion_id: Optionale eigene ID (sonst automatisch)
        
    Returns:
        Initialisierte TradeSuggestion-Instanz
    """
    import uuid
    
    if suggestion_id is None:
        suggestion_id = f"TDS-{uuid.uuid4().hex[:8].upper()}"
    
    return TradeSuggestion(
        suggestion_id=suggestion_id,
        timestamp=datetime.now(),
        symbol=symbol,
        strategy_name=strategy_name,
        strategy_id=strategy_id,
        paper_ids=paper_ids,
        direction=signal.direction,
        entry_price=signal.entry_price,
        stop_loss=signal.stop_loss if signal.stop_loss else signal.entry_price * 0.95,
        take_profit=signal.take_profit,
        signal_strength=signal.strength,
        rationale=signal.rationale,
        features_used=signal.features_used,
        regime_state=regime_state,
        risk_metrics=risk_metrics,
        status=SuggestionStatus.PENDING_REVIEW,
    )
