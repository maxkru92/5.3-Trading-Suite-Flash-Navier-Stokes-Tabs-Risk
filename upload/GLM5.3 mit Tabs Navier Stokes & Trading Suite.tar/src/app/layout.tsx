import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "KRUPP CAPITAL // TRADING SUITE MK-II",
  description:
    "Institutional 13-desk trading matrix: Volatility Complex, Options & Risk, Futures, Bonds, Commodities, FX, Stocks, ETFs, Central Bank Liquidity, Crypto L3 MBO, Stat-Arb and System Infrastructure.",
  keywords: ["trading", "volatility", "GEX", "L3 orderbook", "statistical arbitrage", "KRUPP CAPITAL"],
  authors: [{ name: "KRUPP CAPITAL Quant Architecture" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
