# KRUPP CAPITAL TRADING SUITE — Agent Worklog

---
Task ID: 1
Agent: Z.ai main orchestrator
Task: Build the complete core infrastructure for the 13-desk KRUPP CAPITAL TRADING SUITE (Next.js 16, TS strict).

Work Log:
- Created `src/lib/krupp/ring.ts` — zero-GC Float32Array ring buffer (push/at/last/fill/minMax).
- Created `src/lib/krupp/math.ts` — mulberry32 RNG, gauss, CBOECollector piecewise anchors (VIX 10→1.08 / 20→1.01 / 35→0.90 / ≥80→0.75), contangoRegime(), bsGreeks (BS greeks), ringStd/ringStdDiff/zOf/corrRing/halfLifeTicks, Catmull-Rom splineAt.
- Created `src/lib/krupp/types.ts` — all shared type contracts (InstDef/InstState/Book/MarketState/CrisisState/StatPair/L3State/TapeEvent/InfraState/DerivsState/LadderRow/ExpMoveRow…).
- Created `src/lib/krupp/universe.ts` — 88 instruments across all asset classes with per-tick vol params, tick sizes, sector betas (crisis-coherent: bonds rally, yields fall, JPY/CHF bid, gold safe-haven, copper/crypto/equities crash, VIX family spikes).
- Created `src/lib/krupp/store.ts` — Zustand store: `useKrupp` { revision, activeTab, subTabs, selection }, hooks useRevision/useSubTab/useSelected. Tab switching NEVER clears engine state.
- Created `src/lib/krupp/engine.ts` — master 5 Hz engine: factor model (MKT + 7 sector OUs), crisis state machine (intensity ramp 0→1, phases SHOCK/LOCKDOWN/RECOVERY, 90 s auto-recovery, flash jumps), book builder, IV pass, real VIX contango rings (model = piecewise anchors, market = VIX3M/VIX), MS-GARCH(1,1) SPX realized-vol ring (scaled to vol pts), 4 stat-arb pairs (GOLD×US10YR, Copper/Gold×1000, SPY/HYG, BTC/NQ) with z-rings + OU half-life, startCrisis/endCrisis, bootstrapKrupp(). Exports: ms, getInst, getBook, startCrisis, endCrisis, bootstrapKrupp, ensureEngine.
- Created `src/lib/krupp/liquidityService.ts` — 1 Hz: Fed/ECB/BOJ BS + TGA + RRP with crisis drains, netH ring (Fed−(TGA+RRP)), mirrors FED_BS/ECB_BS/BOJ_BS/TGA/RRP into ms.inst.
- Created `src/lib/krupp/l3service.ts` — 16 Hz crypto L3 MBO worker (BTC-USD/ETH-USD/SOL-USD): unique order IDs, queue positions, cancel-rate EMA, iceberg detection log, CVD ring, OFI, tape (newest-first, cap 48), 12-level book, crisis liquidation cascades. Exports getL3(sym), l3Symbols().
- Created `src/lib/krupp/infraservice.ts` — 0.7 Hz: Cloudflare state machine (CLEAR/CHALLENGE/ROTATING/BLOCKED), UA rotation (6 profiles), 3 proxy latency rings + ok/fail counters, Redis tps ring, QuestDB queue ring, 6 WS feeds health, Firebase token lifecycle w/ expiry countdowns + rotation logs, log console (cap 160). Exports `infra`.
- Created `src/lib/krupp/derivs.ts` — 1 Hz derivatives engine on ES1! spot: 41 relative strikes (0.90–1.10), 9 expiries (0/1/2/3/7/14/30/60/90 DTE), IV surface grid (skew+smile, term structure from VIX family), OI drift + crisis put accumulation, dealer GEX per strike + flip level, max-pain curve + strike, ±11 strike option ladder with full BS greeks, expected-move table. Exports getDerivs().
- Chart library `src/components/krupp/charts/`: Canvas.tsx (DPR + ResizeObserver + rAF/fps), LineChart.tsx (multi-series, shade bands, hlines, markers, legend, zero-alloc draw), BarChart.tsx, Heatmap.tsx (hover tooltip), Sparkline.tsx, Gauge.tsx, Surface3D.tsx (2.5D vol surface), DepthLadder.tsx (direct-DOM rAF ladder).
- UI kit `src/components/krupp/ui.tsx`: Panel, Badge (tones), Stat, FlashAlert, SectionLabel, Tbl/Tr/Td (sticky-header mono tables), clsNum.
- `src/components/krupp/DeskFrame.tsx`: DeskFrame (title/code/subtab bar bound to store) + SubPane.
- `src/components/krupp/CrisisOverlay.tsx`: flashing crimson SYSTEMIC CRISIS LOCKDOWN overlay w/ intensity bar + countdown.
- `src/components/krupp/Shell.tsx`: header (brand, L3/TICKS/WS-LAT/AUTH-TTL chips, UTC clock), 13-tab bar w/ lucide icons, main desk area, sticky footer steering block: SIMULATE MARKET LIQUIDITY CRASH button, TERMINATE during crisis, 3 interceptor chips (Block Mean Reversion / Reduce Size / Emergency Flattening — staggered engagement 400/900/1400 ms, user-toggleable).
- `src/app/page.tsx` renders Shell; layout metadata set; globals.css: crisis-flash/crisis-blink/krupp-boot keyframes, terminal scrollbars, dark color-scheme.

Stage Summary:
- Core is DONE and typechecked against itself. 13 desk files are stubbed for agents:
  `src/components/krupp/desks/Desk01Volatility.tsx` … `Desk13Infra.tsx` (default exports, imported by Shell).
- AGENTS: build ONLY your own desk file(s). Never edit core files, Shell, or other desks.
- Data access pattern: charts read `ms`/`infra`/`getL3`/`getDerivs` DIRECTLY inside draw closures (rAF, zero React re-render). Tables re-render on `useRevision()` (5 Hz).

---
Task ID: 2-g
Agent: Z.ai sub-agent (Desk Builder 12–13)
Task: Build Desks 12 & 13 — Desk12StatArb.tsx (STAT-ARB & CROSS-ASSET SPREAD DESK) and Desk13Infra.tsx (SYSTEM INFRASTRUCTURE TERMINAL).

Work Log:
- Read worklog Task 1 + core contracts: types.ts (StatPair/InfraState/AuthToken/InfraLog/ProxyStat/WsFeed), engine.ts (ms, updatePair semantics: hl in engine ticks, z ring 600, severity thresholds 2.5/3.5), infraservice.ts (infra singleton, 0.7 Hz tick, logs newest-first cap 160, tokens ttl0/expAt), ring.ts, format.ts, ui.tsx, DeskFrame.tsx, LineChart/BarChart/Gauge/Heatmap/Canvas, store.ts (useRevision/useSubTab).
- Created src/components/krupp/desks/Desk12StatArb.tsx (301 lines, deskId=11, accent rose):
  * Module-scratch guarded ensure pattern: HL_DECAY — 4× Ring(240) fed by a single 1 Hz setInterval (guarded by module-level timer + window check); pushes pair.hl, skips NaN by repeating last valid reading; armed in a mount useEffect.
  * RELATIVE VALUE SPREAD MATRIX: 4 PairCards (grid md:grid-cols-2), each = raw spread LineChart (cyan #22d3ee, fmtV 3dp, zeroLine) + z-score LineChart (violet #a78bfa) with hlines +2.5 "ENTRY SHORT" / −2.5 "ENTRY LONG" (amber) and thin ±3.5 rose dash lines + zeroLine; stats row (Z NOW tone by |z| >3.5 rose / >2.5 amber / else emerald, SPREAD 3dp, HALF-LIFE ≈X.Xs via hl*0.2 with NaN→'—', signal badge LONG_SPREAD emerald "LONG SPREAD — BUY A SELL B" / SHORT_SPREAD rose / FLAT zinc); FlashAlert active when severity!=='NONE' — WARN amber "DEVIATION SIGNAL ±2.5σ — PREMIUM DECAY TRACKING ENGAGED", SEVERE rose "SEVERE DEVIATION ±3.5σ — CO-INTEGRATION STRESS" with OU decay %/tick children.
  * CO-INTEGRATION & MEAN-REVERSION RADAR: 4 Gauges (value=clamp(|z|/4*100,0,100) read live in draw closure, zones 0-50 emerald/50-80 amber/80-100 rose, label pair.id) + 4-row Tbl PAIR|Z|SEVERITY|HALF-LIFE|ADJ-SCORE (|z|/hl×100, NaN→'—')|SIGNAL.
  * HISTORICAL PREMIUM DECAY: 4 tiny "HL DECAY" LineCharts (h-16, emerald, fmtV converts ticks→s) over the module HL_DECAY rings.
  * Crisis FlashAlert "CRISIS CORRELATION REGIME — SPREADS WIDE, CROWDED EXITS" active on ms.crisis.active; header badges (N/4 pairs deviated, severe pulse).
- Created src/components/krupp/desks/Desk13Infra.tsx (464 lines, deskId=12, accent violet, 3 sub-tabs via useSubTab(12)+SubPane):
  * Sub-tab 1 SCRAPLING STEALTH: Cloudflare clearance card (cfStatus tone map CLEAR emerald/CHALLENGE amber/ROTATING cyan/BLOCKED rose+pulse, status copy, local UptimeChip on module INFRA_BOOT_T); UA pool Tbl with active row bg-cyan-950/40 + ACTIVE badge and stable FNV-1a fingerprint hashes computed once at module init (UA_HASHES); proxy latency LineChart (3 rings, emerald/amber/cyan) + per-lane ok/fail ratio + last-latency cells; success Gauge (infra.success.last()*100, zones rose <92 / amber 92–97 / emerald >97); request accounting Stats (reqOk, reqFail, fail %, scrapePerMin).
  * Sub-tab 2 DATA-API HUB: Redis tps LineChart (cyan) + current-tps + 240s-ring-peak Stats; QuestDB queue LineChart (amber) + depth fCompact + WAL state + FlashAlert active when queue.last()>2500 "QUESTDB WRITE BUFFER BACKLOG — WAL COMPACTION QUEUED"; WebSocket health Tbl (status badge CONNECTED emerald/RECONNECTING amber pulse/STANDBY zinc, latency amber >100ms); storage pipeline mono <pre> diagram REDIS STREAM → ENRICH WORKER ×4 → QUESTDB (WAL) → DESK MIRRORS ×13 with live tps/queue/latency/success counts.
  * Sub-tab 3 FIREBASE TOKEN LIFECYCLE: crisis FlashAlert "OPS DEGRADED — CF CHALLENGE RATE SPIKE + TOKEN CHURN" active when ms.crisis.active && infra.cfStatus!=='CLEAR'; 3 token cards (label, issued fClock, TTL bar width=(expAt−now)/ttl0 recomputed at 5 Hz via useRevision, countdown fCountdown rose <15s, status badge ACTIVE/EXPIRING/EXPIRED-ROTATING); expiry counter Stat (infra.expired); FIREBASE-filtered rotation log (last 12); full event console Tbl (slice 40, maxH max-h-[360px], LEVEL badges INFO zinc/OK emerald/WARN amber/CRIT rose pulse).
- Engineering: 'use client' + default exports; all numerics font-mono; no indigo/blue anywhere; zero allocation inside chart draw closures (rings/inline math only); render-time allocations limited to 5 Hz React surfaces (filters/slices of logs); no new deps; core files untouched.
- Verified: `bunx tsc --noEmit` → zero errors in both files (remaining errors are missing sibling desk stubs from other agents + pre-existing core/examples issues); `bunx eslint` scoped to desks/Desk12StatArb.tsx + desks/Desk13Infra.tsx → 0 problems.

Stage Summary:
- Desk 12 & Desk 13 are DONE and integrated with Shell's existing imports (./desks/Desk12StatArb, ./desks/Desk13Infra).
- Features: z-band entry radar with OU half-life decay history, co-integration gauges, crisis correlation alert; full infra terminal with stealth session monitor, ingestion/storage health and token lifecycle console.
- Lint: MY two files clean (exit 0). Full `bun run lint` reports 2 pre-existing errors in core files owned by Task 1 (DeskFrame.tsx react/jsx-no-comment-textnodes @47:55, Canvas.tsx react-hooks/refs @18:3) — left untouched per "do NOT touch anything else".

Return: files=Desk12StatArb.tsx (301 lines), Desk13Infra.tsx (464 lines); features as listed above; lint status=clean for both deliverables; deviations=none (spec literal; UptimeChip + ADJ-SCORE scaling and OU-decay children copy implemented as local, spec-consistent details since they were named but not exported by core).
---
Task ID: 2-a
Agent: Desk-01 builder (volatility complex)
Task: Create src/components/krupp/desks/Desk01Volatility.tsx — VOLATILITY COMPLEX DESK (4 sub-tabs: Term Structure, Vol-of-Vol, IV vs RV Tensor, Asset Vectors). Only this file; no other file touched.

Work Log:
- Read worklog Task-1 API sheet + confirmed signatures in types.ts, math.ts (piecewise/splineAt/zOf/contangoRegime/VIX_BASIS_ANCHORS), ring.ts, engine.ts (ms, garch, garchS, volComplex, crisis), format.ts, ui.tsx, DeskFrame.tsx, LineChart.tsx, Sparkline.tsx, universe.ts (G.VOL_COMPLEX/VOL_ASSETS/VOL_HUB), store.ts (useRevision/useSubTab).
- Module-level persistent state (survives tab switches): iv60Ring=Ring(600), curveNow/curvePrev Float32Array(24), anchorNow/anchorPrev Float32Array(4), `started` guard + ensureDesk1Series() 200 ms module interval (guarded on window): rebuilds Catmull-Rom curve via splineAt over [VIX9D,VIX,VIX3M,VIX6M] mapped to maturities [9,30,91,182]D, pushes IV60 = 0.55·VIX+0.45·VIX3M every tick, and snapshots curveNow→curvePrev + anchors every ~5 s for drift view. Initial snapshot copied at start so chart never shows zeros.
- Sub-tab 1 TERM STRUCTURE: LineChart of spline scratch (CURVE T cyan vs CURVE T−5s zinc dashed); 4 anchor cards with live last + Δ5s drift (toneNum); REAL VIX CONTANGO panel — big Stats (model ratio 4 dec emerald / market VIX3M/VIX + basis Δ) + LineChart of contangoReal (emerald) vs contangoMarket (zinc dashed) with PARITY 1.00 hline; CBOECollector anchor Tbl (≤10→1.08, 10–20, 20–35, 35–80, ≥80→0.75) with active piecewise segment row highlight (cyan border-l + bg) + live piecewise(VIX) footer row cross-checked vs engine ring; always-active regime FlashAlert (tone map: STRONG_CONTANGO=emerald, MILD_CONTANGO=cyan, FLAT=amber, BACK/CRISIS=rose) with exact regime string + one-line interpretation (CRISIS copy verbatim per spec).
- Sub-tab 2 VOL-OF-VOL: LineChart VVIX.ivHist (cyan) + SKEW.ivHist (violet) with hlines y=120 emerald "CONTRARIAN BUY THRESHOLD 120" and y=80 amber "COMPLACENCY FLOOR 80"; automated signal FlashAlert (≥120 rose STRONG CONTRARIAN BUY / <80 amber EXTREME COMPLACENCY / else inactive NEUTRAL, exact spec copy); Stats: VVIX last, SKEW last, SKEW z zOf(ivHist,240), VVIX percentile proxy clamp(z·50+50,0,100); Put/Call tail stress Tbl (4 VVIX bands with state/dealer vanna-charm positioning/playbook) + current band highlight.
- Sub-tab 3 IV vs RV TENSOR: LineChart IV30=VIX.ivHist (rose) + RV=ms.garch (emerald) + IV60=module iv60Ring (violet dashed), shade band VIX.ivHist vs ms.garch in #f59e0b; VOL-PREMIUM Stat (VIX.last−garch.last() vol pts, clsNum tone, sub label VOL-PREMIUM/VOL-DISCOUNT) + IV30/IV60 stats; GARCH(1,1) parameter Tbl (ω=1e-9, α=0.06, β=0.92, persistence 0.98 half-life ≈34 ticks, σ̂ tick = ms.garchS.toFixed(8), annualization ×46000) + VOL-PREMIUM DIAGNOSTICS Tbl (IV30−RV, IV60−RV, IV30−IV60, RV/IV30 ratio).
- Sub-tab 4 ASSET VECTORS: crisis FlashAlert (active when ms.crisis.active, intensity/phase in copy); Stat grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 over G.VOL_ASSETS with last (fPx), changePct (toneNum/fPct), IV regime Badge from zOf(ivHist,240) (HIGH rose pulse / LOW emerald / MID zinc) + Sparkline of ivHist color-coded by z; full mono Tbl TICKER|LAST|CHG%|IV-LEVEL|RV-PROXY|SPREAD(IV−RV)|Z-SCORE|LIQ over VOL_ASSETS+VOL_HUB (9 rows) with toneNum/clsNum tones.
- DeskFrame deskId=0, accent cyan, right = regime Badge (pulse on CRISIS_BACKWARDATION) + live VIX price/changePct; useRevision() 5 Hz for stats/tables; chart closures read module state directly, zero per-frame allocation; all numerics mono via fN/fSign/fPct/fPx/fVolPts.

Stage Summary:
- DELIVERED: src/components/krupp/desks/Desk01Volatility.tsx (597 lines, default export Desk01Volatility, 'use client'). Wired 100% to live engine APIs (ms.volComplex, ms.garch/garchS, ms.inst[...].ivHist/hist/rv/liq/changePct, ms.crisis) — zero placeholders.
- Verification: `bunx eslint src/components/krupp/desks/Desk01Volatility.tsx` → 0 problems; `bunx tsc --noEmit` → 0 errors in this file (remaining project errors are missing desk stubs of other agents + 2 pre-existing core-file lint errors in Canvas.tsx/DeskFrame.tsx — untouched per instructions).
- Module intervals: single guarded 200 ms interval (spline + IV60 + 5 s drift copy). No React state for series; safe under tab switching and HMR.

---
Task ID: 2-e
Agent: Z.ai sub-agent (desks 08 + 09)
Task: Build Desk08Stocks.tsx (deskId=7 — Global Liquid Equities + L3 Monitors) and Desk09Etf.tsx (deskId=8 — SPDR & Macro ETF Desk).

Work Log:
- Read worklog Task 1 + core API (types.ts, engine.ts, universe.ts, ring.ts, math.ts, format.ts, store.ts, ui.tsx, DeskFrame.tsx, all charts).
- Desk08Stocks.tsx: 12-name (7 US + 5 EU) quotes Tbl (SYM|NAME|LAST|CHG%|BID×ASK|SPREAD|VOL fCompact|IV|OFI|LIQ) at 5 Hz; module-level FUNDAMENTALS constant for all 12 names (P/E × EPS reconciles to sandbox px0) rendered as second Tbl under a live 2 s guarded ZIP-manifest parser telemetry line (`PARSING ZIP MANIFEST :: SYM.FUND.zip → 6 RECORDS OK (crc ✓)` rotating symbols, mono + UTC timestamp); L3 monitor: useSelected('desk8','NVDA') + 12 instrument chips, DepthLadder rows=8, top-3 bid/ask imbalance + spread + book seq + liq-score Stat grid, bid/ask mass split pressure bar, FlashAlert when top-3 book imbalance > 0.65 ("L3 BOOK IMBALANCE — INSTITUTIONAL SIDE LOADING"); Mag-7 sparkline strip (7 mini cards, 600-tick hist rings); accent cyan, code EQ/CORE-L3-MONITOR.
- Desk09Etf.tsx: DeskFrame subtabs ['SECTOR MATRIX','PILLAR MACRO ETFS'], accent violet, code ETF/SECTOR-ROTATION. Sub-tab 1: Heatmap rows=10 SPDR symbols × cols [LAST,CHG%,1D-Z,OFI,IV,LIQ] from module number[10][6] recomputed on guarded 1 s interval (chg%=changePct/2 clamp, z=zOf(hist,240), ofi, iv, liq/100; scale diverging, 2dp); "ACTIVE SECTOR ROTATION INDEX (MOMENTUM RANK)" BarChart of 1-session momentum (hist.at(0)→hist.last()) sorted desc via reusable BarSpec[] + Int32Array insertion sort (emerald/rose); sector quotes Tbl with LEAD/MID/LAG rotation badges by rank. Sub-tab 2: 8 pillar ETF cards (SPY/QQQ/GLD/SLV/USO/IBIT/ARKK/ARKB) with module FUND records {aum $B, ER %, tracking index, note incl. required IBIT/ARKB/GLD notes}, last/chg%/AUM/ER/FLOW(tone)/Sparkline; flow24h $M random-walked on the 1 s pass with mean reversion to base and crisis outflows (high-beta funds 1.5×); reusable flow BarChart ($M, zero line); rose FlashAlert "ETF CREATION/REDEMPTION STRESS — AP DESKS ON PAUSE" bound to ms.crisis.active + flow aggregate stats.
- Engineering: 'use client', default exports, module-level persistent state + guarded globalThis ensure pattern per file (never allocate in draw closures; heatmap/bars return module arrays), useRevision() 5 Hz for tables/cards, all numerics font-mono, no indigo/blue, responsive grids, Tbl scrolling.
- `bunx eslint` on both files: 0 problems; `tsc --noEmit`: no errors in Desk08/Desk09 (remaining project errors are other agents' missing desk stubs + pre-existing core/examples issues).

Stage Summary:
- Desks 08 + 09 COMPLETE (751 lines total: Desk08Stocks 358, Desk09Etf 393). Shell tab wiring already references these default exports — no other files touched. Zero placeholders: 12 fundamentals records, 8 FUND profiles, flow bases invented; everything else live from engine rings. Deviations: none material — Desk08 FlashAlert uses amber tone for the book alarm; Desk09 heatmap CHG% column stores changePct/2 clamped ±1 per spec formula.
---
Task ID: 2-f
Agent: Z.ai sub-agent (general-purpose)
Task: Build Desks 10 & 11 — Central Bank Liquidity Desk (MACRO/GLI-NET-LIQ) and Crypto L3 MBO Desk (DIGITAL/MBO-OFI-ENGINE).

Work Log:
- Read worklog.md Task 1 + all core files (types.ts, engine.ts, l3service.ts, ring.ts, math.ts, format.ts, store.ts, ui.tsx, DeskFrame.tsx, charts/LineChart|Gauge|Sparkline|BarChart|Canvas, liquidityService.ts) for exact signatures.
- Created `src/components/krupp/desks/Desk10Liquidity.tsx` (345 lines, deskId=9, accent emerald, single view):
  * GLOBAL LIQUIDITY INDEX panel — LineChart fedH(emerald)/ecbH(cyan)/bojH(amber) with fmtV (v/1000).toFixed(2)+'T' + Fed/ECB/BOJ Stat row with 1H Δ (ring at(0) vs last) via toneNum.
  * TGA & RRP panel — LineChart tgaH(rose)/rrpH(violet) + level/Δ stats + sign-of-60-tick-diff badges: "RRP DRAWDOWN ⇒ COLLATERAL RELEASE" / "TGA REBUILD ⇒ RESERVE DRAIN" (tones flip with sign).
  * NET LIQUIDITY PROXY panel — big mono formula block `NET LIQ = FED_BS − (TGA + RRP)` with live fN(v/1000,2)+'T' substitution and colored resolve line; symmetric BarChart contribution breakdown (FED Δ / −TGA Δ / −RRP Δ, rebuilt in render @5Hz — 3 tiny objects, draw closure reads only) + 4 contribution Stats.
  * S&P 500 × NET-LIQ overlay — module Float32Array(360) netNorm + Float32Array(600) spxNorm (ES1! hist, exposed as aligned tail-360 subarray view), both % rebased to window start, rebuilt on guarded 500ms module interval (globalThis flag `__kruppDesk10Series`); hline y=0; last-3 sign-inflections of the netH 30-tick diff ($B deadband 1.0) scanned in the same interval into a preallocated Marker pool, markers() returns it by reference — zero allocation in any draw closure.
  * GLI PRESSURE Gauge value=clamp(50+netΔ60*8,0,100) with rose/amber/emerald zones + crisis FlashAlert "LIQUIDITY CRISIS — TGA REBUILD + RRP SPIKE COMPOUNDING QT" + NET Δ60T / intensity / phase stats; header badges NET LIQ + crisis regime.
- Created `src/components/krupp/desks/Desk11Crypto.tsx` (276 lines, deskId=10, accent amber):
  * Token selector chips BTC-USD/ETH-USD/SOL-USD bound to useSelected('desk11')/select, in DeskFrame right slot.
  * L3 MARKET-BY-ORDER TAPE — Tbl maxH="max-h-[420px]" mapping l3.tape (service array, newest-first) directly @5Hz: TIME fClock(t).slice(0,8), ORDER ID, SIDE B-emerald/S-rose badges, PRICE fPx per-tick decimals, QTY, QUEUE POS, ACTION NEW-cyan/CXL-amber/FILL-emerald/rose, ICE rose pulse "ICEBERG" badge; row background flash by act.
  * Stats strip: open orders, cancel-rate %, tps, mid, CVD last fCompact, OFI toneNum.
  * OFI & CVD panel — LineChart cvd Ring (emerald) with hline 0 + FLOW BALANCE Gauge value=(ofi+1)*50 with rose/amber/emerald zones.
  * ICEBERG DETECTION FEED — FlashAlert active when newest iceberg < 15s ("LARGE ORDER ICEBERG DETECTED — HIDDEN CHILD ORDERS REFILLING") + Tbl of l3.icebergs (fAgo age, sym, px, estQty fCompact, oid).
  * 3-TOKEN CVD COMPARISON — LineChart of raw cvd rings via getL3 (amber/cyan/violet) + per-token mini stat cards with Sparkline(cvd), MID/CVD/OFI/TPS, FOCUS badge on selection.
  * Crisis FlashAlert "LIQUIDATION CASCADE ENGINE ACTIVE — BID WALL SWEEP DETECTED" active when ms.crisis.active && l3.ofi < −0.4.
- Fixed lint issues in my files only: react-hooks/immutability rejected render-time mutation of a module BarSpec pool → contribution bars now rebuilt in component body (per spec "computed in render at 5 Hz — cheap"); Td has no style prop → token color via className map.
- Verified: `bunx eslint <both files>` → 0 problems; `bunx tsc --noEmit` → 0 errors attributable to Desk10/Desk11.

Stage Summary:
- Desks 10 & 11 COMPLETE: 621 lines total, default exports Desk10Liquidity/Desk11Crypto matching Shell imports, typecheck- and lint-clean.
- Engineering rules honored: 'use client'; guarded module ensure pattern (500ms) for all derived overlay series; no per-frame allocation in chart closures (Rings/subarray views returned by reference); tape maps the service array directly; useRevision drives 5 Hz table/stat updates; no indigo/blue; responsive grids; scrollable tables.
- Note: full-project `bun run lint` still reports 2 PRE-EXISTING errors in Task-1 core files (charts/Canvas.tsx react-hooks/refs drawRef.current assignment; DeskFrame.tsx jsx-no-comment-textnodes on the "DESK {id} // {code}" text) — untouched per agent boundary rules, flagging for orchestrator.

Return: files=src/components/krupp/desks/Desk10Liquidity.tsx (345 lines), src/components/krupp/desks/Desk11Crypto.tsx (276 lines); features=GLI index chart, TGA/RRP drain monitor w/ regime badges, net-liq formula resolve + symmetric contribution BarChart, S&P500×NETLIQ normalized overlay w/ 3 LIQ-inflection markers, GLI pressure gauge, crisis flash; L3 MBO tape (8 cols, action/iceberg badges, row flash), 6-stat strip, OFI&CVD chart + flow-balance gauge, iceberg feed + <15s flash, 3-token CVD comparison + mini stats, liquidation-cascade flash; lint=clean (my 2 files; 2 pre-existing core errors reported upstream); deviations=contribution bars built in render instead of mutating module pool (react-hooks/immutability), LineChart has no fill option so CVD drawn as line (fill omitted), GLI gauge uses spec formula literally so needle pins to extremes (calm≈100 / crisis≈0).

---
Task ID: 2-b
Agent: GLM Subagent — Desk 02 Builder
Task: Build src/components/krupp/desks/Desk02Options.tsx — OPTIONS TRADING & RISK DESK (4 sub-tabs) per CORE API sheet. Single-file deliverable, no other files touched.

Work Log:
- Read worklog.md + core contracts (types.ts, derivs.ts, math.ts, ui.tsx, DeskFrame.tsx, Surface3D/BarChart/LineChart/Canvas, format.ts, ring.ts, store.ts, engine.ts exports, Shell.tsx mount path).
- Implemented module-level persistent state: 24×41 number[][] surface grid, xLabelsArr[41], yLabelsArr[24], Float32Array scratches smile7/smile30/painArr/spotLine, reused BarSpec arrays termBars(9)/gexBars(41)/vannaBars(41), painMarkers[1] (marker pos = 40 − argmin(pain) recomputed 1 Hz), plus 1 Hz aggregate vars (rr25, skewSlope LSQ, termSpread, netGex, oiCall/oiPutSum, strike lo/hi, gexPeak/callWall/putWall indices).
- Guarded ensure pattern: started flag + `typeof window === 'undefined'` bail + D.updatedAt/D.iv-shape guard; single setInterval(rebuild, 1000) + immediate rebuild(); zero allocation in any draw closure (all chart closures return module buffers by reference).
- SUB-TAB 1: Surface3D (linear upsample of 9 expiry rows → 24, DTE y-labels, $-strike x-labels), LineChart 7D vs 30D smiles (fmtV toFixed(1)), BarChart ATM term structure (9 expiry IVs, DTE labels), Stat cards: ATM IV, 25Δ RR proxy (iv[4][30]−iv[4][10] = 105%−95%), LSQ skew slope, term spread 30−7, plus 7-DTE wing monitor table.
- SUB-TAB 2: GEX BarChart (symmetric, per-strike emerald/rose, strike labels ×25, zero hline #4a5468, fCompact fmt), Stat cards GEX FLIP / spot→flip pts+bps / NET dealer positioning (emerald "LONG GAMMA — VOL SUPPRESSED" vs rose "SHORT GAMMA — VOL AMPLIFIED"), FlashAlert when |spot−flip| < 0.4%, Vanna proxy BarChart (bsGreeks 7D vega × 0.02 × (K/S−1), symmetric, teal/rose) + dealer book reference table (call/put walls, gamma peak, max pain, net GEX).
- SUB-TAB 3: Pain curve LineChart from module Float32Array(41) with MAX PAIN marker at argmin (index-from-newest conversion), expected-move cone LineChart (spot constant series via Float32Array(2) scratch + 0D/7D ±EM hlines from D.expMove[0]/[2]), EM table (DTE|IV|UPPER|LOWER|RANGE %), max-pain stats + pin-risk FlashAlert at |gap| < 0.3%, 7D half-range stat.
- SUB-TAB 4: 18-column full-greeks ladder Tbl (max-h-[520px], 5 Hz) with delta-flash rows (|Δc|>0.8 rose-950/30, |Δc|<0.2 emerald-950/30), header stats (contracts, agg C/P OI via 1 Hz sums, C/P ratio, 0-1 DTE CHURN chip), execution ticket (useSelected('desk2opt', midStrike) strike select, CALL/PUT side buttons, qty input, 5 Hz live bsGreeks px/Δ/Γ/Θ/vega/ρ + est premium), PRE-TRADE INTERCEPTOR chips (rose ENGAGED when ms.crisis.active per ms.interceptors), sim order button → module blotter (cap 20, FILLED status) with instant repaint via useKrupp.getState().bump().
- Fix 1: eslint react-hooks/immutability flagged blotter mutation from component scope → moved mutation into module-scope pushBlotter(); component only calls it.
- Fix 2: wrong import path '@/lib/krupp/ui' → corrected to '@/components/krupp/ui'.
- Verified: bunx eslint on the file → 0 problems; tsc --noEmit → 0 errors attributable to Desk02Options.tsx (remaining project errors are other desks' / core / examples, out of scope); headless bun harness against live engine validated mult[10]=0.95/mult[30]=1.05, upsample endpoints exact, expMove[2]=7D, ladder 23 rows, marker index math.

Stage Summary:
- Desk02Options.tsx (777 lines) complete: 4 sub-tabs, all charts zero-alloc (module buffers mutated by one 1 Hz interval, draw closures return references), tables/stats live at 5 Hz via useRevision(). File lint-clean and type-clean in isolation. No other files modified.

Return:
- File: /home/z/my-project/src/components/krupp/desks/Desk02Options.tsx
- Lines: 777
- Features: 24×41 vol-surface upsample, 7D/30D smiles, ATM term bars, RR25/skew-slope/term analytics, wing monitor; GEX profile + flip/proximity alert + vanna proxy + book reference; pain curve w/ MAX PAIN marker + EM cone + EM table + pin-risk alert; 18-col greeks ladder w/ delta flash rows + execution ticket w/ live BS analytics + interceptor chips + 20-slot sim blotter.
- Lint: CLEAN (bunx eslint on file = 0 errors). Repo-wide `bun run lint` still red from OTHER agents' files (Desk05Metals, Canvas.tsx core) and unrelated examples/skills — not this deliverable.
- Deviations: (1) LineChart has no x-axis label support, so pain-curve strike range shown as panel badge instead of x tick labels (y fmtV per spec); (2) vanna y-axis uses fx(v,3) since proxy values are sub-0.01; (3) Surface3D subsamples y-labels internally (stride 4 → 6 shown of 24) — all 24 DTE labels are supplied; (4) blotter rows re-render via store bump rather than extra local state.

---
Task ID: 2-d
Agent: Z.ai sub-agent (Desk Builder 04 & 07)
Task: Build Desks 04 & 07 — Desk04Bonds.tsx (BOND FUTURES & SOVEREIGN DESK / GLOBAL YIELD VECTOR MAP) and Desk07Fx.tsx (FX FUTURES DESK / PPP-ENTROPY-HAWKES).

Work Log:
- Read worklog (Task 1) + core signatures: types.ts, engine.ts (ms/getInst/crisis), universe.ts (G), math.ts (clamp/lerp), ring.ts, format.ts, store.ts (useRevision/useSubTab/useSelected/select), ui.tsx, DeskFrame.tsx, Canvas/LineChart/Heatmap/Gauge/Sparkline, Shell.tsx (deskId mapping 3→Bonds, 6→FX).
- Created `src/components/krupp/desks/Desk04Bonds.tsx` (514 lines, deskId=3, accent amber, no subtabs):
  * Hand-crafted stylized SVG world projection (800×380 viewBox, ZERO placeholders): 5 interactive sovereign blobs (US/GB/FR/DE/JP) + 8 decorative landmasses (Greenland, S.America, Iberia, Scandinavia, Italy, Africa, Asia, Australia), graticule lines, dashed amber yield-vector mesh between hotspots, "STYLIZED PROJECTION — NOT TO SCALE" footer label.
  * Hotspots: sonar pulse via Tailwind animate-ping circles (transform-box: fill-box), dot + blob fill heat-mapped by 10Y yield on amber→rose lerp (domain 0.2–4.8%), per-country code/live-10Y/name SVG labels; onMouseEnter + onClick both select via useSelected('desk4','US') + select('desk4', code); selected state = amber stroke + dashed halo + row tint in tables.
  * COUNTRIES config exactly per spec (cdsBase 38/58/78/22/41; s2s10 fallback −2.31/−0.10/+0.05/+0.18/−0.25); US uses real US2Y instrument, others synthesize y2 = y10 + s2s10 + tiny live noise Math.sin(t/5000 + idx·1.7)·0.012.
  * Module persistent state + guarded ensureDesk04() (1s interval): Record<string,Ring(360)> curve10 pushed per country each 1s; slow10 snapshot ring receives cur.last() only every 60 ticks (per spec mechanism), both pre-seeded (300/240 pts of same walk → snapshot = same curve delayed 60 samples); CDS proxy = cdsBase×(1+2.5×crisis.intensity) + OU noise (0.95 decay); bond-option GEX per country = mean-reverting random walk in $B scaled by crisis.
  * Sovereign intelligence column: 6 Stats (10Y w/ Δ1D, 2Y real/synthetic, 2s10s bps, CDS proxy, GEX $B, curve Δ vs snapshot) + risk badge (>100 STRESSED rose pulse / >60 ELEVATED rose / else CONTAINED emerald) + LineChart curve shift (amber NOW vs dashed zinc SNAPSHOT−60s) + sovereign stress FlashAlert + SOVEREIGN RISK MATRIX table (click-to-select rows).
  * Desk aggregates strip: GLOBAL 10Y MEAN, YIELD DISPERSION σ, SOVEREIGN CDS MEAN, RISK BREADTH (n/5 elevated).
  * Bond futures board Tbl (ZN1!/ZB1!/JGB1!/BUND1!: LAST/CHG%/BID/ASK/SPRD/OI/VOL/LIQ) + sovereign yield grid Tbl (all 7 G.YIELDS with Δ1D in bp) — both rows click-select the owning country; crisis regime badge in DeskFrame right.
- Created `src/components/krupp/desks/Desk07Fx.tsx` (331 lines, deskId=6, accent teal):
  * 6 quote cards (G.FX_FUT): last (fPx per-tick decimals), chg% badge, EVZ-linked IV, sign-tinted Sparkline of inst.hist, OFI + LIQ footer.
  * Cross-rate matrix: module-level 6×6 number[][] mutated in place on guarded 1s interval (cross[i][j]=lastᵢ/lastⱼ, diagonal 0), Heatmap scale='mono' fmt=toPrecision(4), module LBL gutter labels — values() returns the module array by reference (zero alloc).
  * PPP overlay: pppBase = px0ᵢ/px0ⱼ fixed at module init; devPct 6×6 = (cross/PPP−1)×100 in second Heatmap scale='heat'; entMat per-pair clamp(|dev|×20,0,100); PURCHASING POWER ENTROPY INDEX Stat = mean |dev| (module var) + Gauge zones <1 emerald / <2.5 amber / else rose (0..5) + worst-pair sub-line.
  * Hawkes flow toxicity: module Ring(600) pushed on guarded 200ms interval, λₜ = 0.35 + (λₜ₋₁−0.35)·e^(−0.2/5) + 8·Σ|ret_tick| over 6 contracts (ret from hist.last()/hist.last(1)); LineChart with hlines 2.0 rose "TOXICITY SPIKE" + 0.8 emerald "CALM"; FlashAlert "HAWKES TOXICITY SPIKE — FLOW SELF-EXCITATION DETECTED, WIDEN FAIR VALUE BANDS" at λ>2; λ Gauge 0..4 with calm/elevated/self-exciting zones; 260-point synthetic pre-seed so chart is populated at first paint.
  * FX board Tbl: SYM | LAST | CHG% | BID | ASK | SPREAD | IV | OFI | CVD | LIQ; USD COMPOSITE BETA Stat = −mean(last/px0−1)×100 across the 6 futures.
- Fixed my 7 tsc errors: Heatmap rows/cols typed () => string[] (dropped readonly on LBL); interactive rows use native <tr> (core ui.Tr has no onClick prop — core untouched) mirroring Tr styling.
- Verified: `bunx eslint` on both files → 0 problems; `bunx tsc --noEmit` → 0 errors in my files; bun module-load smoke test OK for both; full `bun run lint` shows only the 2 pre-existing Task-1 core errors (Canvas.tsx react-hooks/refs, DeskFrame.tsx jsx-no-comment-textnodes) — untouched per boundary rules.

Stage Summary:
- Desks 04 & 07 COMPLETE: 845 lines total, default exports Desk04Bonds/Desk07Fx matching Shell imports, typecheck- and lint-clean, module-load smoke-tested.
- Engineering rules honored: 'use client'; module-level persistent state + guarded ensure pattern (Desk04 1s; Desk07 200ms+1s); zero allocation in chart draw closures (Rings / module matrices returned by reference; Heatmap values() = module arrays); useRevision() drives all 5 Hz stats/tables/SVG labels; font-mono numerics throughout; no indigo/blue (amber/rose/emerald/zinc + mandated teal); responsive (Desk04 intel stacks above map on mobile via order utilities, map xl:col-span-2; Desk07 cards 2→3→6 cols; Tbl scroll containers); only listed imports + react + lucide-react.
- Return: files=src/components/krupp/desks/Desk04Bonds.tsx (514 lines), src/components/krupp/desks/Desk07Fx.tsx (331 lines); features=stylized interactive SVG yield-vector map w/ pulse hotspots + heat fills, sovereign intel (2s10s bps, CDS crisis proxy, GEX $B walk, risk badges, curve-shift dual-ring LineChart, stress FlashAlert, risk matrix), futures board + 7-yield grid w/ click-select; FX: 6 quote cards w/ sparklines, cross-rate Heatmap(mono), PPP deviation Heatmap(heat) + entropy index/gauge + worst pair, Hawkes λ engine @200ms w/ 2.0/0.8 hlines + spike FlashAlert + λ gauge, 10-col FX board, USD composite beta; lint=clean on both files (2 pre-existing core errors remain, reported upstream); deviations=(1) snapshot ring follows the explicit 60-tick mechanism → series labelled SNAPSHOT −60s (spec prose elsewhere said "5-min ago"); (2) interactive table rows are native <tr> because core Tr lacks onClick; (3) US 2s10s is data-driven from real US2Y (≈+31bp at px0) rather than the unused twoTenBase −2.31 fallback.
---
Task ID: 2-c
Agent: Z.ai sub-agent (desks 03/05/06)
Task: Build Desk03IndexFutures (deskId 2), Desk05Metals (deskId 4), Desk06Energies (deskId 5) for the KRUPP CAPITAL TRADING SUITE.

Work Log:
- Read worklog Task 1 + core API (types.ts, engine.ts, universe.ts, math.ts, ring.ts, format.ts, store.ts, ui.tsx, DeskFrame.tsx, all charts) before writing any code.
- Created `src/components/krupp/desks/Desk03IndexFutures.tsx` (321 lines): 7-card header grid (last, chg% toneNum, Sparkline(hist), spreadBps, div-based OFI bar); MODULE-LEVEL number[7][7] CORR matrix rebuilt on guarded 1s interval via corrRing(hist_i, hist_j, 240) → Heatmap rows=cols=symbols scale diverging fmt v.toFixed(2) + live ⟨ρ⟩ badge; MODULE-LEVEL number[15][24] liquidity-density heatmap on the same 1s interval (last 288 ticks → 24 time cols × 12 ticks, per-contract min/max → 15 price rows, tick-count proxy normalized 0..1, high price at top) → Heatmap scale heat; L3 section with useSelected('desk3','ES1!') chips (select('desk3',sym)) + DepthLadder rows=8 + side stats (bid/ask w/ L1 sizes, spread, liq score, book seq, OFI); master quotes Tbl (SYM|LAST|BID|ASK|CHG%|SPRD-BPS|VOLUME|OI|OFI|LIQ) at 5 Hz. accent emerald, no subtabs.
- Created `src/components/krupp/desks/Desk05Metals.tsx` (322 lines): 3 hero cards GC/SI/HG (last, chg%, high/low, IV vs RV, IV−RV spread pts, Sparkline, OFI/CVD rows); MODULE-LEVEL Ring(600) per metal pushed on guarded 200ms interval with rvRing = ringStdDiff(hist,120)*46000 + one-time O(n·120) backfill on boot → 3-up LineChart grid [IV = inst.ivHist amber, RV = rvRing emerald] with amber shade band and live IV−RV badge per chart; MM inventory skew: zero-alloc BarSpec[3] BarChart (symmetric, emerald/rose) + NET MM SKEW Stat with composite OFI_GC + 0.6·OFI_SI + 0.4·OFI_HG maintained as module var recomputed inside the 200ms interval (react-hooks/globals forbids module-var assignment during render — moved it out of render, still module-level); inventory tilt Tbl with BUY/SELL/NEUTRAL badges + conviction; watch Tbl GC/SI/HG/GLD/SLV with live futures-vs-ETF basis (ETF/ETF₀ − FUT/FUT₀)·100. accent amber, title/code per spec.
- Created `src/components/krupp/desks/Desk06Energies.tsx` (440 lines): quote cards CL1! primary (2-col, big px, sparkline, H/L, IV/RV, CVD, vol) + NG/RB/HO; 3-2-1 CRACK SPREAD CALCULATOR: big (2·RB+HO−3·CL)/3 value, MODULE Ring(600) of crack pushed on guarded 200ms interval (backfilled on boot from aligned hists) → LineChart, interactive useState inputs (RB a, HO b, CL c, gal/bbl 42) with live custom crack (a·RB+b·HO−c·CL)/c shown $/bbl + $/gal + ¢/gal sub, σ uncertainty chip = ringStd(crackRing,120)·100 cents; OIB tracker LineChart CL.ofiHist + NG.ofiHist with ±0.5 hlines + stats (OFI×2, CVD fCompact, sweep counter); INSTITUTIONAL CRUDE ACCUMULATOR SWEEP: 200ms module interval checks |ln(CL/prev)| > 3×def.vol → sweepCount++, unshift {t,px,side,bp} cap 8 → FlashAlert active <10s + sweep log Tbl (UTC time, px, BUY/SELL badge, |Δ|bp); crude complex basis Tbl: 4 energies full stats + 4 crack strips (3-2-1, RB−CL, HO−CL, NG−CL) with Δ% vs 120 ticks. accent orange (Badge tone 'orange' does not exist in ui.tsx Tone union → used 'amber' for that badge; DeskFrame accent="orange" is valid).
- All three files: 'use client', default exports, guarded ensureDesk{3,5,6}() as first statement of the component body (started flag + typeof window), module state mutated only inside intervals, useRevision() 5 Hz re-renders, chart closures read rings/matrices directly (no per-frame allocation; BarSpec array reused), font-mono numerics, no indigo/blue, responsive grids, Tbl scroll.
- Verification: scoped eslint on the 3 files → 0 problems; full `bun run lint` → only 2 pre-existing errors in CORE files (DeskFrame.tsx jsx-no-comment-textnodes, Canvas.tsx react-hooks/refs) — not mine, untouched; bunx tsc --noEmit → zero diagnostics for Desk03/05/06 (remaining project errors are missing/buggy sibling desks + core LineChart shade warning, owned by other agents); module import + renderToStaticMarkup smoke tests → all 3 render clean with live data; simulated client (window shim) confirmed desk intervals tick and values change across renders (e.g. crack −76.656 → −76.104).

Stage Summary:
- DESKS 03 / 05 / 06 DONE and verified: lint-clean, type-clean, live-render verified. 1083 lines total across the three files. Zero placeholders; all panels driven by engine state, module intervals and 5 Hz revision.
- Deviations: (1) Desk05 mmSkew composite is recomputed inside the 200ms module interval instead of during render (react-hooks/globals lint rule forbids module-var reassignment in render; identical live result). (2) Desk06 'CRACK LIVE' Badge uses tone 'amber' because ui.tsx Badge has no 'orange' tone (DeskFrame accent stays 'orange'). (3) Desk03 density heatmap row labels are %-of-window-range bands (cross-contract normalization makes absolute price labels meaningless). (4) Crack strips show em-dash N/A cells for book-specific columns (bid/ask/OFI/CVD/IV/RV) — spreads have no order book.
- Core-file lint errors (DeskFrame, Canvas) and other agents' desk errors remain out of scope.

---
Task ID: 3
Agent: Z.ai main orchestrator
Task: Integration, engine stability hardening, and end-to-end browser verification of the 13-desk suite.

Work Log:
- Fixed 2 core lint errors (DeskFrame jsx comment textnode; Canvas ref-during-render → moved into useEffect).
- Fixed 2 TS errors (LineChart shade narrowing; infraservice boolean arithmetic).
- HEADLESS REPRO + FIX of crisis death-spiral: F.MKT factor was accumulating crisis drift as a LEVEL (compounding −12%/tick at clamp). Refactored: F.MKT is now a strict mean-zero per-tick shock (decay 0.9/0.05, mVol 0.00025×(1+1.4I), clamp ±0.005); sector factors rebalanced identically (0.9/0.05, noise ×(1+2.6I)); crisis drift applied as bounded per-tick term mktDrift=−0.0002·I in the instrument loop (~−8% total drawdown at full intensity) + cooling bounce +0.0006·I; flash-jumps rarefied (1%/tick, single, drawdown-guarded, crypto floor 0.55/EQ 0.82) + rubber-band floors (px0×0.65 / 0.50 crypto). VIX family re-tuned (VIX→~83 peak, VIX9D>VIX short-end inversion; noise decoupled from volMult).
- Validated 5 independent headless crisis runs incl. repeat crisis: ES −30..+10% bounded, BTC −25%, ZN rallies (flight to quality), gold bid, VIX 79-93, VIX9D>VIX (CRISIS_BACKWARDATION), no compounding blowups, full recovery to normal regimes.

Stage Summary:
- `bun run lint` → 0 problems; `tsc --noEmit` → 0 app errors (examples/skills pre-existing only).
- Browser-verified (agent-browser): boot → Desk 1 (all 4 subtabs), Desk 2 (surface/GEX/pain/Greeks + sim order FILLED in blotter), Desk 3 correlation+density+L3, Desk 4 SVG yield map (US/DE/JP/GB/FR), Desk 9 sector matrix, Desk 10 GLI/Net-Liq, Desk 11 L3 MBO tape+icebergs, Desk 12 pair radar, Desk 13 CF/UA/proxy/token lifecycle.
- CRISIS E2E: SIMULATE MARKET LIQUIDITY CRASH → flashing crimson SYSTEMIC CRISIS LOCKDOWN overlay + intensity bar + auto-recovery countdown; all 3 Pre-Trade Interceptors engage staggered (400/900/1400ms); ticks/s 3.4K→9.1K; contango flips to BACKWARDATION/CRISIS_BACKWARDATION; GEX/derivs/infra degrade; auto-recovery at T-90s → STABILIZATION → NORMAL; manual TERMINATE available.
- Mobile 390px verified (cards stack, footer sticky w/ safe-area). Footer sticky verified on short & long pages.
